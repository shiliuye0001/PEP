let COUNT = 3;            
let INTERVAL_MS = 60;     
let ELEMENT_CHANCE = 0.3; 
let PEASHOOTER_BURST_CHANCE = 0.5; 
let FIRE_BURST_CHANCE = 0.5;       
let SNOW_BURST_CHANCE = 0.5;       
let SPLITPEA_BURST_CHANCE = 0.5;   
let GOO_BURST_CHANCE = 0.5;        
let ELECTRIC_BURST_CHANCE = 0.5;   
let SHADOW_BURST_CHANCE = 0.5;     
let SKY_BURST_CHANCE = 0.5;        
let PEAPOD_GROW_MS = 60 * 1000;  
let PEAPOD_MAX_HEADS = 5;        
let PEAPOD_ULT_RAIN_CHANCE = 0.5;      
let PEAPOD_ULT_SMALL_PER_HEAD = 50;    
let PEAPOD_ULT_SMALL_HEAD_CAP = 3;     
let PEAPOD_ULT_SMALL_PREPARE_SPEED = 2;    
let PEAPOD_ULT_SMALL_PREPARE_SECONDS = 0.4; 
let PEAPOD_ULT_SMALL_SPAWN_FORWARD = 3.5;   
let PEAPOD_ULT_SPLASH_DAMAGE = 100;   
let PEAPOD_ULT_SPLASH_RANGE_W = 3;    
let PEAPOD_ULT_SPLASH_RANGE_H = 3;    
let REPEATER_ATTR_CHANCE = 0.3;       
let REPEATER_FAVORED_WEIGHT = 0.5;    
let REPEATER_ULT_BONUS = 0.1;         
const REPEATER_ATTR_POOL = [            
  'pea_flame_yellow',  
  'pea_snow',          
  'pea_goo',           
  'pea_primal',        
  'electricpea',       
  'sea_pea',           
  'pea_sky'            
];
let THREEPEATER_EDGE_REDIRECT_DELAY_MS = 10;   
let THREEPEATER_HEAD_HEIGHT_DIFF = 24;         
let THREEPEATER_ULT_MAX_ANGLE = 0.4; 
let THREEPEATER_SKY_CHANCE = 0.3;    
let THREEPEATER_BLOW_FROM_ULT = 2;   
let SUNFLOWER_EXTRA_CHANCE = 0.5;  
let SUNFLOWER_EXTRA_SMALL = 25;    
let SUNFLOWER_EXTRA_MEDIUM = 50;   
let NUT_REGEN_DELAY = 15;      
let NUT_REGEN_RATE_1 = 50;     
let NUT_REGEN_RATE_2 = 80;     
let NUT_REGEN_TICK = 0.2;      
const FIRE_ENHANCED_PEA = 'pea_flame_blue'; 
let FIRE_ULT_RAIN_CHANCE = 0.5;        
const FIRE_ULT_RAIN_PEA = 'pea_flame_yellow'; 
let FIRE_ULT_RAIN_COUNT = 60;          
let FIRE_ULT_RAIN_PREPARE_SPEED = 2;   
let FIRE_ULT_RAIN_PREPARE_SECONDS = 0.25; 
let FIRE_ULT_RAIN_SHOOT_SPEED = 3;     
let FIRE_ULT_SCATTER_SCALE = 0.5;     
let FIRE_ULT_RAIN_COUNT_3 = 90;       
let FIRE_ULT_RAIN_BLUE_SHARE_3 = 1 / 3; 
const SNOW_ENHANCED_PEA = 'snowdrop_freeze'; 
let SNOW_ULT_ICICLE_SHARE_1 = 1 / 6;  
let SNOW_ULT_ICICLE_SHARE_2 = 1 / 4;  
let SNOW_ULT_ICICLE_SHARE_3 = 1 / 3;  
let SNOW_ULT_SCATTER_SCALE = 0.5;     
let SNOW_ULT_COUNT_3 = 90;            
let SPLITPEA_BACK_STRESS_ICE_CHANCE = 0.2;       
let SPLITPEA_BACK_STRESS_ICICLE_CHANCE = 0.05;    
const SPLITPEA_BACK_ICE_PEA = 'pea_snow';        
const SPLITPEA_BACK_ICICLE_PEA = 'snowdrop_freeze'; 
let SPLITPEA_BACK_COUNTER_COOLDOWN_MS = 10 * 1000; 
let SPLITPEA_ULT_BACK_ICE_SHARE = 1 / 6;       
let PRIMAL_SPEED_BOOST_STEP = 0.3;   
let PRIMAL_ULT_EXTRA_SHOTS = 2;   
let PRIMAL_ULT_RAIN_CHANCE = 0.5;            
let PRIMAL_ULT_RAIN_COUNT = 60;              
let PRIMAL_ULT_RAIN_COUNT_3 = 90;            
let PRIMAL_ULT_SCATTER_SCALE = 0.5;          
let PRIMAL_ULT_RAIN_PREPARE_SPEED = 2;       
let PRIMAL_ULT_RAIN_PREPARE_SECONDS = 0.4;   
let PRIMAL_ULT_RAIN_SCALE = 0.7;             
let PRIMAL_ULT_RAIN_DAMAGE = 30;             
let PRIMAL_ULT_RAIN_SPLASH_DAMAGE = 10;      
let PRIMAL_ULT_RAIN_SPLASH_RANGE = 1;        
let PRIMAL_ULT_RAIN_KNOCKBACK = 0.05;        
let PRIMAL_ULT_RAIN_STUN = 0;                
let GOO_ULT_RAIN_CHANCE = 0.5;        
const GOO_ULT_RAIN_PEA = 'pea_goo';     
let GOO_ULT_RAIN_COUNT = 60;          
let GOO_ULT_SCATTER_SCALE = 0.5;      
let GOO_ULT_RAIN_COUNT_3 = 90;        
let GOO_ULT_RAIN_PREPARE_SPEED = 2;   
let GOO_ULT_RAIN_PREPARE_SECONDS = 0.4; 
let ELECTRIC_ULT_RAIN_CHANCE = 0.5;        
let ELECTRIC_ULT_RAIN_COUNT = 60;          
let ELECTRIC_ULT_SCATTER_SCALE = 0.5;      
let ELECTRIC_ULT_RAIN_COUNT_3 = 90;        
let ELECTRIC_ULT_RAIN_SMALL_SHARE = 2 / 3; 
let ELECTRIC_ULT_RAIN_PREPARE_SPEED = 2;   
let ELECTRIC_ULT_RAIN_PREPARE_SECONDS = 0.4; 
let ELECTRIC_ULT_MEGA_EXTRA = 2;           
const MEGA_ATTR_POOL = [ 
  'electricpea',        
  'electricpea_pf',     
  'pea_flame_blue',     
  'snowdrop_freeze',    
  'pea_goo',            
  'pea_primal',         
  'pea_sky'             
];
let MEGA_ATTR_CHANCE = 0.3;        
let MEGA_KILL_BONUS = 0.01;        
let MEGA_KILL_MAX = 0.4;           
const MEGA_ULT_SPREAD_ANGLES = [-0.22, -0.11, 0, 0.11, 0.22]; 
let MEGA_BURST_UNIFY_MS = 500;     
let SHADOW_ULT_RAIN_CHANCE = 0.5;            
let SHADOW_ULT_RAIN_COUNT = 60;              
let SHADOW_ULT_RAIN_COUNT_3 = 90;            
let SHADOW_ULT_RAIN_DMG_SHADOW1 = 30;        
let SHADOW_ULT_RAIN_DMG_SHADOW2 = 40;        
let SHADOW_ULT_RAIN_PREPARE_SPEED = 2;       
let SHADOW_ULT_RAIN_PREPARE_SECONDS = 0.4;   
const SHADOW_ULT_SPREAD_ANGLES = [-0.11, -0.055, 0, 0.055, 0.11]; 
let SHADOW_ULT_RAIN_PERFUME_SECONDS = 3;     
let SHADOW_BURST_PERFUME_SECONDS = 3;        
let SHADOW_ULT_RAIN_JITTER_SHADOW = 0.25;  
let SHADOW_ULT_RAIN_JITTER_NORMAL = 0.13;  
let SHADOW_ULT_RAIN_PEA_SCALE = 1.75;   
let SEA_ULT_LOCK_SEA_PEA = 1;   
let SEA_ULT_LOCK_SWIM = 2;      
let SKY_ULT_SCATTER_SCALE = 0.5;   
let SKY_ULT_COUNT_3 = 90;          
const RAIN_SHOOT5_UUID = '3eWt+A7phAjKdJKhCU8xqX'; 
let RAIN_SHOOT5_INTERVAL_MS = 500;     
let RAIN_SHOOT5_VOLUME = 0.7;          
let FULL_ULT_COUNT = 3;             
let FULL_LIGHT_SCALE = 0.85;        
let FULL_KILL_DROP_CHANCE = 0.05;   
let SG_SHOT_BOTH_F = 4;          
let SG_SHOT_BOTH_B = 5;          
let SG_SHOT_FRONT_ONLY = 6;      
let SG_SHOT_BACK_ONLY = 7;       
let SG_BURST_MS = 50;            
let SG_ULT_FRONT = 150;          
let SG_ULT_BACK = 150;           
let SG_ULT_MS = 2000;            
let SG_BACK_ARC_DEG = 160;       
let SG_BACK_ICE_CHANCE = 0.3;    
let SG_BACK_ICE_ICICLE_SHARE = 0.5; 
let SG_ULT_BACK_ELEC_SHARE = 0.5;
let SG_ELEC_SCALE = 1.6;         
let BOSS_SHOTS = 4;          
let BOSS_SHOTS_UP = 5;       
let BOSS_BURST = 0.05;       
let BOSS_PF_CHANCE = 0.05;   
let BOSS_PF_COUNT = 450;     
let BOSS_SPREAD_DEG = 15;    
let BOSS_SPREAD_SLOTS = 15;  
let BOSS_SPEED_MULT = 1.7;   
let RUBY_DAMAGE = 40;             
let RUBY_ULT_COUNT = 10;          
let RUBY_ULT_INTERVAL_MS = 200;   
let RUBY_DOUBLE_CHANCE = 0.3;     
let RUBY_DOUBLE_DELAY_MS = 150;   
let RUBY_CHARGE_MS = 200;         
let SHADOW_HARVEST_DAMAGE = 40;   
let SHADOW_HARVEST_RANGE = 80;    
let SHADOW_SHARD_COUNT = 3;       
let SHADOW_SHARD_SCALE = 0.6;     
let SHADOW_KILL_HP = 500;         
export async function setup(ctx) {
  const log = ctx && ctx.log;
  const engine = ctx && ctx.unsafe && ctx.unsafe.engine;
  const cleanups = [];
  const pepDiag = { t: 0, enum: '', feat: '', store: '', gs: '', lc: '', pfc: '' };
  let PepZombieCls = null;
  let RUBY_FIELD_ROW = 55;        
  let RUBY_FIELD_R = 200;         
  let RUBY_FIELD_G = 30;          
  let RUBY_FIELD_B = 30;          
  let RUBY_FIELD_SCAN_MS = 100;   
  const hookRubyZombieShade = () => {
    try {
      if (!PepZombieCls || !PepZombieCls.prototype || PepZombieCls.prototype.__gpnRubySMHook) return;
      if (typeof PepZombieCls.prototype.shouldMaterial !== 'function') return;
      PepZombieCls.prototype.__gpnRubySMHook = true;
      const prevSM = PepZombieCls.prototype.shouldMaterial;
      PepZombieCls.prototype.shouldMaterial = function (...smArgs) {
        const res = prevSM.apply(this, smArgs);
        try {
          if (this.__gpnRubyField !== true) return res;
          const m = this.material;
          if (!m || !m.passes || !m.passes[0]) return res;
          const e0 = m.passes[0];
          try { e0.setUniform(e0.getHandle('chillColor'), 0); } catch (e3) {}
          try { e0.setUniform(e0.getHandle('perfume'), 0); } catch (e3) {}
          const dbc = this.body && this.body.db && this.body.db.color;
          const PCls = dbc ? dbc.constructor : null;
          if (PCls) { try { e0.setUniform(e0.getHandle('addColor'), new PCls(RUBY_FIELD_R, RUBY_FIELD_G, RUBY_FIELD_B, 255)); } catch (e3) {} }
        } catch (e3) {}
        return res;
      };
    } catch (e) {}
  };
  let RUBY_ICE_BREAK_TARGET_DMG = 40;   
  let RUBY_ICE_BREAK_SPLASH_DMG = 60;   
  let RUBY_ICE_BREAK_SPLASH_W = 1;      
  let RUBY_ICE_BREAK_SPLASH_H = 1;      
  let RUBY_ULT_DAMAGE = 100;            
  let RUBY_ULT_SCALE = 1.5;             
  let RUBY_ULT_PIERCE = Infinity;       
  let RUBY_ULT_SPLASH = 100;            
  let RubySnowdropSnd = null;
  try {
    let sdTimer = null;
    sdTimer = setInterval(() => {
      try {
        for (const n of ['Snowdrop', 'SnowdropPlant', 'snowdrop']) {
          try {
            const c = engine.getClassByName ? engine.getClassByName(n) : null;
            if (c && c.prototype && c.prototype.soundRes) RubySnowdropSnd = c.prototype.soundRes;
          } catch (e) {}
        }
        const cc = engine.getCc ? engine.getCc() : null;
        const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
        if (cc && PlantF) {
          const scene = cc.director.getScene();
          if (scene) {
            const list = scene.getComponentsInChildren(PlantF);
            if (Array.isArray(list)) {
              for (const p of list) {
                try {
                  if (!p || !p.node) continue;
                  if (/snowdrop|雪滴/i.test(p.node.name || '')) {
                    const snd = p.soundRes;
                    if (snd) RubySnowdropSnd = snd;
                  }
                } catch (e) {}
              }
            }
          }
        }
      } catch (e) {}
    }, 2000);
    cleanups.push(() => { try { clearInterval(sdTimer); } catch (e) {} });
  } catch (e) {}
  try {
    const csD = engine.getClassByName ? engine.getClassByName('commonShot') : null;
    if (csD && csD.prototype && typeof csD.prototype.dealDamageToZombie === 'function' && !csD.prototype.__gpnRubyHitHook) {
      csD.prototype.__gpnRubyHitHook = true;
      const prevDD = csD.prototype.dealDamageToZombie;
      csD.prototype.dealDamageToZombie = function (zombie, ...rest) {
        const preState = (() => {
          try {
            if (!zombie) return null;
            return {
              freeze: Number(zombie.freeze) || 0,
              _freeze: Number(zombie._freeze) || 0,
              chill: Number(zombie.chill) || 0,
              _chill: Number(zombie._chill) || 0,
              iceblocked: zombie.iceblocked ? 1 : 0,
              icebloom_block: zombie.icebloom_block ? 1 : 0,
              frozen: Number(zombie.frozen) || 0,
              stun: Number(zombie.stun) || 0,
              icetrap: zombie.icetrapDB ? 1 : 0
            };
          } catch (e) { return null; }
        })();
        const wasFrozenBefore = !!(preState && (preState.freeze > 0 || preState._freeze > 0 || preState.iceblocked || preState.icebloom_block || preState.frozen > 0 || preState.icetrap));
        const isRubyPrimary = arguments[2] == null;
        let splashRestore = null;
        if (this.__gpnRuby === true && isRubyPrimary && wasFrozenBefore && RUBY_ICE_BREAK_SPLASH_DMG > 0) {
          try {
            splashRestore = this.splashDamages;
            this.splashDamages = [{ splashRange: { width: RUBY_ICE_BREAK_SPLASH_W, height: RUBY_ICE_BREAK_SPLASH_H }, splashDamage: RUBY_ICE_BREAK_SPLASH_DMG }];
          } catch (e) { splashRestore = null; }
        }
        let rubyPiercePrimary = false;
        if (this.__gpnRubyPierce === true && zombie) {
          try {
            if (!this.__gpnRubyPierceHits) this.__gpnRubyPierceHits = new WeakSet();
            if (this.__gpnRubyPierceHits.has(zombie)) {
              try { if (this.__gpnRubyPierceVelX && this.linearVelocity && typeof this.linearVelocity.x === 'number') this.linearVelocity.x = this.__gpnRubyPierceVelX; } catch (e3) {}
              return;
            }
            this.__gpnRubyPierceHits.add(zombie);
            rubyPiercePrimary = true;
            this.__gpnPierceHitPending = true;
            this.__gpnPierceHpBefore = zombie && zombie.health;
          } catch (e) {}
        }
        const res = prevDD.apply(this, arguments);
        try { if (splashRestore !== null) this.splashDamages = splashRestore; } catch (e) {}
        try {
          if (this.__gpnRubyPierce === true && zombie && this.__gpnPierceHitPending === true) {
            this.__gpnPierceHitPending = false;
            const hpB = this.__gpnPierceHpBefore;
            if (hpB !== undefined && zombie.health >= hpB && zombie.health > 0) {
              try {
                if (typeof zombie.defaultDealDamage === 'function') {
                  zombie.defaultDealDamage({ damage: RUBY_ULT_DAMAGE, armorProtection: true, armorKnockSound: null, bodyKnockSound: false, damageDirection: null, damageType: this.damageType, flash: true, armorAlsoDamagedWhenNotProtecting: false });
                }
              } catch (e4) {}
            }
          }
        } catch (e) {}
        if (rubyPiercePrimary && this.__gpnRubyPierceVelX) {
          try { if (this.linearVelocity && typeof this.linearVelocity.x === 'number') this.linearVelocity.x = this.__gpnRubyPierceVelX; } catch (e) {}
        }
        if (rubyPiercePrimary && zombie && RUBY_ULT_DAMAGE > 0) {
          const zcls = PepZombieCls || (zombie && zombie.constructor);
          if (zcls) {
            const cc5 = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
            if (cc5) {
              const scene5 = cc5.director.getScene();
              if (scene5) {
                const list5 = scene5.getComponentsInChildren(zcls);
                if (Array.isArray(list5)) {
                  const tx5 = Number(zombie.worldPositionX) || 0;
                  const ty5 = Number(zombie.worldPositionY) || 0;
                  for (const z of list5) {
                    try {
                      if (!z || z === zombie || !z.node || !z.node.isValid || z.dead) continue;
                      if (this.__gpnRubyPierceHits && this.__gpnRubyPierceHits.has(z)) continue;
                      if (Math.abs((Number(z.worldPositionX) || 0) - tx5) < 80 && Math.abs((Number(z.worldPositionY) || 0) - ty5) < 80 && typeof z.defaultDealDamage === 'function') {
                        z.defaultDealDamage({ damage: RUBY_ULT_DAMAGE, armorProtection: true, armorKnockSound: null, bodyKnockSound: false, damageDirection: null, damageType: this.damageType, flash: true, armorAlsoDamagedWhenNotProtecting: false });
                        try { if (this.__gpnRubyPierceHits) this.__gpnRubyPierceHits.add(z); } catch (e4) {}
                      }
                    } catch (e3) {}
                  }
                }
              }
            }
          }
        }
        try {
          if (this.__gpnRuby === true && zombie) {
            try { if (!PepZombieCls && zombie && zombie.constructor && zombie.constructor.prototype) { PepZombieCls = zombie.constructor; hookRubyZombieShade(); } } catch (e) {}
            try {
              if (isRubyPrimary && wasFrozenBefore && RUBY_ICE_BREAK_TARGET_DMG > 0 && typeof zombie.defaultDealDamage === 'function') {
                zombie.defaultDealDamage({
                  damage: RUBY_ICE_BREAK_TARGET_DMG,
                  armorProtection: !!this.armorProtection,
                  armorKnockSound: this.armorKnockSound,
                  bodyKnockSound: this.bodyKnockSound,
                  damageDirection: null,
                  damageType: this.damageType,
                  flash: true,
                  armorAlsoDamagedWhenNotProtecting: false
                });
              }
            } catch (e) {}
            try { zombie.chill = 0; } catch (e2) {}
            try { zombie._chill = 0; } catch (e2) {}
            try { zombie.freeze = 0; } catch (e2) {}
            try { zombie._freeze = 0; } catch (e2) {}
            try { zombie.slow = 0; } catch (e2) {}
            try { zombie._slow = 0; } catch (e2) {}
            try { if (typeof zombie.unChill === 'function') zombie.unChill(); } catch (e2) {}
            try { if (typeof zombie.removeChill === 'function') zombie.removeChill(); } catch (e2) {}
            try { if (typeof zombie.refreshSpeed === 'function') zombie.refreshSpeed(); } catch (e2) {}
          }
        } catch (e) {}
        return res;
      };
    }
    if (csD && csD.prototype && typeof csD.prototype.characterOnEnable === 'function' && !csD.prototype.__gpnRubyCE) {
      csD.prototype.__gpnRubyCE = true;
      const prevCE = csD.prototype.characterOnEnable;
      csD.prototype.characterOnEnable = function (...args) {
        try { this.__gpnRuby = false; this.__gpnRubyUlt = false; this.__gpnRubyPiercedSet = null; this.__gpnRubyPierce = false; this.__gpnRubyPierceHits = null; delete this.__gpnRubyPierceDetecting; delete this.__gpnRubyPierceHit; delete this.__gpnPierceFirst; delete this.__gpnPierceSkip; delete this.__gpnPierceLogN; } catch (e2) {}
        return prevCE.apply(this, args);
      };
    }
    try {
      if (csD && csD.prototype && typeof csD.prototype.detectEnemy === 'function' && !csD.prototype.__gpnRubyPierceDE) {
        csD.prototype.__gpnRubyPierceDE = true;
        const prevDE = csD.prototype.detectEnemy;
        csD.prototype.detectEnemy = function (...args) {
          const pierce = this.__gpnRubyPierce === true;
          if (pierce) this.__gpnRubyPierceDetecting = true;
          try { return prevDE.apply(this, args); }
          finally { if (pierce) delete this.__gpnRubyPierceDetecting; }
        };
        cleanups.push(() => { try { if (csD.prototype.detectEnemy && csD.prototype.__gpnRubyPierceDE) csD.prototype.detectEnemy = prevDE; delete csD.prototype.__gpnRubyPierceDE; } catch (e) {} });
      }
      if (csD && csD.prototype && typeof csD.prototype.pop === 'function' && !csD.prototype.__gpnRubyPiercePop) {
        csD.prototype.__gpnRubyPiercePop = true;
        const prevPop = csD.prototype.pop;
        csD.prototype.pop = function (...args) {
          try {
            if (this.__gpnRubyPierce === true && this.__gpnRubyPierceDetecting === true) return;
          } catch (e) {}
          return prevPop.apply(this, args);
        };
        cleanups.push(() => { try { if (csD.prototype.pop && csD.prototype.__gpnRubyPiercePop) csD.prototype.pop = prevPop; delete csD.prototype.__gpnRubyPiercePop; } catch (e) {} });
      }
    } catch (e) {}
  } catch (e) {}
  const PEP_FIELD_DEFS = [
    ['FULL_ULT_COUNT', '通用·满级次数', 1, 10, 1],
    ['FULL_KILL_DROP_CHANCE', '通用·击杀产豆概率', 0, 1, 0.01],
    ['ELEMENT_CHANCE', '火焰/寒冰·强化弹概率', 0, 1, 0.01],
    ['PEASHOOTER_BURST_CHANCE', '豌豆射手·连发概率', 0, 1, 0.01],
    ['PEAPOD_GROW_MS', '豌豆荚·生长毫秒', 5000, 180000, 5000],
    ['REPEATER_ATTR_CHANCE', '双重射手·属性豌豆概率', 0, 1, 0.01],
    ['REPEATER_ULT_BONUS', '双重射手·开大每档加成', 0, 0.5, 0.01],
    ['THREEPEATER_SKY_CHANCE', '三线射手·天空豌豆概率', 0, 1, 0.01],
    ['SUNFLOWER_EXTRA_CHANCE', '向日葵·额外阳光概率', 0, 1, 0.01],
    ['NUT_REGEN_RATE_1', '坚果·1次大回血率', 0, 200, 5],
    ['NUT_REGEN_RATE_2', '坚果·2次大回血率', 0, 300, 5],
    ['FIRE_BURST_CHANCE', '火焰射手·连发概率', 0, 1, 0.01],
    ['FIRE_ULT_RAIN_BLUE_SHARE_3', '火焰射手·3次起蓝火比例', 0, 1, 0.01],
    ['SNOW_BURST_CHANCE', '寒冰射手·连发概率', 0, 1, 0.01],
    ['SNOW_ULT_ICICLE_SHARE_1', '寒冰射手·1次冰棱比例', 0, 1, 0.01],
    ['SNOW_ULT_ICICLE_SHARE_2', '寒冰射手·2次冰棱比例', 0, 1, 0.01],
    ['SNOW_ULT_ICICLE_SHARE_3', '寒冰射手·3次起冰棱比例', 0, 1, 0.01],
    ['SPLITPEA_BURST_CHANCE', '裂荚射手·连发概率', 0, 1, 0.01],
    ['SPLITPEA_BACK_STRESS_ICE_CHANCE', '裂荚射手·应激冰豌豆', 0, 1, 0.01],
    ['SPLITPEA_BACK_STRESS_ICICLE_CHANCE', '裂荚射手·应激冰棱', 0, 1, 0.01],
    ['SPLITPEA_ULT_BACK_ICE_SHARE', '裂荚射手·大招后冰比例', 0, 1, 0.01],
    ['PRIMAL_SPEED_BOOST_STEP', '原始豌豆·攻速成长步', 0, 1, 0.01],
    ['PRIMAL_ULT_EXTRA_SHOTS', '原始豌豆·3次起加颗', 0, 10, 1],
    ['GOO_BURST_CHANCE', '毒液豌豆·连发概率', 0, 1, 0.01],
    ['ELECTRIC_BURST_CHANCE', '电能豌豆·连发概率', 0, 1, 0.01],
    ['ELECTRIC_ULT_RAIN_SMALL_SHARE', '电能豌豆·小电豌豆比例', 0, 1, 0.01],
    ['ELECTRIC_ULT_MEGA_EXTRA', '电能豌豆·3次起大电加颗', 0, 10, 1],
    ['MEGA_ATTR_CHANCE', '大哥·属性豌豆概率', 0, 1, 0.01],
    ['MEGA_KILL_BONUS', '大哥·击杀成长量', 0, 0.1, 0.01],
    ['MEGA_KILL_MAX', '大哥·自开大封顶', 0.03, 1, 0.01],
    ['SHADOW_BURST_CHANCE', '暗影豌豆·连发概率', 0, 1, 0.01],
    ['SKY_BURST_CHANCE', '天空豌豆·连发概率', 0, 1, 0.01],
    ['SHADOW_HARVEST_DAMAGE', '暗影大哥·收割爆发伤害', 1, 200, 1],
    ['SHADOW_HARVEST_RANGE', '暗影大哥·收割范围', 20, 200, 1],
    ['SHADOW_SHARD_COUNT', '暗影大哥·散射小暗影数', 1, 12, 1],
    ['SHADOW_KILL_HP', '暗影大哥·斩杀阈值', 100, 5000, 1],
    ['RUBY_ULT_COUNT', '红宝石·大招连射数', 1, 40, 1],
    ['RUBY_ULT_INTERVAL_MS', '红宝石·连射间隔毫秒', 50, 600, 1],
    ['RUBY_DOUBLE_CHANCE', '红宝石·普攻双发概率', 0, 1, 0.01],
    ['RUBY_ICE_BREAK_TARGET_DMG', '红宝石·破冰本体伤害', 0, 200, 1],
    ['RUBY_ICE_BREAK_SPLASH_DMG', '红宝石·破冰溅射伤害', 0, 300, 1],
    ['RUBY_ICE_BREAK_SPLASH_W', '红宝石·破冰溅射宽格', 0, 3, 1],
    ['RUBY_ICE_BREAK_SPLASH_H', '红宝石·破冰溅射高格', 0, 3, 1],
    ['RUBY_FIELD_ROW', '红宝石·领域行判定', 20, 120, 1],
    ['RUBY_FIELD_SCAN_MS', '红宝石·领域扫描毫秒', 30, 500, 1],
    ['SG_SHOT_BOTH_F', '裂荚大哥·前头连发(同打)', 1, 12, 1],
    ['SG_SHOT_BOTH_B', '裂荚大哥·后头连发(同打)', 1, 12, 1],
    ['SG_SHOT_FRONT_ONLY', '裂荚大哥·仅前头连发', 1, 14, 1],
    ['SG_SHOT_BACK_ONLY', '裂荚大哥·仅后头连发', 1, 14, 1],
    ['SG_BACK_ARC_DEG', '裂荚大哥·后扇角度', 20, 180, 1],
    ['SG_BACK_ICE_CHANCE', '裂荚大哥·后头冰系概率', 0, 1, 0.01],
    ['SG_BACK_ICE_ICICLE_SHARE', '裂荚大哥·冰系中冰棱占比', 0, 1, 0.01],
    ['SG_ULT_BACK_ELEC_SHARE', '裂荚大哥·后向大招电弹占比', 0, 1, 0.01],
  ];
  const pepCurrentValue = (key, fallback) => {
    try {
      const map = {
        COUNT, INTERVAL_MS, ELEMENT_CHANCE,
        PEASHOOTER_BURST_CHANCE, FIRE_BURST_CHANCE, SNOW_BURST_CHANCE, SPLITPEA_BURST_CHANCE, GOO_BURST_CHANCE, ELECTRIC_BURST_CHANCE, SHADOW_BURST_CHANCE, SKY_BURST_CHANCE,
        PEAPOD_GROW_MS, PEAPOD_MAX_HEADS, PEAPOD_ULT_RAIN_CHANCE, PEAPOD_ULT_SMALL_PER_HEAD, PEAPOD_ULT_SMALL_HEAD_CAP, PEAPOD_ULT_SPLASH_DAMAGE, PEAPOD_ULT_SPLASH_RANGE_W, PEAPOD_ULT_SPLASH_RANGE_H,
        REPEATER_ATTR_CHANCE, REPEATER_FAVORED_WEIGHT, REPEATER_ULT_BONUS,
        THREEPEATER_EDGE_REDIRECT_DELAY_MS, THREEPEATER_HEAD_HEIGHT_DIFF, THREEPEATER_ULT_MAX_ANGLE, THREEPEATER_SKY_CHANCE, THREEPEATER_BLOW_FROM_ULT,
        SUNFLOWER_EXTRA_CHANCE, SUNFLOWER_EXTRA_SMALL, SUNFLOWER_EXTRA_MEDIUM,
        NUT_REGEN_DELAY, NUT_REGEN_RATE_1, NUT_REGEN_RATE_2, NUT_REGEN_TICK,
        FIRE_ULT_RAIN_CHANCE, FIRE_ULT_RAIN_COUNT, FIRE_ULT_SCATTER_SCALE, FIRE_ULT_RAIN_COUNT_3, FIRE_ULT_RAIN_BLUE_SHARE_3,
        SNOW_ULT_ICICLE_SHARE_1, SNOW_ULT_ICICLE_SHARE_2, SNOW_ULT_ICICLE_SHARE_3, SNOW_ULT_SCATTER_SCALE, SNOW_ULT_COUNT_3,
        SPLITPEA_BACK_STRESS_ICE_CHANCE, SPLITPEA_BACK_STRESS_ICICLE_CHANCE, SPLITPEA_BACK_COUNTER_COOLDOWN_MS, SPLITPEA_ULT_BACK_ICE_SHARE,
        PRIMAL_SPEED_BOOST_STEP, PRIMAL_ULT_EXTRA_SHOTS, PRIMAL_ULT_RAIN_CHANCE, PRIMAL_ULT_RAIN_COUNT, PRIMAL_ULT_RAIN_COUNT_3, PRIMAL_ULT_SCATTER_SCALE, PRIMAL_ULT_RAIN_SCALE, PRIMAL_ULT_RAIN_DAMAGE, PRIMAL_ULT_RAIN_SPLASH_DAMAGE, PRIMAL_ULT_RAIN_SPLASH_RANGE, PRIMAL_ULT_RAIN_KNOCKBACK, PRIMAL_ULT_RAIN_STUN,
        GOO_ULT_RAIN_CHANCE, GOO_ULT_RAIN_COUNT, GOO_ULT_SCATTER_SCALE, GOO_ULT_RAIN_COUNT_3,
        ELECTRIC_ULT_RAIN_CHANCE, ELECTRIC_ULT_RAIN_COUNT, ELECTRIC_ULT_SCATTER_SCALE, ELECTRIC_ULT_RAIN_COUNT_3, ELECTRIC_ULT_RAIN_SMALL_SHARE, ELECTRIC_ULT_MEGA_EXTRA,
        MEGA_ATTR_CHANCE, MEGA_KILL_BONUS, MEGA_KILL_MAX, MEGA_BURST_UNIFY_MS,
        SHADOW_ULT_RAIN_CHANCE, SHADOW_ULT_RAIN_COUNT, SHADOW_ULT_RAIN_COUNT_3, SHADOW_ULT_RAIN_DMG_SHADOW1, SHADOW_ULT_RAIN_DMG_SHADOW2, SHADOW_ULT_RAIN_PERFUME_SECONDS, SHADOW_BURST_PERFUME_SECONDS, SHADOW_ULT_RAIN_JITTER_SHADOW, SHADOW_ULT_RAIN_JITTER_NORMAL, SHADOW_ULT_RAIN_PEA_SCALE,
        SEA_ULT_LOCK_SEA_PEA, SEA_ULT_LOCK_SWIM,
        SKY_ULT_SCATTER_SCALE, SKY_ULT_COUNT_3,
        RAIN_SHOOT5_INTERVAL_MS, RAIN_SHOOT5_VOLUME,
        FULL_ULT_COUNT, FULL_LIGHT_SCALE, FULL_KILL_DROP_CHANCE,
        SG_SHOT_BOTH_F, SG_SHOT_BOTH_B, SG_SHOT_FRONT_ONLY, SG_SHOT_BACK_ONLY, SG_BACK_ARC_DEG, SG_BACK_ICE_CHANCE, SG_BACK_ICE_ICICLE_SHARE, SG_ULT_BACK_ELEC_SHARE,
        SHADOW_HARVEST_DAMAGE, SHADOW_HARVEST_RANGE, SHADOW_SHARD_COUNT, SHADOW_KILL_HP,
        RUBY_ULT_COUNT, RUBY_ULT_INTERVAL_MS, RUBY_DOUBLE_CHANCE, RUBY_ICE_BREAK_TARGET_DMG, RUBY_ICE_BREAK_SPLASH_DMG, RUBY_ICE_BREAK_SPLASH_W, RUBY_ICE_BREAK_SPLASH_H, RUBY_FIELD_ROW, RUBY_FIELD_SCAN_MS,
      };
      const v = map[key];
      return (typeof v === 'number' && isFinite(v)) ? v : fallback;
    } catch (e) { return fallback; }
  };
  const PEP_SETTINGS_FIELDS = PEP_FIELD_DEFS.map((d) => ({
    key: d[0], label: d[1], type: 'slider', min: d[2], max: d[3], step: d[4],
    default: pepCurrentValue(d[0], d[2]),
  }));
  const applyPepSettings = (values) => {
    try {
      if (!values || typeof values !== 'object') return;
      const num = (k, def) => {
        const v = values[k];
        return (typeof v === 'number' && isFinite(v)) ? Math.round(v * 100) / 100 : def;
      };
      PEASHOOTER_BURST_CHANCE = num('PEASHOOTER_BURST_CHANCE', PEASHOOTER_BURST_CHANCE);
      FIRE_BURST_CHANCE = num('FIRE_BURST_CHANCE', FIRE_BURST_CHANCE);
      SNOW_BURST_CHANCE = num('SNOW_BURST_CHANCE', SNOW_BURST_CHANCE);
      SPLITPEA_BURST_CHANCE = num('SPLITPEA_BURST_CHANCE', SPLITPEA_BURST_CHANCE);
      GOO_BURST_CHANCE = num('GOO_BURST_CHANCE', GOO_BURST_CHANCE);
      ELECTRIC_BURST_CHANCE = num('ELECTRIC_BURST_CHANCE', ELECTRIC_BURST_CHANCE);
      SHADOW_BURST_CHANCE = num('SHADOW_BURST_CHANCE', SHADOW_BURST_CHANCE);
      SKY_BURST_CHANCE = num('SKY_BURST_CHANCE', SKY_BURST_CHANCE);
      COUNT = num('COUNT', COUNT);
      INTERVAL_MS = num('INTERVAL_MS', INTERVAL_MS);
      ELEMENT_CHANCE = num('ELEMENT_CHANCE', ELEMENT_CHANCE);
      PEAPOD_GROW_MS = num('PEAPOD_GROW_MS', PEAPOD_GROW_MS);
      PEAPOD_MAX_HEADS = num('PEAPOD_MAX_HEADS', PEAPOD_MAX_HEADS);
      PEAPOD_ULT_RAIN_CHANCE = num('PEAPOD_ULT_RAIN_CHANCE', PEAPOD_ULT_RAIN_CHANCE);
      PEAPOD_ULT_SMALL_PER_HEAD = num('PEAPOD_ULT_SMALL_PER_HEAD', PEAPOD_ULT_SMALL_PER_HEAD);
      PEAPOD_ULT_SMALL_HEAD_CAP = num('PEAPOD_ULT_SMALL_HEAD_CAP', PEAPOD_ULT_SMALL_HEAD_CAP);
      PEAPOD_ULT_SPLASH_DAMAGE = num('PEAPOD_ULT_SPLASH_DAMAGE', PEAPOD_ULT_SPLASH_DAMAGE);
      PEAPOD_ULT_SPLASH_RANGE_W = num('PEAPOD_ULT_SPLASH_RANGE_W', PEAPOD_ULT_SPLASH_RANGE_W);
      PEAPOD_ULT_SPLASH_RANGE_H = num('PEAPOD_ULT_SPLASH_RANGE_H', PEAPOD_ULT_SPLASH_RANGE_H);
      REPEATER_ATTR_CHANCE = num('REPEATER_ATTR_CHANCE', REPEATER_ATTR_CHANCE);
      REPEATER_FAVORED_WEIGHT = num('REPEATER_FAVORED_WEIGHT', REPEATER_FAVORED_WEIGHT);
      REPEATER_ULT_BONUS = num('REPEATER_ULT_BONUS', REPEATER_ULT_BONUS);
      THREEPEATER_EDGE_REDIRECT_DELAY_MS = num('THREEPEATER_EDGE_REDIRECT_DELAY_MS', THREEPEATER_EDGE_REDIRECT_DELAY_MS);
      THREEPEATER_HEAD_HEIGHT_DIFF = num('THREEPEATER_HEAD_HEIGHT_DIFF', THREEPEATER_HEAD_HEIGHT_DIFF);
      THREEPEATER_ULT_MAX_ANGLE = num('THREEPEATER_ULT_MAX_ANGLE', THREEPEATER_ULT_MAX_ANGLE);
      THREEPEATER_SKY_CHANCE = num('THREEPEATER_SKY_CHANCE', THREEPEATER_SKY_CHANCE);
      THREEPEATER_BLOW_FROM_ULT = num('THREEPEATER_BLOW_FROM_ULT', THREEPEATER_BLOW_FROM_ULT);
      SUNFLOWER_EXTRA_CHANCE = num('SUNFLOWER_EXTRA_CHANCE', SUNFLOWER_EXTRA_CHANCE);
      SUNFLOWER_EXTRA_SMALL = num('SUNFLOWER_EXTRA_SMALL', SUNFLOWER_EXTRA_SMALL);
      SUNFLOWER_EXTRA_MEDIUM = num('SUNFLOWER_EXTRA_MEDIUM', SUNFLOWER_EXTRA_MEDIUM);
      NUT_REGEN_DELAY = num('NUT_REGEN_DELAY', NUT_REGEN_DELAY);
      NUT_REGEN_RATE_1 = num('NUT_REGEN_RATE_1', NUT_REGEN_RATE_1);
      NUT_REGEN_RATE_2 = num('NUT_REGEN_RATE_2', NUT_REGEN_RATE_2);
      NUT_REGEN_TICK = num('NUT_REGEN_TICK', NUT_REGEN_TICK);
      FIRE_ULT_RAIN_COUNT = num('FIRE_ULT_RAIN_COUNT', FIRE_ULT_RAIN_COUNT);
      FIRE_ULT_SCATTER_SCALE = num('FIRE_ULT_SCATTER_SCALE', FIRE_ULT_SCATTER_SCALE);
      FIRE_ULT_RAIN_COUNT_3 = num('FIRE_ULT_RAIN_COUNT_3', FIRE_ULT_RAIN_COUNT_3);
      FIRE_ULT_RAIN_BLUE_SHARE_3 = num('FIRE_ULT_RAIN_BLUE_SHARE_3', FIRE_ULT_RAIN_BLUE_SHARE_3);
      SNOW_ULT_ICICLE_SHARE_1 = num('SNOW_ULT_ICICLE_SHARE_1', SNOW_ULT_ICICLE_SHARE_1);
      SNOW_ULT_ICICLE_SHARE_2 = num('SNOW_ULT_ICICLE_SHARE_2', SNOW_ULT_ICICLE_SHARE_2);
      SNOW_ULT_ICICLE_SHARE_3 = num('SNOW_ULT_ICICLE_SHARE_3', SNOW_ULT_ICICLE_SHARE_3);
      SNOW_ULT_SCATTER_SCALE = num('SNOW_ULT_SCATTER_SCALE', SNOW_ULT_SCATTER_SCALE);
      SNOW_ULT_COUNT_3 = num('SNOW_ULT_COUNT_3', SNOW_ULT_COUNT_3);
      SPLITPEA_BACK_STRESS_ICE_CHANCE = num('SPLITPEA_BACK_STRESS_ICE_CHANCE', SPLITPEA_BACK_STRESS_ICE_CHANCE);
      SPLITPEA_BACK_STRESS_ICICLE_CHANCE = num('SPLITPEA_BACK_STRESS_ICICLE_CHANCE', SPLITPEA_BACK_STRESS_ICICLE_CHANCE);
      SPLITPEA_BACK_COUNTER_COOLDOWN_MS = num('SPLITPEA_BACK_COUNTER_COOLDOWN_MS', SPLITPEA_BACK_COUNTER_COOLDOWN_MS);
      SPLITPEA_ULT_BACK_ICE_SHARE = num('SPLITPEA_ULT_BACK_ICE_SHARE', SPLITPEA_ULT_BACK_ICE_SHARE);
      PRIMAL_SPEED_BOOST_STEP = num('PRIMAL_SPEED_BOOST_STEP', PRIMAL_SPEED_BOOST_STEP);
      PRIMAL_ULT_EXTRA_SHOTS = num('PRIMAL_ULT_EXTRA_SHOTS', PRIMAL_ULT_EXTRA_SHOTS);
      PRIMAL_ULT_RAIN_CHANCE = num('PRIMAL_ULT_RAIN_CHANCE', PRIMAL_ULT_RAIN_CHANCE);
      PRIMAL_ULT_RAIN_COUNT = num('PRIMAL_ULT_RAIN_COUNT', PRIMAL_ULT_RAIN_COUNT);
      PRIMAL_ULT_RAIN_COUNT_3 = num('PRIMAL_ULT_RAIN_COUNT_3', PRIMAL_ULT_RAIN_COUNT_3);
      PRIMAL_ULT_SCATTER_SCALE = num('PRIMAL_ULT_SCATTER_SCALE', PRIMAL_ULT_SCATTER_SCALE);
      PRIMAL_ULT_RAIN_SCALE = num('PRIMAL_ULT_RAIN_SCALE', PRIMAL_ULT_RAIN_SCALE);
      PRIMAL_ULT_RAIN_DAMAGE = num('PRIMAL_ULT_RAIN_DAMAGE', PRIMAL_ULT_RAIN_DAMAGE);
      PRIMAL_ULT_RAIN_SPLASH_DAMAGE = num('PRIMAL_ULT_RAIN_SPLASH_DAMAGE', PRIMAL_ULT_RAIN_SPLASH_DAMAGE);
      PRIMAL_ULT_RAIN_SPLASH_RANGE = num('PRIMAL_ULT_RAIN_SPLASH_RANGE', PRIMAL_ULT_RAIN_SPLASH_RANGE);
      PRIMAL_ULT_RAIN_KNOCKBACK = num('PRIMAL_ULT_RAIN_KNOCKBACK', PRIMAL_ULT_RAIN_KNOCKBACK);
      PRIMAL_ULT_RAIN_STUN = num('PRIMAL_ULT_RAIN_STUN', PRIMAL_ULT_RAIN_STUN);
      GOO_ULT_RAIN_CHANCE = num('GOO_ULT_RAIN_CHANCE', GOO_ULT_RAIN_CHANCE);
      GOO_ULT_RAIN_COUNT = num('GOO_ULT_RAIN_COUNT', GOO_ULT_RAIN_COUNT);
      GOO_ULT_SCATTER_SCALE = num('GOO_ULT_SCATTER_SCALE', GOO_ULT_SCATTER_SCALE);
      GOO_ULT_RAIN_COUNT_3 = num('GOO_ULT_RAIN_COUNT_3', GOO_ULT_RAIN_COUNT_3);
      ELECTRIC_ULT_RAIN_CHANCE = num('ELECTRIC_ULT_RAIN_CHANCE', ELECTRIC_ULT_RAIN_CHANCE);
      ELECTRIC_ULT_RAIN_COUNT = num('ELECTRIC_ULT_RAIN_COUNT', ELECTRIC_ULT_RAIN_COUNT);
      ELECTRIC_ULT_SCATTER_SCALE = num('ELECTRIC_ULT_SCATTER_SCALE', ELECTRIC_ULT_SCATTER_SCALE);
      ELECTRIC_ULT_RAIN_COUNT_3 = num('ELECTRIC_ULT_RAIN_COUNT_3', ELECTRIC_ULT_RAIN_COUNT_3);
      ELECTRIC_ULT_RAIN_SMALL_SHARE = num('ELECTRIC_ULT_RAIN_SMALL_SHARE', ELECTRIC_ULT_RAIN_SMALL_SHARE);
      ELECTRIC_ULT_MEGA_EXTRA = num('ELECTRIC_ULT_MEGA_EXTRA', ELECTRIC_ULT_MEGA_EXTRA);
      MEGA_ATTR_CHANCE = num('MEGA_ATTR_CHANCE', MEGA_ATTR_CHANCE);
      MEGA_KILL_BONUS = num('MEGA_KILL_BONUS', MEGA_KILL_BONUS);
      MEGA_KILL_MAX = num('MEGA_KILL_MAX', MEGA_KILL_MAX);
      MEGA_BURST_UNIFY_MS = num('MEGA_BURST_UNIFY_MS', MEGA_BURST_UNIFY_MS);
      SHADOW_ULT_RAIN_CHANCE = num('SHADOW_ULT_RAIN_CHANCE', SHADOW_ULT_RAIN_CHANCE);
      SHADOW_ULT_RAIN_COUNT = num('SHADOW_ULT_RAIN_COUNT', SHADOW_ULT_RAIN_COUNT);
      SHADOW_ULT_RAIN_COUNT_3 = num('SHADOW_ULT_RAIN_COUNT_3', SHADOW_ULT_RAIN_COUNT_3);
      SHADOW_ULT_RAIN_DMG_SHADOW1 = num('SHADOW_ULT_RAIN_DMG_SHADOW1', SHADOW_ULT_RAIN_DMG_SHADOW1);
      SHADOW_ULT_RAIN_DMG_SHADOW2 = num('SHADOW_ULT_RAIN_DMG_SHADOW2', SHADOW_ULT_RAIN_DMG_SHADOW2);
      SHADOW_ULT_RAIN_PERFUME_SECONDS = num('SHADOW_ULT_RAIN_PERFUME_SECONDS', SHADOW_ULT_RAIN_PERFUME_SECONDS);
      SHADOW_BURST_PERFUME_SECONDS = num('SHADOW_BURST_PERFUME_SECONDS', SHADOW_BURST_PERFUME_SECONDS);
      SHADOW_ULT_RAIN_JITTER_SHADOW = num('SHADOW_ULT_RAIN_JITTER_SHADOW', SHADOW_ULT_RAIN_JITTER_SHADOW);
      SHADOW_ULT_RAIN_JITTER_NORMAL = num('SHADOW_ULT_RAIN_JITTER_NORMAL', SHADOW_ULT_RAIN_JITTER_NORMAL);
      SHADOW_ULT_RAIN_PEA_SCALE = num('SHADOW_ULT_RAIN_PEA_SCALE', SHADOW_ULT_RAIN_PEA_SCALE);
      SEA_ULT_LOCK_SEA_PEA = num('SEA_ULT_LOCK_SEA_PEA', SEA_ULT_LOCK_SEA_PEA);
      SEA_ULT_LOCK_SWIM = num('SEA_ULT_LOCK_SWIM', SEA_ULT_LOCK_SWIM);
      SKY_ULT_SCATTER_SCALE = num('SKY_ULT_SCATTER_SCALE', SKY_ULT_SCATTER_SCALE);
      SKY_ULT_COUNT_3 = num('SKY_ULT_COUNT_3', SKY_ULT_COUNT_3);
      RAIN_SHOOT5_INTERVAL_MS = num('RAIN_SHOOT5_INTERVAL_MS', RAIN_SHOOT5_INTERVAL_MS);
      RAIN_SHOOT5_VOLUME = num('RAIN_SHOOT5_VOLUME', RAIN_SHOOT5_VOLUME);
      FULL_ULT_COUNT = num('FULL_ULT_COUNT', FULL_ULT_COUNT);
      FULL_LIGHT_SCALE = num('FULL_LIGHT_SCALE', FULL_LIGHT_SCALE);
      FULL_KILL_DROP_CHANCE = num('FULL_KILL_DROP_CHANCE', FULL_KILL_DROP_CHANCE);
      SG_SHOT_BOTH_F = num('SG_SHOT_BOTH_F', SG_SHOT_BOTH_F);
      SG_SHOT_BOTH_B = num('SG_SHOT_BOTH_B', SG_SHOT_BOTH_B);
      SG_SHOT_FRONT_ONLY = num('SG_SHOT_FRONT_ONLY', SG_SHOT_FRONT_ONLY);
      SG_SHOT_BACK_ONLY = num('SG_SHOT_BACK_ONLY', SG_SHOT_BACK_ONLY);
      SG_BACK_ARC_DEG = num('SG_BACK_ARC_DEG', SG_BACK_ARC_DEG);
      SG_BACK_ICE_CHANCE = num('SG_BACK_ICE_CHANCE', SG_BACK_ICE_CHANCE);
      SG_BACK_ICE_ICICLE_SHARE = num('SG_BACK_ICE_ICICLE_SHARE', SG_BACK_ICE_ICICLE_SHARE);
      SG_ULT_BACK_ELEC_SHARE = num('SG_ULT_BACK_ELEC_SHARE', SG_ULT_BACK_ELEC_SHARE);
      SHADOW_HARVEST_DAMAGE = num('SHADOW_HARVEST_DAMAGE', SHADOW_HARVEST_DAMAGE);
      SHADOW_HARVEST_RANGE = num('SHADOW_HARVEST_RANGE', SHADOW_HARVEST_RANGE);
      SHADOW_SHARD_COUNT = num('SHADOW_SHARD_COUNT', SHADOW_SHARD_COUNT);
      SHADOW_KILL_HP = num('SHADOW_KILL_HP', SHADOW_KILL_HP);
      RUBY_ULT_COUNT = num('RUBY_ULT_COUNT', RUBY_ULT_COUNT);
      RUBY_ULT_INTERVAL_MS = num('RUBY_ULT_INTERVAL_MS', RUBY_ULT_INTERVAL_MS);
      RUBY_DOUBLE_CHANCE = num('RUBY_DOUBLE_CHANCE', RUBY_DOUBLE_CHANCE);
      RUBY_ICE_BREAK_TARGET_DMG = num('RUBY_ICE_BREAK_TARGET_DMG', RUBY_ICE_BREAK_TARGET_DMG);
      RUBY_ICE_BREAK_SPLASH_DMG = num('RUBY_ICE_BREAK_SPLASH_DMG', RUBY_ICE_BREAK_SPLASH_DMG);
      RUBY_ICE_BREAK_SPLASH_W = num('RUBY_ICE_BREAK_SPLASH_W', RUBY_ICE_BREAK_SPLASH_W);
      RUBY_ICE_BREAK_SPLASH_H = num('RUBY_ICE_BREAK_SPLASH_H', RUBY_ICE_BREAK_SPLASH_H);
      RUBY_FIELD_ROW = num('RUBY_FIELD_ROW', RUBY_FIELD_ROW);
      RUBY_FIELD_SCAN_MS = num('RUBY_FIELD_SCAN_MS', RUBY_FIELD_SCAN_MS);
    } catch (e) {}
  };
  const PEP_SETTINGS_SCHEMA = {
    title: 'PEP 植物增强参数',
    description: '全部数值参数实时可调;豌豆类型池/角度表等数组参数不在此处',
    fields: PEP_SETTINGS_FIELDS,
  };
  try {
    if (ctx && ctx.settings && typeof ctx.settings.defineSchema === 'function') {
      try {
        for (const d of PEP_FIELD_DEFS) {
          const key = d[0];
          const codeVal = pepCurrentValue(key, d[2]);
          if (typeof codeVal === 'number' && isFinite(codeVal)) {
            try { await ctx.settings.set(key, codeVal); } catch (e) {}
          }
        }
      } catch (e) {}
      await ctx.settings.defineSchema(PEP_SETTINGS_SCHEMA);
      let initial = null;
      try { initial = await ctx.settings.getAll(); } catch (e) { initial = null; }
      if (initial && typeof initial === 'object') applyPepSettings(initial);
      if (log) log.info('PEP: settings panel registered (' + PEP_FIELD_DEFS.length + ' params)');
    } else if (log) {
      log.warn('PEP: ctx.settings unavailable, settings panel skipped');
    }
  } catch (e) {
    if (log) log.warn('PEP: settings register failed: ' + (e && e.message));
  }
  const pepSettingsTimer = setInterval(async () => {
    try {
      if (ctx && ctx.settings && typeof ctx.settings.getAll === 'function') {
        const all = await ctx.settings.getAll();
        applyPepSettings(all);
        if (all && typeof all === 'object') {
          for (const d of PEP_FIELD_DEFS) {
            const k = d[0];
            const v = all[k];
            if (typeof v === 'number' && isFinite(v)) {
              const clean = Math.round(v * 100) / 100;
              if (clean !== v) {
                try { await ctx.settings.set(k, clean); } catch (e) {}
              }
            }
          }
        }
      }
    } catch (e) {}
  }, 800);
  cleanups.push(() => { try { clearInterval(pepSettingsTimer); } catch (e) {} });
  const MICRO_FIELDS = PEP_FIELD_DEFS.filter((d) => {
    const step = d[4];
    return typeof step === 'number' && step < 1;
  });
  const PEP_MICRO_GROUP_DEFS = [
    ['通用', ['FULL_KILL_DROP_CHANCE', 'ELEMENT_CHANCE']],
    ['豌豆射手', ['PEASHOOTER_BURST_CHANCE']],
    ['双重射手', ['REPEATER_ATTR_CHANCE', 'REPEATER_ULT_BONUS']],
    ['三线射手', ['THREEPEATER_SKY_CHANCE']],
    ['向日葵', ['SUNFLOWER_EXTRA_CHANCE']],
    ['火焰射手', ['FIRE_BURST_CHANCE', 'FIRE_ULT_RAIN_BLUE_SHARE_3']],
    ['寒冰射手', ['SNOW_BURST_CHANCE', 'SNOW_ULT_ICICLE_SHARE_1', 'SNOW_ULT_ICICLE_SHARE_2', 'SNOW_ULT_ICICLE_SHARE_3']],
    ['裂荚射手', ['SPLITPEA_BURST_CHANCE', 'SPLITPEA_BACK_STRESS_ICE_CHANCE', 'SPLITPEA_BACK_STRESS_ICICLE_CHANCE', 'SPLITPEA_ULT_BACK_ICE_SHARE', 'SG_BACK_ICE_CHANCE', 'SG_BACK_ICE_ICICLE_SHARE', 'SG_ULT_BACK_ELEC_SHARE']],
    ['原始豌豆', ['PRIMAL_SPEED_BOOST_STEP']],
    ['毒液豌豆', ['GOO_BURST_CHANCE']],
    ['电能豌豆', ['ELECTRIC_BURST_CHANCE', 'ELECTRIC_ULT_RAIN_SMALL_SHARE']],
    ['大哥', ['MEGA_ATTR_CHANCE', 'MEGA_KILL_BONUS', 'MEGA_KILL_MAX']],
    ['暗影豌豆', ['SHADOW_BURST_CHANCE']],
    ['天空豌豆', ['SKY_BURST_CHANCE']],
    ['红宝石', ['RUBY_DOUBLE_CHANCE']],
  ];
  const PEP_MICRO_GROUP_OF = {};
  for (const g of PEP_MICRO_GROUP_DEFS) for (const k of g[1]) PEP_MICRO_GROUP_OF[k] = g[0];
  const pepShortLabel = (label) => String(label || '').replace(/^[^·]+·/, '');
  const currentModuleValue = (key) => {
    try {
      const map = {
        COUNT, INTERVAL_MS, ELEMENT_CHANCE,
        PEASHOOTER_BURST_CHANCE, FIRE_BURST_CHANCE, SNOW_BURST_CHANCE, SPLITPEA_BURST_CHANCE, GOO_BURST_CHANCE, ELECTRIC_BURST_CHANCE, SHADOW_BURST_CHANCE, SKY_BURST_CHANCE,
        PEAPOD_GROW_MS, PEAPOD_MAX_HEADS, PEAPOD_ULT_RAIN_CHANCE, PEAPOD_ULT_SMALL_PER_HEAD, PEAPOD_ULT_SMALL_HEAD_CAP, PEAPOD_ULT_SPLASH_DAMAGE, PEAPOD_ULT_SPLASH_RANGE_W, PEAPOD_ULT_SPLASH_RANGE_H,
        REPEATER_ATTR_CHANCE, REPEATER_FAVORED_WEIGHT, REPEATER_ULT_BONUS,
        THREEPEATER_EDGE_REDIRECT_DELAY_MS, THREEPEATER_HEAD_HEIGHT_DIFF, THREEPEATER_ULT_MAX_ANGLE, THREEPEATER_SKY_CHANCE, THREEPEATER_BLOW_FROM_ULT,
        SUNFLOWER_EXTRA_CHANCE, SUNFLOWER_EXTRA_SMALL, SUNFLOWER_EXTRA_MEDIUM,
        NUT_REGEN_DELAY, NUT_REGEN_RATE_1, NUT_REGEN_RATE_2, NUT_REGEN_TICK,
        FIRE_ULT_RAIN_CHANCE, FIRE_ULT_RAIN_COUNT, FIRE_ULT_SCATTER_SCALE, FIRE_ULT_RAIN_COUNT_3, FIRE_ULT_RAIN_BLUE_SHARE_3,
        SNOW_ULT_ICICLE_SHARE_1, SNOW_ULT_ICICLE_SHARE_2, SNOW_ULT_ICICLE_SHARE_3, SNOW_ULT_SCATTER_SCALE, SNOW_ULT_COUNT_3,
        SPLITPEA_BACK_STRESS_ICE_CHANCE, SPLITPEA_BACK_STRESS_ICICLE_CHANCE, SPLITPEA_BACK_COUNTER_COOLDOWN_MS, SPLITPEA_ULT_BACK_ICE_SHARE,
        PRIMAL_SPEED_BOOST_STEP, PRIMAL_ULT_EXTRA_SHOTS, PRIMAL_ULT_RAIN_CHANCE, PRIMAL_ULT_RAIN_COUNT, PRIMAL_ULT_RAIN_COUNT_3, PRIMAL_ULT_SCATTER_SCALE, PRIMAL_ULT_RAIN_SCALE, PRIMAL_ULT_RAIN_DAMAGE, PRIMAL_ULT_RAIN_SPLASH_DAMAGE, PRIMAL_ULT_RAIN_SPLASH_RANGE, PRIMAL_ULT_RAIN_KNOCKBACK, PRIMAL_ULT_RAIN_STUN,
        GOO_ULT_RAIN_CHANCE, GOO_ULT_RAIN_COUNT, GOO_ULT_SCATTER_SCALE, GOO_ULT_RAIN_COUNT_3,
        ELECTRIC_ULT_RAIN_CHANCE, ELECTRIC_ULT_RAIN_COUNT, ELECTRIC_ULT_SCATTER_SCALE, ELECTRIC_ULT_RAIN_COUNT_3, ELECTRIC_ULT_RAIN_SMALL_SHARE, ELECTRIC_ULT_MEGA_EXTRA,
        MEGA_ATTR_CHANCE, MEGA_KILL_BONUS, MEGA_KILL_MAX, MEGA_BURST_UNIFY_MS,
        SHADOW_ULT_RAIN_CHANCE, SHADOW_ULT_RAIN_COUNT, SHADOW_ULT_RAIN_COUNT_3, SHADOW_ULT_RAIN_DMG_SHADOW1, SHADOW_ULT_RAIN_DMG_SHADOW2, SHADOW_ULT_RAIN_PERFUME_SECONDS, SHADOW_BURST_PERFUME_SECONDS, SHADOW_ULT_RAIN_JITTER_SHADOW, SHADOW_ULT_RAIN_JITTER_NORMAL, SHADOW_ULT_RAIN_PEA_SCALE,
        SEA_ULT_LOCK_SEA_PEA, SEA_ULT_LOCK_SWIM,
        SKY_ULT_SCATTER_SCALE, SKY_ULT_COUNT_3,
        RAIN_SHOOT5_INTERVAL_MS, RAIN_SHOOT5_VOLUME,
        FULL_ULT_COUNT, FULL_LIGHT_SCALE, FULL_KILL_DROP_CHANCE,
        SG_SHOT_BOTH_F, SG_SHOT_BOTH_B, SG_SHOT_FRONT_ONLY, SG_SHOT_BACK_ONLY, SG_BACK_ARC_DEG, SG_BACK_ICE_CHANCE, SG_BACK_ICE_ICICLE_SHARE, SG_ULT_BACK_ELEC_SHARE,
        SHADOW_HARVEST_DAMAGE, SHADOW_HARVEST_RANGE, SHADOW_SHARD_COUNT, SHADOW_KILL_HP,
        RUBY_ULT_COUNT, RUBY_ULT_INTERVAL_MS, RUBY_DOUBLE_CHANCE, RUBY_ICE_BREAK_TARGET_DMG, RUBY_ICE_BREAK_SPLASH_DMG, RUBY_ICE_BREAK_SPLASH_W, RUBY_ICE_BREAK_SPLASH_H, RUBY_FIELD_ROW, RUBY_FIELD_SCAN_MS,
      };
      const v = map[key];
      return (typeof v === 'number' && isFinite(v)) ? v : null;
    } catch (e) { return null; }
  };
  const microAdjust = (key, delta, min, max) => async () => {
    try {
      if (!ctx || !ctx.settings || typeof ctx.settings.set !== 'function') return;
      let base = null;
      try { base = await ctx.settings.get(key); } catch (e) { base = null; }
      if (!(typeof base === 'number' && isFinite(base))) base = currentModuleValue(key);
      if (base === null) return;
      const v = Math.min(max, Math.max(min, Math.round((base + delta) * 100) / 100));
      await ctx.settings.set(key, v);
      if (log) log.info('PEP micro-adjust ' + key + ' -> ' + v);
      try { await rebuildMicroPanel(); } catch (e) {}
      try { updateMicroDisplayDOM(key, v); } catch (e) {}
    } catch (e) {}
  };
  const updateMicroDisplayDOM = (key, value) => {
    try {
      if (typeof document === 'undefined') return;
      const def = MICRO_FIELDS.find((d) => d[0] === key);
      if (!def) return;
      const short = pepShortLabel(def[1]);
      const groupTitle = PEP_MICRO_GROUP_OF[key] || '';
      const shown = String(Math.round(value * 100) / 100);
      const prefix = short + ': ';
      const sections = document.querySelectorAll('.gp-section');
      for (const sec of sections) {
        const titleEl = sec.querySelector('.gp-section-title');
        if (!titleEl) continue;
        const t = (titleEl.textContent || '').replace(/\s+/g, '');
        if (t.indexOf(groupTitle) === -1) continue;
        const mutes = sec.querySelectorAll('.gp-text-muted');
        for (const muted of mutes) {
          const txt = (muted.textContent || '');
          if (txt.indexOf(prefix) === 0) muted.textContent = prefix + shown;
        }
      }
    } catch (e) {}
  };
  const microCurrent = async (key) => {
    try {
      const v = await ctx.settings.get(key);
      if (typeof v === 'number' && isFinite(v)) return v;
    } catch (e) {}
    return currentModuleValue(key);
  };
  const rebuildMicroPanel = async () => {
    try {
      if (!ctx || !ctx.controls || typeof ctx.controls.definePanel !== 'function') return;
      const byKey = new Map(MICRO_FIELDS.map((d) => [d[0], d]));
      const buildFieldItems = async (key) => {
        const d = byKey.get(key);
        if (!d) return [];
        const [, label] = d;
        const min = d[2], max = d[3];
        const cur = await microCurrent(key);
        const shown = (typeof cur === 'number' && isFinite(cur)) ? String(Math.round(cur * 100) / 100) : '?';
        return [
          { type: 'readonly', key: key + '_val', label: pepShortLabel(label), value: shown },
          { type: 'action', key: key + '_minus', label: '−1%', onClick: microAdjust(key, -0.01, min, max) },
          { type: 'action', key: key + '_plus', label: '+1%', onClick: microAdjust(key, 0.01, min, max) },
        ];
      };
      const groups = [];
      for (const g of PEP_MICRO_GROUP_DEFS) {
        const items = [];
        for (const key of g[1]) items.push(...(await buildFieldItems(key)));
        if (items.length > 0) groups.push({ title: g[0], items });
      }
      const known = new Set(PEP_MICRO_GROUP_DEFS.flatMap((g) => g[1]));
      const extra = MICRO_FIELDS.filter((d) => !known.has(d[0]));
      if (extra.length > 0) {
        const items = [];
        for (const d of extra) items.push(...(await buildFieldItems(d[0])));
        groups.push({ title: '其它', items });
      }
      await ctx.controls.definePanel({
        title: 'PEP 植物参数微调(±1%)',
        description: '按植物折叠分组:组内每行是当前生效值,点 −1%/+1% 写回设置并自动生效;连续滑条在「设置 > 模组设置」',
        groups,
      });
      if (log) log.info('PEP: micro-adjust panel rebuilt (' + MICRO_FIELDS.length + ' params in ' + groups.length + ' groups)');
    } catch (e) {}
  };
  try {
    await rebuildMicroPanel();
  } catch (e) {
    if (log) log.warn('PEP: controls register failed: ' + (e && e.message));
  }
  {
    const PF_UPGRADE_KEYS = ['upgrade_starting_plantfood_lvl1', 'upgrade_starting_plantfood_lvl2'];
    let pepUpgradeInjected = false;
    const pepGetModule = (path) => {
      try { return engine && typeof engine.getSystemModule === 'function' ? engine.getSystemModule(path) : null; }
      catch (e) { return null; }
    };
    const pepGetUpgradeBoost = () => {
      try {
        const ap = pepGetModule('chunks:///_virtual/PlayerProperties.ts');
        const app = ap && (ap.AllPlayerProperties || ap.currentPlayer || null);
        const holder = (app && typeof app.getUpgradeProgressByID === 'function') ? app
          : (ap && typeof ap.getUpgradeProgressByID === 'function') ? ap : null;
        if (!holder) return 0;
        let boost = 0;
        for (let k = 0; k < PF_UPGRADE_KEYS.length; k++) {
          try {
            const pr = holder.getUpgradeProgressByID(PF_UPGRADE_KEYS[k]);
            if (pr && pr.progress > 0 && pr.enabled !== false) boost = Math.max(boost, k + 1);
          } catch (e) {}
        }
        return boost;
      } catch (e) { return 0; }
    };
    const pepDumpFeatures = (features) => {
      try {
        if (!features || !Array.isArray(features)) { pepDiag.feats = 'no-arr'; return; }
        const arr = [];
        for (let i = 0; i < features.length; i++) {
          const f = features[i];
          if (!f) { arr.push('#' + i + '=null'); continue; }
          const keys = [];
          try { for (const k in f) keys.push(k); } catch (e) {}
          const sn = f.SPRITENAME || f.spriteName || f.sprite || f.icon || '';
          const cn = f.CODENAME || f.codename || f.name || '';
          arr.push('#' + i + '{' + keys.join(',') + '} ' + String(cn) + '=>' + String(sn));
        }
        pepDiag.feats = arr.join(' | ');
      } catch (e) { pepDiag.feats = 'dump-err:' + (e && e.message); }
    };
    const pepInjectUpgrade = () => {
      try {
        if (pepUpgradeInjected) return true;
        pepDiag.t++;
        let enumObj = null;
        {
          const m = pepGetModule('chunks:///_virtual/Trophies.ts');
          if (m && m.UpgradeEnum) enumObj = m.UpgradeEnum;
          pepDiag.enum = enumObj ? 'ok' : 'missing';
        }
        let features = null;
        {
          const m = pepGetModule('chunks:///_virtual/Prizes.ts');
          const pr = m && (m.prizeRes || null);
          if (pr && pr.res && Array.isArray(pr.res.upgradeFeatures)) features = pr.res.upgradeFeatures;
          pepDiag.feat = features ? 'ok(' + features.length + ')' : (pr && pr.res ? 'no-arr' : 'no-res');
        }
        if (!enumObj || !features) return false;
        if (enumObj.upgrade_starting_plantfood_lvl1 !== undefined) {
          pepUpgradeInjected = true;
          try { pepDumpFeatures(features); } catch (e) {}
          return true;
        }
        const baseIdx = (typeof enumObj.amount === 'number') ? enumObj.amount : features.length;
        enumObj.upgrade_starting_plantfood_lvl1 = baseIdx;
        enumObj.upgrade_starting_plantfood_lvl2 = baseIdx + 1;
        enumObj[baseIdx] = 'upgrade_starting_plantfood_lvl1';
        enumObj[baseIdx + 1] = 'upgrade_starting_plantfood_lvl2';
        enumObj.amount = baseIdx + 2;
        features.push(
          { CODENAME: 'starting_plantfood_1', SPRITENAME: 'PlantfoodSlot', UPGRADETYPE: 'starting_plantfood' },
          { CODENAME: 'starting_plantfood_2', SPRITENAME: 'PlantfoodSlot', UPGRADETYPE: 'starting_plantfood' }
        );
        pepUpgradeInjected = true;
        if (log) log.info('PEP: starting-plantfood upgrade injected (idx ' + baseIdx + '+' + (baseIdx + 1) + ')');
        try { pepDumpFeatures(features); } catch (e) {}
        return true;
      } catch (e) {
        pepDiag.enum = 'err:' + (e && e.message);
        if (log) log.warn('PEP: upgrade inject failed: ' + (e && e.message));
        return false;
      }
    };
    let pepStoreTimer = null;
    try {
      pepStoreTimer = setInterval(() => {
        try {
          if (!pepInjectUpgrade()) return;
          let storeCls = null;
          try { storeCls = engine.getClassByName ? engine.getClassByName('Store') : null; } catch (e) { storeCls = null; }
          if (!storeCls) {
            const stMod = pepGetModule('chunks:///_virtual/Store.ts');
            storeCls = stMod && (stMod.Store || stMod.store || stMod.default || null);
          }
          const st = storeCls && storeCls.component ? storeCls.component : null;
          pepDiag.store = st ? 'ok' : ('no-comp' + (storeCls ? '' : '+no-cls'));
          if (!st || !st.commodityJson || !st.commodityJson.json) return;
          const ups = st.commodityJson.json.Upgrade;
          if (!Array.isArray(ups)) return;
          try {
            if (pepDiag.sample === undefined && ups.length > 0) {
              const s0 = ups[0];
              const keys = [];
              try { for (const k in s0) keys.push(k); } catch (e) {}
              pepDiag.sample = keys.join(',');
              pepDiag.sampleCount = ups.length;
            }
          } catch (e) {}
          if (ups.some((c) => c && PF_UPGRADE_KEYS.indexOf(c.CommodityName) !== -1)) {
            clearInterval(pepStoreTimer); pepStoreTimer = null;
            if (log) log.info('PEP: store upgrade commodities injected');
            return;
          }
          ups.push(
            { CommodityType: 'upgrade', CommodityName: PF_UPGRADE_KEYS[0], CommodityCount: 1, StackLevel: 0, CurrencyType: 'coin', CurrencyRequired: 3000, UnlockLevel: null, PlantWeekDiscount: void 0, CommodityDisplayName: null },
            { CommodityType: 'upgrade', CommodityName: PF_UPGRADE_KEYS[1], CommodityCount: 1, StackLevel: 0, CurrencyType: 'coin', CurrencyRequired: 3000, UnlockLevel: null, PlantWeekDiscount: void 0, CommodityDisplayName: null }
          );
          try {
            pepDiag.injectedCount = ups.length;
            const last = ups[ups.length - 1];
            const lk = [];
            try { for (const k in last) lk.push(k + '=' + String(last[k])); } catch (e) {}
            pepDiag.lastItem = lk.join(' | ');
          } catch (e) {}
          clearInterval(pepStoreTimer); pepStoreTimer = null;
          if (log) log.info('PEP: store upgrade commodities injected (2 x 3000 coin)');
        } catch (e) { pepDiag.store = 'err:' + (e && e.message); }
      }, 1000);
      cleanups.push(() => { try { if (pepStoreTimer) clearInterval(pepStoreTimer); } catch (e) {} });
    } catch (e) {}
    {
      const SC_MOD = 'chunks:///_virtual/StoreCommodity.ts';
      const pepGetProgressObj = (e) => {
        try {
          const ap = pepGetModule('chunks:///_virtual/PlayerProperties.ts');
          const holder = ap && (ap.AllPlayerProperties || ap.currentPlayer || null);
          const hh = (holder && typeof holder.getUpgradeProgressByID === 'function') ? holder
            : (ap && typeof ap.getUpgradeProgressByID === 'function') ? ap : null;
          if (!hh) return null;
          const t = e && e.CommodityType;
          if (t === 'upgrade') {
            try { return hh.getUpgradeProgressByID(e.CommodityName) || null; } catch (e2) { return null; }
          }
          if (t === 'plant') {
            try { return hh.getPlantProgressByID(e.CommodityName) || null; } catch (e2) { return null; }
          }
          return null;
        } catch (e2) { return null; }
      };
      const pepWrapReadCommodity = () => {
        try {
          const m = pepGetModule(SC_MOD);
          const cls = m && (m.StoreCommodity || m.default || null);
          if (!cls || !cls.prototype || typeof cls.prototype.readCommodity !== 'function') return false;
          if (cls.prototype.__pepReadWrapped) return true;
          const orig = cls.prototype.readCommodity;
          const myRead = function (e) {
            try {
              pepDiag.lastRender = (e ? (e.CommodityType || '?') + ':' + (e.CommodityName || '?') : 'null')
                + ' price=' + (e && e.CurrencyRequired != null ? String(e.CurrencyRequired) : '?');
            } catch (e4) {}
            if (e && PF_UPGRADE_KEYS.indexOf(e.CommodityName) !== -1) {
              try {
                this.currentCommodity = e;
                const lvl2 = e.CommodityName === PF_UPGRADE_KEYS[1];
                try { this.window.spriteFrame = this.upgradeWindow; } catch (e5) {}
                try { this.nameLabel.string = lvl2 ? '基础储备 II' : '基础储备'; } catch (e5) {}
                try { this.countLabel.string = ''; } catch (e5) {}
                try {
                  this.buyCoinIcon.node.active = true;
                  this.buyGemIcon.node.active = false;
                  this.buyTicketIcon.node.active = false;
                  this.buyButton.hoverSprite = this.buyButton.pressedSprite = this.coinButtonDown;
                  this.buyButton.disabledSprite = this.buyButton.normalSprite = this.coinButtonUp;
                } catch (e5) {}
                try { this.discountLabel.node.parent.active = false; } catch (e5) {}
                try { this.leftTimeLabel.node.parent.active = false; } catch (e5) {}
                let owned = false;
                try {
                  const ap = pepGetModule('chunks:///_virtual/PlayerProperties.ts');
                  const holder = ap && (ap.AllPlayerProperties || ap.currentPlayer || null);
                  const hh = (holder && typeof holder.getUpgradeProgressByID === 'function') ? holder
                    : (ap && typeof ap.getUpgradeProgressByID === 'function') ? ap : null;
                  if (hh) {
                    try {
                      const pr = hh.getUpgradeProgressByID(e.CommodityName);
                      owned = !!(pr && pr.progress > 0);
                    } catch (e6) {}
                  }
                } catch (e6) {}
                this.soldout = owned;
                try {
                  this.buyButtonLabel.string = owned ? '[已拥有]' : String(Math.floor(Number(e.CurrencyRequired) || 0));
                } catch (e5) {}
                try {
                  if (this.displaySlot) {
                    try { this.displaySlot.destroyAllChildren(); } catch (e7) {}
                    let node = null;
                    try {
                      const dpMod = pepGetModule('chunks:///_virtual/Droppings.ts');
                      const dp = dpMod && (dpMod.droppings || dpMod.default || dpMod);
                      const tpf = dp && dp.UpgradeTrophy ? dp.UpgradeTrophy : null;
                      if (tpf) {
                        const npMod = pepGetModule('chunks:///_virtual/NodePools.ts');
                        if (npMod && typeof npMod.instantiatePooly === 'function') node = npMod.instantiatePooly(tpf);
                      }
                    } catch (e7) {}
                    if (node) {
                      node.parent = this.displaySlot;
                      try { node.setPosition(0, 0, 0); } catch (e7) {}
                      try { node.setScale(1, 1, 1); } catch (e7) {}
                      try { node.setLayerWithAllChildren(this.displaySlot.layer); } catch (e7) {}
                      try {
                        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
                        const utCls = cc && cc.js && typeof cc.js.getClassByName === 'function'
                          ? cc.js.getClassByName('UpgradeTrophy') : null;
                        const comp = node.getComponent ? node.getComponent(utCls) : null;
                        if (comp && typeof comp.readID === 'function') {
                          let idx = -1;
                          try {
                            const prm = pepGetModule('chunks:///_virtual/Prizes.ts');
                            const pr = prm && (prm.prizeRes || null);
                            const fs = pr && pr.res && Array.isArray(pr.res.upgradeFeatures) ? pr.res.upgradeFeatures : null;
                            if (fs) for (let i = 0; i < fs.length; i++) {
                              try { if (fs[i] && fs[i].SPRITENAME === 'PlantfoodSlot') { idx = i; break; } } catch (e8) {}
                            }
                          } catch (e8) {}
                          comp.readID(idx >= 0 ? idx : 0, true);
                        }
                      } catch (e7) {}
                    } else {
                      this.displaySlot.active = false;
                    }
                  }
                } catch (e5) {}
                return Promise.resolve();
              } catch (e5) {
                return orig.call(this, e);
              }
            }
            const t = e && e.CommodityType;
            const isShowableOwned = (t === 'plant' || t === 'upgrade');
            let progObj = null, origProg = null, forceShow = false;
            if (isShowableOwned) {
              try {
                progObj = pepGetProgressObj(e);
                if (progObj && progObj.progress > 0) {
                  forceShow = true;
                  origProg = progObj.progress;
                  progObj.progress = 0; 
                }
              } catch (e2) {}
            }
            try {
              const r = orig.call(this, e);
              const fin = () => {
                try {
                  if (forceShow && progObj && origProg !== null) progObj.progress = origProg;
                  if (forceShow) {
                    this.soldout = true;
                    try { this.buyButtonLabel.string = '[已拥有]'; } catch (e3) {}
                  }
                } catch (e3) {}
              };
              if (r && typeof r.then === 'function') { try { return r.then(fin, fin); } catch (e3) { return r; } }
              fin();
              return r;
            } catch (e2) {
              if (forceShow && progObj && origProg !== null) { try { progObj.progress = origProg; } catch (e3) {} }
              return orig.call(this, e);
            }
          };
          cls.prototype.readCommodity = myRead;
          cls.prototype.__pepReadWrapped = true;
          cleanups.push(() => {
            try { if (cls.prototype.readCommodity === myRead) cls.prototype.readCommodity = orig; } catch (e) {}
            try { delete cls.prototype.__pepReadWrapped; } catch (e) {}
          });
          if (log) log.info('PEP: StoreCommodity.readCommodity wrapped (owned keep-show)');
          return true;
        } catch (e) { return false; }
      };
      let pepWrapTimer = null;
      try {
        pepWrapTimer = setInterval(() => {
          try {
            if (pepWrapReadCommodity()) {
              clearInterval(pepWrapTimer); pepWrapTimer = null;
              pepDiag.rc = 'ok';
            }
          } catch (e) {}
        }, 1000);
        cleanups.push(() => { try { if (pepWrapTimer) clearInterval(pepWrapTimer); } catch (e) {} });
      } catch (e) {}
    }
    {
      const AU_MOD = 'chunks:///_virtual/AlmanacUpgradePage.ts';
      const AUD_MOD = 'chunks:///_virtual/AlmanacUpgradeDisplay.ts';
      const pepUpgradeDisplayData = (key) => {
        const lvl2 = key === PF_UPGRADE_KEYS[1];
        return {
          name: lvl2 ? '基础储备 II' : '基础储备',
          desc: lvl2 ? '开局自带 2 颗能量豆' : '开局自带 1 颗能量豆',
          codename: lvl2 ? 'starting_plantfood_2' : 'starting_plantfood_1',
          spr: 'PlantfoodSlot',
          world: 'modern',
        };
      };
      const pepPutUpgradeTrophy = (slot) => {
        try {
          if (!slot || !slot.isValid) return;
          try { slot.destroyAllChildren(); } catch (e) {}
          let node = null;
          try {
            const npMod = pepGetModule('chunks:///_virtual/NodePools.ts');
            if (npMod && typeof npMod.instantiatePooly === 'function') node = npMod.instantiatePooly(npMod.UpgradeTrophy || null);
          } catch (e) {}
          if (!node) {
            try {
              const dpMod = pepGetModule('chunks:///_virtual/Droppings.ts');
              const dp = dpMod && (dpMod.droppings || dpMod.default || dpMod);
              const tpf = dp && dp.UpgradeTrophy ? dp.UpgradeTrophy : null;
              if (tpf) {
                const npMod = pepGetModule('chunks:///_virtual/NodePools.ts');
                if (npMod && typeof npMod.instantiatePooly === 'function') node = npMod.instantiatePooly(tpf);
              }
            } catch (e) {}
          }
          if (!node) { slot.active = false; return; }
          node.parent = slot;
          try { node.setPosition(0, 0, 0); } catch (e) {}
          try { node.setScale(1, 1, 1); } catch (e) {}
          try { node.setLayerWithAllChildren(slot.layer); } catch (e) {}
          try {
            const utCls = ccTrophyCls();
            const comp = node.getComponent ? node.getComponent(utCls) : null;
            if (comp && typeof comp.readID === 'function') {
              const idx = pepFindPlantfoodSlotIdx();
              comp.readID(idx >= 0 ? idx : 0, true);
            }
          } catch (e) {}
        } catch (e) {}
      };
      const pepFindPlantfoodSlotIdx = () => {
        try {
          const m = pepGetModule('chunks:///_virtual/Prizes.ts');
          const pr = m && (m.prizeRes || null);
          const fs = pr && pr.res && Array.isArray(pr.res.upgradeFeatures) ? pr.res.upgradeFeatures : null;
          if (fs) {
            for (let i = 0; i < fs.length; i++) {
              try { if (fs[i] && fs[i].SPRITENAME === 'PlantfoodSlot') return i; } catch (e) {}
            }
          }
        } catch (e) {}
        return -1;
      };
      const ccTrophyCls = () => {
        try {
          const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
          if (cc && cc.js && typeof cc.js.getClassByName === 'function') return cc.js.getClassByName('UpgradeTrophy');
          if (engine && typeof engine.getClassByName === 'function') return engine.getClassByName('UpgradeTrophy');
        } catch (e) {}
        return null;
      };
      const pepWrapSwitchUpgrade = () => {
        try {
          const m = pepGetModule(AUD_MOD);
          const cls = m && (m.AlmanacUpgradeDisplay || m.default || null);
          if (!cls || !cls.prototype || typeof cls.prototype.switchUpgrade !== 'function') return false;
          if (cls.prototype.__pepUpgWrapped) return true;
          const orig = cls.prototype.switchUpgrade;
          const mySwitch = function (e) {
            if (PF_UPGRADE_KEYS.indexOf(e) !== -1) {
              try {
                this.id_name = e;
                const d = pepUpgradeDisplayData(e);
                try { this.titleLabel.string = d.name; } catch (e2) {}
                try { this.descriptionLabel.string = d.desc; } catch (e2) {}
                try {
                  const ap = pepGetModule('chunks:///_virtual/PlayerProperties.ts');
                  const holder = ap && (ap.AllPlayerProperties || ap.currentPlayer || null);
                  const hh = (holder && typeof holder.getUpgradeProgressByID === 'function') ? holder
                    : (ap && typeof ap.getUpgradeProgressByID === 'function') ? ap : null;
                  const pr = hh ? hh.getUpgradeProgressByID(e) : null;
                  if (typeof this.readEnable === 'function') this.readEnable(pr);
                  const r = !!(pr && pr.progress > 0);
                  try { if (this.enableButtonLabel && this.enableButtonLabel.node) this.enableButtonLabel.node.parent.active = r; } catch (e2) {}
                } catch (e2) {}
                try {
                  const slot = this.displaySlot || this.trophy;
                  if (slot) pepPutUpgradeTrophy(slot);
                } catch (e2) {}
                return;
              } catch (e2) {  }
            }
            return orig.call(this, e);
          };
          cls.prototype.switchUpgrade = mySwitch;
          cls.prototype.__pepUpgWrapped = true;
          cleanups.push(() => {
            try { if (cls.prototype.switchUpgrade === mySwitch) cls.prototype.switchUpgrade = orig; } catch (e) {}
            try { delete cls.prototype.__pepUpgWrapped; } catch (e) {}
          });
          if (log) log.info('PEP: AlmanacUpgradeDisplay.switchUpgrade wrapped');
          return true;
        } catch (e) { return false; }
      };
      const pepWrapUpgradePageStart = () => {
        try {
          const m = pepGetModule(AU_MOD);
          const cls = m && (m.AlmanacUpgradePage || m.default || null);
          if (!cls || !cls.prototype || typeof cls.prototype.start !== 'function') return false;
          if (cls.prototype.__pepPageWrapped) return true;
          const orig = cls.prototype.start;
          const myStart = function (...args) {
            try { orig.apply(this, args); } catch (e) {}
            try {
              const npMod = pepGetModule('chunks:///_virtual/NodePools.ts');
              const inst = npMod && typeof npMod.instantiatePooly === 'function' ? npMod.instantiatePooly : null;
              const displayer = this.upgradeDisplayer;
              const parent = this.upgradeParent;
              const audMod = pepGetModule(AUD_MOD);
              const audCls = audMod && (audMod.AlmanacUpgradeDisplay || audMod.default || null);
              if (!inst || !displayer || !parent || !audCls) return;
              for (const key of PF_UPGRADE_KEYS) {
                try {
                  const r = inst(displayer);
                  if (!r) continue;
                  r.parent = parent;
                  const comp = r.getComponent(audCls);
                  if (comp && typeof comp.switchUpgrade === 'function') comp.switchUpgrade(key);
                } catch (e) {}
              }
              if (log) log.info('PEP: almanac upgrade page extra cards added');
            } catch (e) {}
          };
          cls.prototype.start = myStart;
          cls.prototype.__pepPageWrapped = true;
          cleanups.push(() => {
            try { if (cls.prototype.start === myStart) cls.prototype.start = orig; } catch (e) {}
            try { delete cls.prototype.__pepPageWrapped; } catch (e) {}
          });
          if (log) log.info('PEP: AlmanacUpgradePage.start wrapped');
          return true;
        } catch (e) { return false; }
      };
      let pepAlmanacTimer = null;
      try {
        pepAlmanacTimer = setInterval(() => {
          try {
            const a = pepWrapSwitchUpgrade();
            const b = pepWrapUpgradePageStart();
            if (a && b) {
              clearInterval(pepAlmanacTimer); pepAlmanacTimer = null;
              pepDiag.au = 'ok';
            }
          } catch (e) {}
        }, 1000);
        cleanups.push(() => { try { if (pepAlmanacTimer) clearInterval(pepAlmanacTimer); } catch (e) {} });
      } catch (e) {}
    }
    {
      let lcCls = null;
      try {
        const lcMod = pepGetModule('chunks:///_virtual/levelController.ts');
        for (const nm of ['LevelController', 'levelController', 'LevelPlay']) {
          const c = lcMod && lcMod[nm] ? lcMod[nm] : null;
          if (c && c.prototype && typeof c.prototype.gameStart === 'function') { lcCls = c; break; }
        }
        if (!lcCls) {
          for (const cn of ['LevelController', 'levelController', 'LevelPlay']) {
            try {
              const c = engine.getClassByName ? engine.getClassByName(cn) : null;
              if (c && c.prototype && typeof c.prototype.gameStart === 'function') { lcCls = c; break; }
            } catch (e) {}
          }
        }
        pepDiag.lc = lcCls ? 'ok' : 'missing';
      } catch (e) { pepDiag.lc = 'err'; }
      if (lcCls && lcCls.prototype.gameStart) {
        const prevGS = lcCls.prototype.gameStart;
        const myGameStart = function (...args) {
          try { prevGS.apply(this, args); } catch (e) {}
          try {
            const boost = pepGetUpgradeBoost();
            if (boost > 0) {
              const pfMod = pepGetModule('chunks:///_virtual/PlantFoodCount.ts');
              const pfCls = pfMod && (pfMod.PlantFoodCount || pfMod.plantFoodCount || pfMod.default || null);
              const pfc = pfCls && pfCls.component ? pfCls.component : null;
              pepDiag.pfc = pfc ? 'ok' : ('no-comp' + (pfCls ? '' : '+no-cls'));
              if (pfc && typeof pfc.setPlantFoodNum === 'function') {
                pfc.setPlantFoodNum(boost);
                if (log) log.info('PEP: starting plantfood -> ' + boost);
              }
            }
          } catch (e) { pepDiag.pfc = 'err:' + (e && e.message); }
        };
        lcCls.prototype.gameStart = myGameStart;
        cleanups.push(() => {
          try { if (lcCls && lcCls.prototype.gameStart === myGameStart) lcCls.prototype.gameStart = prevGS; } catch (e) {}
        });
      }
    }
    try {
      const diagWrite = async () => {
        try {
          if (ctx && ctx.settings && typeof ctx.settings.set === 'function') {
            await ctx.settings.set('__pep_diag__', {
              t: pepDiag.t, enum: pepDiag.enum, feat: pepDiag.feat,
              store: pepDiag.store, lc: pepDiag.lc, pfc: pepDiag.pfc, rc: pepDiag.rc, au: pepDiag.au, bw: pepDiag.bw,
              injected: pepUpgradeInjected,
              sample: pepDiag.sample || '', sampleCount: pepDiag.sampleCount || 0,
              lastItem: pepDiag.lastItem || '', lastRender: pepDiag.lastRender || '',
              feats: pepDiag.feats || '', export: pepDiag.export || '', elec: pepDiag.elec || '',
            });
          }
        } catch (e) {}
      };
      const t1 = setTimeout(() => { try { diagWrite(); } catch (e) {} }, 3000);
      const t2 = setTimeout(() => { try { diagWrite(); } catch (e) {} }, 10000);
      cleanups.push(() => { try { clearTimeout(t1); clearTimeout(t2); } catch (e) {} });
    } catch (e) {}
  }
  let shoot5Clip = null;      
  let shoot5Loaded = false;   
  const shoot5LoadCbs = [];   
  const getCc = () => { try { return engine && typeof engine.getCc === 'function' ? engine.getCc() : null; } catch (e) { return null; } };
  const tryLoadShoot5 = (cb) => {
    try {
      if (shoot5Clip) { if (cb) cb(shoot5Clip); return; }
      if (shoot5Loaded) { if (cb) shoot5LoadCbs.push(cb); return; }
      shoot5Loaded = true;
      if (cb) shoot5LoadCbs.push(cb);
      const am = getCc() && getCc().assetManager;
      if (!am) {
        if (log) log.warn('PEP: assetManager unavailable, rain sfx disabled');
        shoot5Loaded = false;
        const cbs = shoot5LoadCbs.splice(0);
        for (const c of cbs) { try { c(null); } catch (e2) {} }
        return;
      }
      const done = (clip) => {
        try {
          if (clip) {
            shoot5Clip = clip;
            if (log) log.info('PEP: shoot5 rain sfx loaded (' + (clip._duration || '?') + 's)');
          } else if (log) {
            log.warn('PEP: shoot5 rain sfx load failed');
          }
        } catch (e) {}
        const cbs = shoot5LoadCbs.splice(0);
        for (const c of cbs) { try { c(shoot5Clip); } catch (e2) {} }
      };
      try {
        const cached = (typeof am.getAssetByUuid === 'function' && am.getAssetByUuid(RAIN_SHOOT5_UUID))
          || (am.assets && am.assets.get && am.assets.get(RAIN_SHOOT5_UUID));
        if (cached) { done(cached); return; }
      } catch (e) {}
      if (typeof am.loadAny === 'function') {
        try { am.loadAny({ uuid: RAIN_SHOOT5_UUID }, (err, clip) => done(err ? null : clip)); }
        catch (e) { done(null); }
      } else {
        done(null);
      }
    } catch (e) {
      shoot5Loaded = false;
      if (cb) { try { cb(null); } catch (e3) {} }
    }
  };
  const getSoundPlayer = () => {
    try {
      const soundsMod = engine && typeof engine.getSystemModule === 'function'
        ? engine.getSystemModule('chunks:///_virtual/SoundRescourses.ts')
        : null;
      const sounds = soundsMod && soundsMod.sounds;
      if (sounds && typeof sounds.playOneShot === 'function' && sounds.sr) return sounds;
      return null;
    } catch (e) { return null; }
  };
  const startRainSfx = (self) => {
    try {
      tryLoadShoot5((clip) => {
        try {
          if (!clip || !self || self.dead || self.__gpnRainSfxStop) {
            fallbackRainSfx(self);
            return;
          }
          const sounds = getSoundPlayer();
          if (!sounds) {
            fallbackRainSfx(self);
            return;
          }
          let timer = null;
          const playOnce = () => {
            try {
              if (self.dead || self.__gpnRainSfxStop) { if (timer) clearInterval(timer); return; }
              sounds.playOneShot(clip, RAIN_SHOOT5_VOLUME, 0);
            } catch (e) {}
          };
          playOnce();
          timer = setInterval(playOnce, RAIN_SHOOT5_INTERVAL_MS);
          self.__gpnRainSfxTimer = timer;
          cleanups.push(() => { try { clearInterval(timer); } catch (e) {} });
        } catch (e) {}
      });
    } catch (e) {}
  };
  const fallbackRainSfx = (self) => {
    try {
      if (!self || self.dead || self.__gpnRainSfxStop) return;
      const snd = self.soundRes;
      if (!snd || typeof snd.playShoot !== 'function') return;
      let timer = null;
      const playOnce = () => {
        try {
          if (self.dead || self.__gpnRainSfxStop) { if (timer) clearInterval(timer); return; }
          snd.playShoot(0.8);
        } catch (e) {}
      };
      playOnce();
      timer = setInterval(playOnce, 120);
      self.__gpnRainSfxTimer = timer;
      cleanups.push(() => { try { clearInterval(timer); } catch (e) {} });
    } catch (e) {}
  };
  const stopRainSfx = (self) => {
    try {
      self.__gpnRainSfxStop = true;
      if (self.__gpnRainSfxTimer) { clearInterval(self.__gpnRainSfxTimer); self.__gpnRainSfxTimer = null; }
    } catch (e) {}
  };
  const activeTimers = new Set();
  cleanups.push(() => {
    try {
      for (const t of activeTimers) clearInterval(t);
      activeTimers.clear();
    } catch (e) {}
  });
  (function installPeashooterBurst() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('PeashooterPlant')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.error('PEP: PeashooterPlant class not found, peashooter burst skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shoot !== 'function' ||
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function' ||
      typeof proto.startShooting !== 'function'
    ) {
      if (log) log.error('PEP: required methods missing on PeashooterPlant, peashooter burst skipped');
      return;
    }
    const isBase = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const prevSpecialPlantFood = proto.specialPlantFood;
    const newSpecialPlantFood = function (...args) {
      try { if (isBase(this)) this.__gpnUlted = true; } catch (e) {}
      return prevSpecialPlantFood.apply(this, args);
    };
    const prevSpecialPlantOnEnable = proto.specialPlantOnEnable;
    const newSpecialPlantOnEnable = function (...args) {
      try {
        this.__gpnUlted = false;
        this.__gpnCycleBurst = false;
        this.__gpnCycleFired = 0;
      } catch (e) {}
      return prevSpecialPlantOnEnable.apply(this, args);
    };
    const prevStartShooting = proto.startShooting;
    const newStartShooting = function (...args) {
      try {
        if (isBase(this)) {
          if (this.__gpnUlted === true && PEASHOOTER_BURST_CHANCE > 0) {
            this.__gpnCycleBurst = Math.random() < PEASHOOTER_BURST_CHANCE;
          } else {
            this.__gpnCycleBurst = false;
          }
          this.__gpnCycleFired = 0;
        }
      } catch (e) {}
      return prevStartShooting.apply(this, args);
    };
    const prevShoot = proto._shoot;
    const activeTimers = new Set();
    const newShoot = function (...args) {
      const result = prevShoot.apply(this, args); 
      try {
        const isFoodShot = args[0] === true;
        if (!isBase(this) || isFoodShot || this.__gpnUlted !== true) return result;
        if (this.__gpnCycleBurst !== true) return result;
        if (this.__gpnCycleFired !== 0) return result;
        this.__gpnCycleFired = 1;
        const remain = Math.max(0, COUNT - 1);
        let n = 0;
        const timer = setInterval(() => {
          try {
            if (this.dead) { clearInterval(timer); activeTimers.delete(timer); return; }
          } catch (e) {}
          if (n >= remain) { clearInterval(timer); activeTimers.delete(timer); return; }
          try { prevShoot.apply(this, args); } catch (e) {}
          n++;
        }, INTERVAL_MS);
        activeTimers.add(timer);
      } catch (e) {}
      return result;
    };
    proto.specialPlantFood = newSpecialPlantFood;
    proto.specialPlantOnEnable = newSpecialPlantOnEnable;
    proto.startShooting = newStartShooting;
    proto._shoot = newShoot;
    cleanups.push(() => {
      try {
        for (const t of activeTimers) clearInterval(t);
        activeTimers.clear();
        if (proto._shoot === newShoot) proto._shoot = prevShoot;
        if (proto.startShooting === newStartShooting) proto.startShooting = prevStartShooting;
        if (proto.specialPlantFood === newSpecialPlantFood) proto.specialPlantFood = prevSpecialPlantFood;
        if (proto.specialPlantOnEnable === newSpecialPlantOnEnable) proto.specialPlantOnEnable = prevSpecialPlantOnEnable;
      } catch (e) {}
    });
    if (log) log.info('PEP [Peashooter] active: chance=' + PEASHOOTER_BURST_CHANCE + ' count=' + COUNT + ' interval=' + INTERVAL_MS + 'ms (ult-gated, per-cycle roll)');
  })();
  (function installPeaPodAll() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('PeaPodPlant')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: PeaPodPlant class not found, peapod features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto.specialPeashooterOnEnable !== 'function' ||
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPlantFoodEnd !== 'function' ||
      typeof proto.animationListener !== 'function' ||
      typeof proto.foodShooting !== 'function' ||
      typeof proto.onFoodLeftPeaCountDec !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on PeaPodPlant, peapod features skipped');
      return;
    }
    const isPeaPod = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const prevEnable = proto.specialPeashooterOnEnable;
    const growTimers = new Set();
    const newEnable = function (...args) {
      try {
        const old = this.__gpnPeapodTimer;
        if (old) { clearInterval(old); growTimers.delete(old); this.__gpnPeapodTimer = null; }
      } catch (e) {}
      const res = prevEnable.apply(this, args);
      try {
        const self = this;
        const stop = () => {
          try {
            const t = self.__gpnPeapodTimer;
            if (t) { clearInterval(t); growTimers.delete(t); self.__gpnPeapodTimer = null; }
          } catch (e) {}
        };
        const timer = setInterval(() => {
          try {
            if (self.dead || !self.plantInLnC || typeof self.plantInLnC.isInLawn !== 'function' || !self.plantInLnC.isInLawn()) {
              stop();
              return;
            }
            const hc = Number(self.headCount);
            if (!Number.isFinite(hc) || hc >= PEAPOD_MAX_HEADS) { stop(); return; }
            if (typeof self.replant !== 'function') { stop(); return; }
            self.replant(); 
          } catch (e) {
            stop();
          }
        }, PEAPOD_GROW_MS);
        self.__gpnPeapodTimer = timer;
        growTimers.add(timer);
      } catch (e) {}
      return res;
    };
    proto.specialPeashooterOnEnable = newEnable;
    let SplashDamage = null;
    let ccSize = null;
    try {
      const mProj = engine.getSystemModule('chunks:///_virtual/Projectiles.ts');
      const mShot = engine.getSystemModule('chunks:///_virtual/commonShot.ts');
      SplashDamage = (mProj && mProj.SplashDamage) || (mShot && mShot.SplashDamage) || null;
      const cc = engine.getCc ? engine.getCc() : null;
      ccSize = (cc && cc.Size) || null;
    } catch (e) { SplashDamage = null; ccSize = null; }
    if (!SplashDamage || !ccSize) {
      if (log) log.warn('PEP: SplashDamage/Size unavailable, splash ult falls back to normal big pea');
    }
    const prevPF = proto.specialPlantFood;
    const newPF = function (t) {
      try {
        if (isPeaPod(this) && !this.__gpnFusion) {
          if (PEAPOD_ULT_RAIN_CHANCE > 0 && Math.random() < PEAPOD_ULT_RAIN_CHANCE) {
            this.__gpnUltMode = 'small';
            this.__gpnRainSfxStop = false;
            this.__gpnSavedPFType = this._objdataOwn.PeaTypePlantfood;
            this._objdataOwn.PeaTypePlantfood = 'pea'; 
            this._objdataOwn.PlantfoodPeaCount =
              PEAPOD_ULT_SMALL_PER_HEAD * Math.min(Math.max(Number(this.headCount) || 1, 1), PEAPOD_ULT_SMALL_HEAD_CAP);
            this.fooding = true;
            this.shootCD = 1 / 0;
            startRainSfx(this);
            try { this.anmControl.playAnimation('FoodStart', 1, PEAPOD_ULT_SMALL_PREPARE_SPEED); } catch (e) {}
            try { this.soundRes.playFood(); } catch (e) {}
            const self = this;
            if (typeof this.scheduleOnce === 'function') {
              this.scheduleOnce(() => {
                try {
                  if (self.dead || self.__gpnUltMode !== 'small') return;
                  if (self.anmControl) self.anmControl.playAnimation('FoodShoot', 1 / 0);
                  self.foodShooting(); 
                } catch (err) {}
              }, PEAPOD_ULT_SMALL_PREPARE_SECONDS);
            } else {
              this.foodShooting();
            }
            return;
          }
          this.__gpnUltMode = 'splash';
          return prevPF.apply(this, arguments);
        }
      } catch (e) {}
      return prevPF.apply(this, arguments);
    };
    const prevPFEnd = proto.specialPlantFoodEnd;
    const newPFEnd = function (...args) {
      try {
        const wasSmall = this.__gpnUltMode === 'small';
        if (wasSmall && this.__gpnSavedPFType) {
          this._objdataOwn.PeaTypePlantfood = this.__gpnSavedPFType;
        }
        if (wasSmall) stopRainSfx(this);
        this.__gpnSavedPFType = null;
        this.__gpnUltMode = null;
        if (wasSmall && this.anmControl) {
          try { this.anmControl.playAnimation('FoodEnd', 1); } catch (e) {}
        }
      } catch (e) {}
      return prevPFEnd.apply(this, args);
    };
    const prevAnim = proto.animationListener;
    const newAnim = function (evt) {
      try {
        if (isPeaPod(this) && !this.__gpnFusion && evt && typeof evt.name === 'string') {
          const nm = evt.name;
          if (nm === 'toFoodShoot' && this.__gpnUltMode === 'small') return; 
          if (nm === 'ShootMega') {
            if (this.__gpnUltMode === 'small') return; 
            if (this.__gpnUltMode === 'splash') {
              const p = this._shoot(false, false, this._objdataOwn.PeaTypePlantfood);
              try { this.soundRes.playShootMegaPeapod(); } catch (e) {}
              if (p && typeof p.then === 'function') {
                p.then((pea) => {
                  try {
                    if (pea && typeof pea.setSplashDamages === 'function' && SplashDamage && ccSize) {
                      pea.setSplashDamages([new SplashDamage(
                        PEAPOD_ULT_SPLASH_DAMAGE,
                        new ccSize(PEAPOD_ULT_SPLASH_RANGE_W, PEAPOD_ULT_SPLASH_RANGE_H)
                      )]);
                    }
                  } catch (err) {}
                }).catch(() => {});
              }
              return;
            }
          }
        }
      } catch (e) {}
      return prevAnim.apply(this, arguments);
    };
    const prevOnDec = proto.onFoodLeftPeaCountDec;
    const newOnDec = function (t) {
      let moved = false;
      try {
        if (this.__gpnUltMode === 'small' && this.peaSpawnpoint && typeof this.peaSpawnpoint.getWorldPosition === 'function') {
          const p = this.peaSpawnpoint.getWorldPosition();
          this.peaSpawnpoint.setWorldPosition(p.x + PEAPOD_ULT_SMALL_SPAWN_FORWARD, p.y, p.z);
          moved = true;
        }
      } catch (e) {}
      let result;
      try {
        result = prevOnDec.apply(this, arguments);
      } finally {
        if (moved && this.peaSpawnpoint && typeof this.peaSpawnpoint.getWorldPosition === 'function') {
          try {
            const p = this.peaSpawnpoint.getWorldPosition();
            this.peaSpawnpoint.setWorldPosition(p.x - PEAPOD_ULT_SMALL_SPAWN_FORWARD, p.y, p.z);
          } catch (e2) {}
        }
      }
      return result;
    };
    proto.specialPlantFood = newPF;
    proto.specialPlantFoodEnd = newPFEnd;
    proto.animationListener = newAnim;
    proto.onFoodLeftPeaCountDec = newOnDec;
    cleanups.push(() => {
      try {
        for (const t of growTimers) clearInterval(t);
        growTimers.clear();
        if (proto.specialPeashooterOnEnable === newEnable) proto.specialPeashooterOnEnable = prevEnable;
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
        if (proto.specialPlantFoodEnd === newPFEnd) proto.specialPlantFoodEnd = prevPFEnd;
        if (proto.animationListener === newAnim) proto.animationListener = prevAnim;
        if (proto.onFoodLeftPeaCountDec === newOnDec) proto.onFoodLeftPeaCountDec = prevOnDec;
      } catch (e) {}
    });
    if (log) log.info('PEP [PeaPod] active: grow one head every ' + PEAPOD_GROW_MS + 'ms, max ' + PEAPOD_MAX_HEADS + ' heads; ult: ' + Math.round(PEAPOD_ULT_RAIN_CHANCE * 100) + '% small-pea rain (' + PEAPOD_ULT_SMALL_PER_HEAD + '/head, up to ' + PEAPOD_ULT_SMALL_HEAD_CAP + ' heads = max ' + (PEAPOD_ULT_SMALL_PER_HEAD * PEAPOD_ULT_SMALL_HEAD_CAP) + ' peas, 2s, hit sfx=PopSound, fwd=' + PEAPOD_ULT_SMALL_SPAWN_FORWARD + '), ' + Math.round((1 - PEAPOD_ULT_RAIN_CHANCE) * 100) + '% splash big pea (' + PEAPOD_ULT_SPLASH_DAMAGE + ' dmg ' + PEAPOD_ULT_SPLASH_RANGE_W + 'x' + PEAPOD_ULT_SPLASH_RANGE_H + ')');
  })();
  (function installRepeaterAttrPeas() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('RepeaterPlant')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: RepeaterPlant class not found, repeater attr peas skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shoot !== 'function' ||
      typeof proto.startShooting !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on RepeaterPlant, repeater attr peas skipped');
      return;
    }
    const isRepeater = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const ultLevel = (self) => {
      try { return Math.min(Math.max(Number(self.__gpnRepeaterUltCount) || 0, 0), 2); } catch (e) { return 0; }
    };
    const totalChance = (self) => {
      return REPEATER_ATTR_CHANCE + REPEATER_ULT_BONUS * ultLevel(self);
    };
    const favoredChance = (self) => {
      return REPEATER_ATTR_CHANCE * REPEATER_FAVORED_WEIGHT + REPEATER_ULT_BONUS * ultLevel(self);
    };
    const prevStartShooting = proto.startShooting;
    const newStartShooting = function (...args) {
      try {
        if (isRepeater(this) && !this.__gpnFusion) { 
          const pool = REPEATER_ATTR_POOL;
          const tc = totalChance(this);
          if (tc > 0 && pool.length > 0 && Math.random() < tc) {
            let chosen = null;
            const favored = this.__gpnRepeaterFavored;
            if (!favored) {
              chosen = pool[Math.floor(Math.random() * pool.length)];
              this.__gpnRepeaterFavored = chosen;
            } else {
              const fc = favoredChance(this);
              const others = pool.filter(t => t !== favored);
              if (Math.random() < fc / tc) {
                chosen = favored;
              } else {
                chosen = others.length ? others[Math.floor(Math.random() * others.length)] : favored;
              }
            }
            this.__gpnRepeaterCycleType = chosen;
            this.__gpnRepeaterCycle = true;
          } else {
            this.__gpnRepeaterCycle = false;
            this.__gpnRepeaterCycleType = null;
          }
        }
      } catch (e) {}
      return prevStartShooting.apply(this, args);
    };
    const prevShoot = proto._shoot;
    const newShoot = function (...args) {
      try {
        if (
          isRepeater(this) && !this.__gpnFusion &&
          this.__gpnRepeaterCycle === true && this.__gpnRepeaterCycleType &&
          this.fooding !== true && args[0] !== true 
        ) {
          const a = args.slice();
          a[2] = this.__gpnRepeaterCycleType; 
          return prevShoot.apply(this, a);
        }
      } catch (e) {}
      return prevShoot.apply(this, args);
    };
    const prevOnEnable = proto.specialPlantOnEnable;
    const newOnEnable = function (...args) {
      try {
        this.__gpnRepeaterFavored = null;
        this.__gpnRepeaterCycle = false;
        this.__gpnRepeaterCycleType = null;
        this.__gpnRepeaterUltCount = 0;
      } catch (e) {}
      return prevOnEnable.apply(this, args);
    };
    const prevPF = proto.specialPlantFood;
    const newPF = function (...args) {
      try {
        if (isRepeater(this) && !this.__gpnFusion) {
          this.__gpnRepeaterUltCount = Math.min((Number(this.__gpnRepeaterUltCount) || 0) + 1, 2);
        }
      } catch (e) {}
      return prevPF.apply(this, args);
    };
    proto.startShooting = newStartShooting;
    proto._shoot = newShoot;
    proto.specialPlantOnEnable = newOnEnable;
    proto.specialPlantFood = newPF;
    cleanups.push(() => {
      try {
        if (proto._shoot === newShoot) proto._shoot = prevShoot;
        if (proto.startShooting === newStartShooting) proto.startShooting = prevStartShooting;
        if (proto.specialPlantOnEnable === newOnEnable) proto.specialPlantOnEnable = prevOnEnable;
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
      } catch (e) {}
    });
    if (log) log.info('PEP [Repeater] active: attr chance=' + REPEATER_ATTR_CHANCE + ' (+' + REPEATER_ULT_BONUS + '/ult, max +' + (REPEATER_ULT_BONUS * 2) + '), favoredWeight=' + REPEATER_FAVORED_WEIGHT + ' pool=' + REPEATER_ATTR_POOL.join(',') + ' (first trigger gains weight + all ult bonus)');
  })();
  (function installThreePeaterAll() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? (engine.getClassByName('ThreePeater') || engine.getClassByName('ThreePeaterPlant'))
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: ThreePeaterPlant class not found, threepeater features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shoot3 !== 'function' ||
      typeof proto._shootPeaAnimation !== 'function' ||
      typeof proto.animationListener !== 'function' ||
      typeof proto.specialPlantFood !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on ThreePeaterPlant, threepeater features skipped');
      return;
    }
    let ccVec2 = null;
    try {
      const cc = engine.getCc ? engine.getCc() : null;
      ccVec2 = (cc && cc.Vec2) || null;
    } catch (e) { ccVec2 = null; }
    const isThreePeater = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const laneHasZombies = (lane) => {
      try {
        if (!lane) return false;
        return Array.isArray(lane.zombiePool()) && lane.zombiePool().length > 0;
      } catch (e) { return false; }
    };
    const targetE = (self, prefer) => {
      try {
        const lane = self.inLane;
        if (!lane) return 1;
        const upHas = laneHasZombies(lane.UpperLane);
        const midHas = laneHasZombies(lane);
        const downHas = laneHasZombies(lane.LowerLane);
        if (prefer === 0) return upHas ? 0 : (midHas ? 1 : (downHas ? 2 : 1));
        if (prefer === 2) return downHas ? 2 : (midHas ? 1 : (upHas ? 0 : 1));
        return 1;
      } catch (e) { return 1; }
    };
    const fireWithHeight = (self, e, heightOffset, delayMs, peaType) => {
      const fire = () => {
        try {
          if (self.dead || !self.inLane) return;
          const sp = self.peaSpawnpoint;
          let orig = null;
          if (sp && heightOffset !== 0 && typeof sp.getWorldPosition === 'function') {
            try {
              orig = sp.getWorldPosition();
              sp.setWorldPosition(orig.x, orig.y + heightOffset, orig.z);
            } catch (e) {}
          }
          self._shoot3(e, undefined, peaType);
          if (orig) {
            try { sp.setWorldPosition(orig.x, orig.y, orig.z); } catch (e2) {}
          }
        } catch (err) {}
      };
      if (delayMs > 0) setTimeout(fire, delayMs); else fire();
    };
    const skyPeaFor = (self) => {
      try {
        if ((Number(self.__gpnThreeUltCount) || 0) >= 1 && THREEPEATER_SKY_CHANCE > 0 && Math.random() < THREEPEATER_SKY_CHANCE) {
          return 'pea_sky';
        }
      } catch (e) {}
      return undefined;
    };
    const blowFlying = (self) => {
      try {
        const lane = self.inLane;
        if (!lane) return;
        const lanes = [lane];
        try { if (lane.UpperLane) lanes.push(lane.UpperLane); } catch (e) {}
        try { if (lane.LowerLane) lanes.push(lane.LowerLane); } catch (e) {}
        for (const ln of lanes) {
          try {
            const pools = [];
            if (typeof ln.zombiePool === 'function') { try { pools.push(ln.zombiePool()); } catch (e) {} }
            if (Array.isArray(ln.hypnoZombies)) pools.push(ln.hypnoZombies);
            for (const pool of pools) {
              if (!pool || !pool.length) continue;
              for (let i = 0; i < pool.length; i++) {
                const z = pool[i];
                try {
                  if (z && z.flying && !z.blew && typeof z.blowAway === 'function') {
                    z.blowAway();
                  }
                } catch (e) {}
              }
            }
          } catch (e) {}
        }
      } catch (e) {}
    };
    const fireHead = (self, evtName) => {
      try {
        const e = targetE(self, evtName === 'shootU' ? 0 : (evtName === 'shootD' ? 2 : 1));
        const defaultE = evtName === 'shootU' ? 0 : (evtName === 'shootD' ? 2 : 1);
        const delay = e !== defaultE ? THREEPEATER_EDGE_REDIRECT_DELAY_MS : 0;
        let h = 0;
        if (evtName === 'shootU') h = e !== 0 ? THREEPEATER_HEAD_HEIGHT_DIFF : 0;
        if (evtName === 'shootD') h = e !== 2 ? -THREEPEATER_HEAD_HEIGHT_DIFF : 0;
        fireWithHeight(self, e, h, delay, skyPeaFor(self));
      } catch (e) {}
    };
    const prevSPA = proto._shootPeaAnimation;
    const newSPA = function (...args) {
      try {
        if (isThreePeater(this) && !this.__gpnFusion && !this.objdataOwn.AlwaysShoots) {
          this.anmControl.playAnimation('Shoot111', 1, 0.1 * this._cdScale, Math.max(1 / this.shootCD, 1));
          return;
        }
      } catch (e) {}
      return prevSPA.apply(this, args);
    };
    const prevAnim = proto.animationListener;
    const newAnim = function (evt) {
      try {
        if (isThreePeater(this) && !this.__gpnFusion && this.inLane && evt && typeof evt.name === 'string') {
          const nm = evt.name;
          if (nm === 'shootU') { fireHead(this, 'shootU'); return; }
          if (nm === 'shootM') { this._shoot3(1, undefined, skyPeaFor(this)); return; }
          if (nm === 'shootD') { fireHead(this, 'shootD'); return; }
        }
      } catch (e) {}
      return prevAnim.apply(this, arguments);
    };
    const prevPF = proto.specialPlantFood;
    const newPF = function () {
      try {
        if (isThreePeater(this) && !this.__gpnFusion) {
          const t = this;
          t.__gpnThreeUltCount = (Number(t.__gpnThreeUltCount) || 0) + 1;
          if ((Number(t.__gpnThreeUltCount) || 0) >= THREEPEATER_BLOW_FROM_ULT) {
            try { blowFlying(t); } catch (e) {}
          }
          const e = Number(this._objdataOwn.PlantfoodPeaCount) || 30;
          t.anmControl.playAnimation('Food', 1 / 0);
          try { t.soundRes.playFood(); } catch (err) {}
          t.shootCD = 1 / 0;
          let o = 0;
          const HALF_PI = Math.PI / 2;
          t.schedule(() => {
            try {
              const n = 2 * HALF_PI * (e / 2 - Math.abs((o % e) - e / 2)) / e; 
              const n2 = (n / HALF_PI) * THREEPEATER_ULT_MAX_ANGLE;            
              const dx = 8 * Math.cos(n2);
              const dy = 8 * Math.sin(n2);
              t._shoot3(3, new ccVec2(dx, dy), t._objdataOwn.PeaTypePlantfood);   
              t._shoot3(3, new ccVec2(dx, -dy), t._objdataOwn.PeaTypePlantfood);  
              t._shoot3(3, new ccVec2(8, 0), t._objdataOwn.PeaTypePlantfood);     
              ++o > e && t.foodEnd();
            } catch (err) {
              if (++o > e && t && typeof t.foodEnd === 'function') t.foodEnd();
            }
          }, 2 / e, e, 0.01);
          return;
        }
      } catch (err) {}
      return prevPF.apply(this, arguments);
    };
    proto._shootPeaAnimation = newSPA;
    proto.animationListener = newAnim;
    if (ccVec2) proto.specialPlantFood = newPF;
    const prevOE = proto.specialPlantOnEnable;
    if (typeof prevOE === 'function') {
      const newOE = function (...args) {
        try {
          this.__gpnThreeUltCount = 0;
        } catch (e) {}
        return prevOE.apply(this, args);
      };
      proto.specialPlantOnEnable = newOE;
      cleanups.push(() => {
        try {
          if (proto.specialPlantOnEnable === newOE) proto.specialPlantOnEnable = prevOE;
        } catch (e) {}
      });
    }
    cleanups.push(() => {
      try {
        if (proto._shootPeaAnimation === newSPA) proto._shootPeaAnimation = prevSPA;
        if (proto.animationListener === newAnim) proto.animationListener = prevAnim;
        if (ccVec2 && proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
      } catch (e) {}
    });
    if (log) log.info('PEP [ThreePeater] active: full 3-head anim, smart aim (flex lane targeting + redirect delay ' + THREEPEATER_EDGE_REDIRECT_DELAY_MS + 'ms)' + (ccVec2 ? ', ult fan triangle 0->' + THREEPEATER_ULT_MAX_ANGLE + '->0' : ' (cc.Vec2 unavailable, ult tighten skipped)') + ', sky chance=' + THREEPEATER_SKY_CHANCE + ', blow flying from ult ' + THREEPEATER_BLOW_FROM_ULT);
  })();
  (function installSunflowerUltBoost() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('Sunflower')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: Sunflower class not found, sunflower ult boost skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._produce !== 'function' ||
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on Sunflower, sunflower ult boost skipped');
      return;
    }
    let sunflowerStatic = null;
    let plantsMod = null;
    try {
      const m = engine.getSystemModule('chunks:///_virtual/Sunflower.ts');
      sunflowerStatic = (m && m.sunflower) || null;
      plantsMod = engine.getSystemModule('chunks:///_virtual/Plants.ts');
    } catch (e) { sunflowerStatic = null; plantsMod = null; }
    if (!sunflowerStatic || typeof sunflowerStatic.produceSun !== 'function') {
      if (log) log.warn('PEP: sunflower.produceSun unavailable, sunflower ult boost skipped');
      return;
    }
    const isSunflowerFamily = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const getCodename = (self) => {
      try {
        const en = plantsMod && plantsMod.PlantEnum;
        const id = Number(self.ID);
        return (en && Number.isFinite(id)) ? en[id] : null;
      } catch (e) { return null; }
    };
    const spawnExtraSun = (self, value) => {
      try {
        const h = self.sunSpawnpoint && self.sunSpawnpoint.worldPosition
          ? self.sunSpawnpoint.worldPosition.y - (Number(self.worldPositionY) || 0)
          : 0;
        const buffed = !!(self.plantInLnC && self.plantInLnC.ShineVineBuffed === true);
        sunflowerStatic.produceSun(value, self.worldPosition, h, true, false, buffed);
      } catch (e) {}
    };
    const prevPF = proto.specialPlantFood;
    const newPF = function () {
      try {
        if (isSunflowerFamily(this) && !this.__gpnFusion) {
          this.__gpnUltCount = Math.min((Number(this.__gpnUltCount) || 0) + 1, 3);
        }
      } catch (e) {}
      return prevPF.apply(this, arguments);
    };
    const prevOnEnable = proto.specialPlantOnEnable;
    const newOnEnable = function (...args) {
      try { if (isSunflowerFamily(this)) this.__gpnUltCount = 0; } catch (e) {}
      return prevOnEnable.apply(this, args);
    };
    const prevProduce = proto._produce;
    const newProduce = function (n) {
      const result = prevProduce.apply(this, arguments);
      try {
        if (!isSunflowerFamily(this) || this.__gpnFusion) return result;
        if (this.fooding === true || this.coinProducer === true) return result; 
        const count = Number(this.__gpnUltCount) || 0;
        if (count <= 0) return result;
        const code = getCodename(this);
        const mult = code === 'TwinSunflower' ? 2 : 1; 
        const value = count >= 3 ? SUNFLOWER_EXTRA_MEDIUM : SUNFLOWER_EXTRA_SMALL;
        const chance = count >= 2 ? 1 : SUNFLOWER_EXTRA_CHANCE; 
        if (Math.random() < chance) {
          for (let k = 0; k < mult; k++) spawnExtraSun(this, value);
        }
      } catch (e) {}
      return result;
    };
    proto.specialPlantFood = newPF;
    proto.specialPlantOnEnable = newOnEnable;
    proto._produce = newProduce;
    cleanups.push(() => {
      try {
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
        if (proto.specialPlantOnEnable === newOnEnable) proto.specialPlantOnEnable = prevOnEnable;
        if (proto._produce === newProduce) proto._produce = prevProduce;
      } catch (e) {}
    });
    if (log) log.info('PEP [Sunflower] active: 1ult 50% extra ' + SUNFLOWER_EXTRA_SMALL + ', 2ult always extra, 3ult extra ' + SUNFLOWER_EXTRA_MEDIUM + ', twin x2');
  })();
  (function installNutRegen() {
    const getCls = (name) => engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName(name)
      : null;
    const wCls = getCls('WallNutPlant');
    const tCls = getCls('TallNutPlant');
    const pCls = getCls('PrimalWallNutPlant');
    if (!wCls || !wCls.prototype || !tCls || !tCls.prototype) {
      if (log) log.warn('PEP: WallNutPlant/TallNutPlant class not found, nut regen skipped');
      return;
    }
    const wProto = wCls.prototype;
    const tProto = tCls.prototype;
    const pProto = pCls && pCls.prototype ? pCls.prototype : null;
    if (
      typeof wProto.specialPlantFood !== 'function' ||
      typeof wProto.dealNormalDamage !== 'function' ||
      typeof wProto.normalSmash !== 'function' ||
      typeof wProto.specialPlantOnEnable !== 'function' ||
      typeof tProto.specialPlantFood !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on nut classes, nut regen skipped');
      return;
    }
    if (!pProto || typeof pProto.normalSmash !== 'function') {
      if (log) log.warn('PEP: PrimalWallNutPlant not found, primal wallnut excluded from regen');
    }
    const isNut = (self) => {
      try {
        const p = Object.getPrototypeOf(self);
        return p === wProto || p === tProto || (pProto !== null && p === pProto);
      } catch (e) { return false; }
    };
    const refreshVisual = (self) => {
      try {
        if (self.dead || typeof self.setAnimation !== 'function') return;
        const max = Number(self.toughness);
        const hp = Number(self.health);
        if (!(max > 0) || !(hp > 0)) return;
        const stages = Object.getPrototypeOf(self) === tProto ? 3 : 4;
        for (let e = 1; e <= stages; e++) {
          if (hp <= (max / stages) * e) { self.setAnimation(stages - e); return; }
        }
        self.setAnimation(0);
      } catch (e) {}
    };
    const stopRegen = (self) => {
      try {
        if (self.__gpnNutRegenOn) {
          if (self.__gpnNutRegenCb && typeof self.unschedule === 'function') self.unschedule(self.__gpnNutRegenCb);
          self.__gpnNutRegenCb = null;
          self.__gpnNutRegenOn = false;
        }
      } catch (e) {}
    };
    const clearCheck = (self) => {
      try {
        if (self.__gpnNutCheckCb && typeof self.unschedule === 'function') self.unschedule(self.__gpnNutCheckCb);
        self.__gpnNutCheckCb = null;
      } catch (e) {}
    };
    const startCheck = (self) => {
      clearCheck(self);
      try {
        const ult = Number(self.__gpnNutUlt) || 0;
        if (ult <= 0 || self.dead) return;
        const cb = () => {
          self.__gpnNutCheckCb = null;
          try {
            if (self.dead) return;
            if (Number(self.health) >= Number(self.toughness)) return;
            self.__gpnNutRegenOn = true;
            const rate = ult >= 2 ? NUT_REGEN_RATE_2 : NUT_REGEN_RATE_1;
            const tick = () => {
              try {
                if (self.dead || !self.__gpnNutRegenOn) { stopRegen(self); return; }
                const max = Number(self.toughness);
                let h = Number(self.health);
                h = Math.min(h + rate * NUT_REGEN_TICK, max); 
                self.health = h;
                refreshVisual(self); 
                if (h >= max) stopRegen(self);
              } catch (e) { stopRegen(self); }
            };
            self.__gpnNutRegenCb = tick;
            self.schedule(tick, NUT_REGEN_TICK);
          } catch (e) {}
        };
        self.__gpnNutCheckCb = cb;
        self.scheduleOnce(cb, NUT_REGEN_DELAY);
      } catch (e) {}
    };
    const onNutDamage = (self) => {
      stopRegen(self);     
      startCheck(self);    
    };
    const wrapUlt = (proto) => {
      const prev = proto.specialPlantFood;
      const next = function () {
        try {
          if (isNut(this) && !this.__gpnFusion) {
            this.__gpnNutUlt = Math.min((Number(this.__gpnNutUlt) || 0) + 1, 2);
            stopRegen(this);
            startCheck(this);
          }
        } catch (e) {}
        return prev.apply(this, arguments);
      };
      proto.specialPlantFood = next;
      return { prev, next };
    };
    const wUlt = wrapUlt(wProto);
    const tUlt = wrapUlt(tProto);
    const prevDmg = wProto.dealNormalDamage;
    const newDmg = function (t, n) {
      const r = prevDmg.apply(this, arguments);
      try { if (isNut(this) && !this.__gpnFusion) onNutDamage(this); } catch (e) {}
      return r;
    };
    const prevSmash = wProto.normalSmash;
    const newSmash = function (t) {
      const r = prevSmash.apply(this, arguments);
      try { if (isNut(this) && !this.__gpnFusion) onNutDamage(this); } catch (e) {}
      return r;
    };
    const pPrevSmash = pProto && typeof pProto.normalSmash === 'function' ? pProto.normalSmash : null;
    const pNewSmash = pPrevSmash ? function (t) {
      const r = pPrevSmash.apply(this, arguments);
      try { if (isNut(this) && !this.__gpnFusion) onNutDamage(this); } catch (e) {}
      return r;
    } : null;
    const prevOnEnable = wProto.specialPlantOnEnable;
    const newOnEnable = function (...args) {
      try {
        if (isNut(this)) {
          stopRegen(this);
          clearCheck(this);
          this.__gpnNutUlt = 0;
        }
      } catch (e) {}
      return prevOnEnable.apply(this, args);
    };
    wProto.dealNormalDamage = newDmg;
    wProto.normalSmash = newSmash;
    wProto.specialPlantOnEnable = newOnEnable;
    if (pProto && pNewSmash) pProto.normalSmash = pNewSmash;
    cleanups.push(() => {
      try {
        if (wProto.specialPlantFood === wUlt.next) wProto.specialPlantFood = wUlt.prev;
        if (tProto.specialPlantFood === tUlt.next) tProto.specialPlantFood = tUlt.prev;
        if (wProto.dealNormalDamage === newDmg) wProto.dealNormalDamage = prevDmg;
        if (wProto.normalSmash === newSmash) wProto.normalSmash = prevSmash;
        if (wProto.specialPlantOnEnable === newOnEnable) wProto.specialPlantOnEnable = prevOnEnable;
        if (pProto && pNewSmash && pProto.normalSmash === pNewSmash) pProto.normalSmash = pPrevSmash;
      } catch (e) {}
    });
    if (log) log.info('PEP [Nut] active: regen after ' + NUT_REGEN_DELAY + 's no damage, ' + NUT_REGEN_RATE_1 + '/' + NUT_REGEN_RATE_2 + ' HP/s (1/2 ults), body-only, clamp at max, visual refresh on heal, primal wallnut included');
  })();
  (function installFirePeashooter() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('FirePeashooterPlant')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: FirePeashooterPlant class not found, fire peashooter features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shoot !== 'function' ||
      typeof proto.startShooting !== 'function' ||
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on FirePeashooterPlant, fire peashooter features skipped');
      return;
    }
    const isSelf = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const prevPF = proto.specialPlantFood;
    const newPF = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          this.__gpnUlted = true;
          this.__gpnCycleBurst = false;
          this.__gpnCycleFired = 0;
          this.__gpnFireUltCount = (Number(this.__gpnFireUltCount) || 0) + 1;
          if (FIRE_ULT_RAIN_CHANCE > 0 && Math.random() < FIRE_ULT_RAIN_CHANCE) {
            this.__gpnFireUltMode = 'rain';
            this.__gpnRainSfxStop = false;
            this.__gpnSavedPFType = this._objdataOwn.PeaTypePlantfood;
            this._objdataOwn.PeaTypePlantfood = FIRE_ULT_RAIN_PEA;
            this.fooding = true;
            startRainSfx(this);
            this.foodStarted = false;
            this.foodCountDown = 0;
            try { this.anmControl.playAnimation('FoodStart', 1, FIRE_ULT_RAIN_PREPARE_SPEED); } catch (e) {}
            try { this.soundRes.playFood(); } catch (e) {}
            const stage3 = (Number(this.__gpnFireUltCount) || 0) >= 3;
            const fireRainPea = (self2, s3) => {
              try {
                const peaType = s3 && FIRE_ULT_RAIN_BLUE_SHARE_3 > 0 && Math.random() < FIRE_ULT_RAIN_BLUE_SHARE_3 ? 'pea_flame_blue' : FIRE_ULT_RAIN_PEA;
                let angle = null;
                if (s3 && FIRE_ULT_SCATTER_SCALE > 0 && MEGA_ULT_SPREAD_ANGLES && MEGA_ULT_SPREAD_ANGLES.length) {
                  angle = MEGA_ULT_SPREAD_ANGLES[(self2.__gpnFireSpreadCursor || 0) % MEGA_ULT_SPREAD_ANGLES.length] * FIRE_ULT_SCATTER_SCALE;
                  self2.__gpnFireSpreadCursor = (self2.__gpnFireSpreadCursor || 0) + 1;
                }
                const p = self2._shoot(true, true, peaType);
                if (angle != null) {
                  const apply = (pea) => { try { if (pea && pea.linearVelocity && typeof pea.linearVelocity.x === 'number') pea.linearVelocity.y = pea.linearVelocity.x * angle; } catch (e) {} };
                  if (p && typeof p.then === 'function') p.then(apply, () => {}); else apply(p);
                }
              } catch (e) {}
            };
            const self = this;
            if (typeof this.scheduleOnce === 'function') {
              this.scheduleOnce(() => {
                try {
                  if (self.dead || self.__gpnFireUltMode !== 'rain') return;
                  if (self.anmControl) self.anmControl.playAnimation('Shoot', 1 / 0, 0, FIRE_ULT_RAIN_SHOOT_SPEED); 
                  const total = Math.max(1, Math.floor(Number(stage3 ? FIRE_ULT_RAIN_COUNT_3 : FIRE_ULT_RAIN_COUNT) || 1));
                  const step = Math.max(16, Math.floor(2000 / total)); 
                  let fired = 0;
                  const timer = setInterval(() => {
                    try {
                      if (self.dead || self.__gpnFireUltMode !== 'rain') {
                        clearInterval(timer); activeTimers.delete(timer);
                        try { if (typeof self.foodEnd === 'function') self.foodEnd(); } catch (e) {}
                        return;
                      }
                    } catch (e) {}
                    if (fired >= total) {
                      clearInterval(timer); activeTimers.delete(timer);
                      try { if (typeof self.foodEnd === 'function') self.foodEnd(); } catch (e) {}
                      return;
                    }
                    fireRainPea(self, stage3);
                    fired++;
                  }, step);
                  activeTimers.add(timer);
                } catch (err) {}
              }, FIRE_ULT_RAIN_PREPARE_SECONDS);
            } else {
              const total = Math.max(1, Math.floor(Number(stage3 ? FIRE_ULT_RAIN_COUNT_3 : FIRE_ULT_RAIN_COUNT) || 1));
              for (let i = 0; i < total; i++) { fireRainPea(this, stage3); }
              try { if (typeof this.foodEnd === 'function') this.foodEnd(); } catch (e) {}
            }
            return;
          }
        }
      } catch (e) {}
      return prevPF.apply(this, args);
    };
    const prevPFEnd = proto.specialPlantFoodEnd;
    const newPFEnd = function (...args) {
      try {
        if (this.__gpnFireUltMode === 'rain') {
          if (this.__gpnSavedPFType != null) this._objdataOwn.PeaTypePlantfood = this.__gpnSavedPFType;
          this.__gpnSavedPFType = null;
          this.__gpnFireUltMode = null;
          stopRainSfx(this);
        }
      } catch (e) {}
      return prevPFEnd.apply(this, args);
    };
    const prevSAL = proto.specialPeashooterAnimationListener;
    const newSAL = function (evt) {
      try {
        if (this.__gpnFireUltMode === 'rain' && evt && evt.name === 'playFooding') return;
      } catch (e) {}
      return prevSAL.apply(this, arguments);
    };
    const prevSPU = proto.specialPeashooterUpdate;
    const newSPU = function (dt) {
      try {
        if (this.__gpnFireUltMode === 'rain') return;
      } catch (e) {}
      return prevSPU.apply(this, arguments);
    };
    const prevOE = proto.specialPlantOnEnable;
    const newOE = function (...args) {
      try {
        this.__gpnUlted = false;
        this.__gpnCycleBurst = false;
        this.__gpnCycleFired = 0;
        this.__gpnFireUltCount = 0;
        this.__gpnFireSpreadCursor = 0;
        this.__gpnFireUltMode = null;
        this.__gpnSavedPFType = null;
        stopRainSfx(this);
      } catch (e) {}
      return prevOE.apply(this, args);
    };
    const prevStart = proto.startShooting;
    const newStart = function (...args) {
      try {
        if (isSelf(this)) {
          if (this.__gpnUlted === true && FIRE_BURST_CHANCE > 0) {
            this.__gpnCycleBurst = Math.random() < FIRE_BURST_CHANCE;
          } else {
            this.__gpnCycleBurst = false;
          }
          this.__gpnCycleFired = 0;
        }
      } catch (e) {}
      return prevStart.apply(this, args);
    };
    const prevShoot = proto._shoot;
    const newShoot = function (...args) {
      const isFoodShot = args[0] === true;
      let useEnhanced = false;
      try {
        if (isSelf(this) && !this.__gpnFusion && !isFoodShot) {
          if (this.__gpnUlted === true) {
            useEnhanced = this.__gpnCycleBurst === true;
          } else {
            useEnhanced = ELEMENT_CHANCE > 0 && Math.random() < ELEMENT_CHANCE;
          }
        }
      } catch (e) {}
      const fireArgs = args.slice();
      if (useEnhanced) fireArgs[2] = FIRE_ENHANCED_PEA; 
      const result = prevShoot.apply(this, fireArgs);
      try {
        if (
          isSelf(this) && !this.__gpnFusion && !isFoodShot &&
          this.__gpnUlted === true && this.__gpnCycleBurst === true &&
          this.__gpnCycleFired === 0
        ) {
          this.__gpnCycleFired = 1;
          const remain = Math.max(0, COUNT - 1);
          let n = 0;
          const timer = setInterval(() => {
            try {
              if (this.dead) { clearInterval(timer); activeTimers.delete(timer); return; }
            } catch (e) {}
            if (n >= remain) { clearInterval(timer); activeTimers.delete(timer); return; }
            try { prevShoot.apply(this, fireArgs); } catch (e) {}
            n++;
          }, INTERVAL_MS);
          activeTimers.add(timer);
        }
      } catch (e) {}
      return result;
    };
    proto.specialPlantFood = newPF;
    proto.specialPlantOnEnable = newOE;
    proto.startShooting = newStart;
    proto._shoot = newShoot;
    proto.specialPlantFoodEnd = newPFEnd;
    proto.specialPeashooterAnimationListener = newSAL;
    proto.specialPeashooterUpdate = newSPU;
    cleanups.push(() => {
      try {
        for (const tm of activeTimers) clearInterval(tm);
        activeTimers.clear();
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
        if (proto.specialPlantOnEnable === newOE) proto.specialPlantOnEnable = prevOE;
        if (proto.startShooting === newStart) proto.startShooting = prevStart;
        if (proto._shoot === newShoot) proto._shoot = prevShoot;
        if (proto.specialPlantFoodEnd === newPFEnd) proto.specialPlantFoodEnd = prevPFEnd;
        if (proto.specialPeashooterAnimationListener === newSAL) proto.specialPeashooterAnimationListener = prevSAL;
        if (proto.specialPeashooterUpdate === newSPU) proto.specialPeashooterUpdate = prevSPU;
      } catch (e) {}
    });
    if (log) log.info('PEP [FirePeashooter] active: normal chance=' + ELEMENT_CHANCE + ' enhanced=' + FIRE_ENHANCED_PEA + ' (native type), ult burst chance=' + FIRE_BURST_CHANCE + ' count=' + COUNT + ' interval=' + INTERVAL_MS + 'ms, ult dual: rain=' + FIRE_ULT_RAIN_CHANCE + ' peas=' + FIRE_ULT_RAIN_COUNT + ' (hit sfx=PopSound), 3rd+ rain scatter=' + FIRE_ULT_SCATTER_SCALE + ' count=' + FIRE_ULT_RAIN_COUNT_3 + ' blue-share=' + FIRE_ULT_RAIN_BLUE_SHARE_3);
  })();
  (function installSnowPea() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('SnowPeaPlant')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: SnowPeaPlant class not found, snow pea features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shoot !== 'function' ||
      typeof proto.startShooting !== 'function' ||
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPlantFoodEnd !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on SnowPeaPlant, snow pea features skipped');
      return;
    }
    const isSelf = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const prevPF = proto.specialPlantFood;
    const newPF = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          this.__gpnUlted = true;
          this.__gpnCycleBurst = false;
          this.__gpnCycleFired = 0;
          const n = (Number(this.__gpnSnowUltCount) || 0) + 1;
          this.__gpnSnowUltCount = n;
          this.__gpnSnowUltActive = true;
          this.__gpnSnowIcicleShare = n >= 3
            ? SNOW_ULT_ICICLE_SHARE_3
            : (n === 2 ? SNOW_ULT_ICICLE_SHARE_2 : SNOW_ULT_ICICLE_SHARE_1);
        }
      } catch (e) {}
      return prevPF.apply(this, args);
    };
    const prevFS = proto.foodShooting;
    if (typeof prevFS === 'function') {
      const newFS = function (...args) {
        let touched = false;
        let saved;
        try {
          if ((Number(this.__gpnSnowUltCount) || 0) >= 3 && SNOW_ULT_COUNT_3 > 0 && this._objdataOwn) {
            saved = this._objdataOwn.PlantfoodPeaCount;
            this._objdataOwn.PlantfoodPeaCount = SNOW_ULT_COUNT_3;
            touched = true;
          }
        } catch (e) {}
        let res;
        try {
          res = prevFS.apply(this, args);
        } finally {
          if (touched) {
            try { this._objdataOwn.PlantfoodPeaCount = saved; } catch (e) {}
          }
        }
        return res;
      };
      proto.foodShooting = newFS;
      cleanups.push(() => {
        try {
          if (proto.foodShooting === newFS) proto.foodShooting = prevFS;
        } catch (e) {}
      });
    }
    const prevPFEnd = proto.specialPlantFoodEnd;
    const newPFEnd = function (...args) {
      try {
        this.__gpnSnowUltActive = false;
      } catch (e) {}
      return prevPFEnd.apply(this, args);
    };
    const prevOE = proto.specialPlantOnEnable;
    const newOE = function (...args) {
      try {
        this.__gpnUlted = false;
        this.__gpnCycleBurst = false;
        this.__gpnCycleFired = 0;
        this.__gpnSnowUltCount = 0;
        this.__gpnSnowUltActive = false;
        this.__gpnSnowIcicleShare = 0;
        this.__gpnSnowSpreadCursor = 0;
      } catch (e) {}
      return prevOE.apply(this, args);
    };
    const prevStart = proto.startShooting;
    const newStart = function (...args) {
      try {
        if (isSelf(this)) {
          if (this.__gpnUlted === true && SNOW_BURST_CHANCE > 0) {
            this.__gpnCycleBurst = Math.random() < SNOW_BURST_CHANCE;
          } else {
            this.__gpnCycleBurst = false;
          }
          this.__gpnCycleFired = 0;
        }
      } catch (e) {}
      return prevStart.apply(this, args);
    };
    const prevShoot = proto._shoot;
    const newShoot = function (...args) {
      const isFoodShot = args[0] === true;
      let useEnhanced = false;
      let scatterAngle = null;
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          if (isFoodShot && this.__gpnSnowUltActive && this.__gpnSnowIcicleShare > 0) {
            useEnhanced = Math.random() < this.__gpnSnowIcicleShare;
            if (
              (Number(this.__gpnSnowUltCount) || 0) >= 3 &&
              MEGA_ULT_SPREAD_ANGLES && MEGA_ULT_SPREAD_ANGLES.length && SNOW_ULT_SCATTER_SCALE > 0
            ) {
              scatterAngle = MEGA_ULT_SPREAD_ANGLES[(this.__gpnSnowSpreadCursor || 0) % MEGA_ULT_SPREAD_ANGLES.length] * SNOW_ULT_SCATTER_SCALE;
              this.__gpnSnowSpreadCursor = (this.__gpnSnowSpreadCursor || 0) + 1;
            }
          } else if (!isFoodShot) {
            if (this.__gpnUlted === true) {
              useEnhanced = this.__gpnCycleBurst === true;
            } else {
              useEnhanced = ELEMENT_CHANCE > 0 && Math.random() < ELEMENT_CHANCE;
            }
          }
        }
      } catch (e) {}
      const fireArgs = args.slice();
      if (useEnhanced) fireArgs[2] = SNOW_ENHANCED_PEA; 
      const result = prevShoot.apply(this, fireArgs);
      try {
        if (scatterAngle != null) {
          const scatter = (p) => {
            try {
              if (p && p.linearVelocity && typeof p.linearVelocity.x === 'number') {
                p.linearVelocity.y = p.linearVelocity.x * scatterAngle;
              }
            } catch (e) {}
          };
          if (result && typeof result.then === 'function') {
            result.then(scatter, () => {});
          } else {
            scatter(result);
          }
        }
      } catch (e) {}
      try {
        if (
          isSelf(this) && !this.__gpnFusion && !isFoodShot &&
          this.__gpnUlted === true && this.__gpnCycleBurst === true &&
          this.__gpnCycleFired === 0
        ) {
          this.__gpnCycleFired = 1;
          const remain = Math.max(0, COUNT - 1);
          let n = 0;
          const timer = setInterval(() => {
            try {
              if (this.dead) { clearInterval(timer); activeTimers.delete(timer); return; }
            } catch (e) {}
            if (n >= remain) { clearInterval(timer); activeTimers.delete(timer); return; }
            try { prevShoot.apply(this, fireArgs); } catch (e) {}
            n++;
          }, INTERVAL_MS);
          activeTimers.add(timer);
        }
      } catch (e) {}
      return result;
    };
    proto.specialPlantFood = newPF;
    proto.specialPlantFoodEnd = newPFEnd;
    proto.specialPlantOnEnable = newOE;
    proto.startShooting = newStart;
    proto._shoot = newShoot;
    cleanups.push(() => {
      try {
        for (const tm of activeTimers) clearInterval(tm);
        activeTimers.clear();
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
        if (proto.specialPlantFoodEnd === newPFEnd) proto.specialPlantFoodEnd = prevPFEnd;
        if (proto.specialPlantOnEnable === newOE) proto.specialPlantOnEnable = prevOE;
        if (proto.startShooting === newStart) proto.startShooting = prevStart;
        if (proto._shoot === newShoot) proto._shoot = prevShoot;
      } catch (e) {}
    });
    if (log) log.info('PEP [SnowPea] active: normal chance=' + ELEMENT_CHANCE + ' enhanced=' + SNOW_ENHANCED_PEA + ' (native type), ult burst chance=' + SNOW_BURST_CHANCE + ' count=' + COUNT + ' interval=' + INTERVAL_MS + 'ms, ult rain icicle share: 1st=' + SNOW_ULT_ICICLE_SHARE_1 + ' 2nd=' + SNOW_ULT_ICICLE_SHARE_2 + ' 3rd+=' + SNOW_ULT_ICICLE_SHARE_3 + ', 3rd+ scatter scale=' + SNOW_ULT_SCATTER_SCALE + ' count=' + SNOW_ULT_COUNT_3);
  })();
  (function installSplitPea() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('SplitPeaPlant')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: SplitPeaPlant class not found, split pea features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shootBack !== 'function' ||
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function' ||
      typeof proto.specialPeashooterAnimationListener !== 'function' ||
      typeof proto.onDamaged !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on SplitPeaPlant, split pea features skipped');
      return;
    }
    const isSelf = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const isStress = (self) => {
      try {
        if (!self.inLane || !self.node || !self.node.worldPosition) return false;
        const selfX = self.node.worldPosition.x;
        const pool = self.inLane.zombiePool();
        if (!pool || !pool.length) return false;
        for (let i = 0; i < pool.length; i++) {
          const z = pool[i];
          if (!z || z.dead || !z.node || !z.node.worldPosition) continue;
          if (z.node.worldPosition.x < selfX) return true;
        }
      } catch (e) {}
      return false;
    };
    const prevShootBack = proto._shootBack;
    const newShootBack = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          const o = args[0];
          const hasExplicitPea = args.length >= 3 && args[2] !== undefined;
          if (!hasExplicitPea) {
            if (o === true) {
              if (SPLITPEA_ULT_BACK_ICE_SHARE > 0 && Math.random() < SPLITPEA_ULT_BACK_ICE_SHARE) {
                args = args.slice();
                args[2] = SPLITPEA_BACK_ICE_PEA;
              }
            } else {
              let decided = false;
              let backPea = null;
              if (this.__gpnSplitBackPendingSet) {
                backPea = this.__gpnSplitBackPending;
                this.__gpnSplitBackPendingSet = false;
                this.__gpnSplitBackPending = null;
                decided = true;
              }
              if (!decided) {
                if (this.__gpnBackCounterReady) {
                  backPea = SPLITPEA_BACK_ICICLE_PEA;
                  this.__gpnBackCounterReady = false;
                  this.__gpnBackCounterNext = Date.now() + SPLITPEA_BACK_COUNTER_COOLDOWN_MS;
                } else if (isStress(this)) {
                  const roll = Math.random();
                  if (roll < SPLITPEA_BACK_STRESS_ICICLE_CHANCE) {
                    backPea = SPLITPEA_BACK_ICICLE_PEA;
                  } else if (roll < SPLITPEA_BACK_STRESS_ICICLE_CHANCE + SPLITPEA_BACK_STRESS_ICE_CHANCE) {
                    backPea = SPLITPEA_BACK_ICE_PEA;
                  }
                }
                this.__gpnSplitBackPendingSet = true;
                this.__gpnSplitBackPending = backPea;
              }
              if (backPea) {
                args = args.slice();
                args[2] = backPea;
              }
            }
          }
        }
      } catch (e) {}
      return prevShootBack.apply(this, args);
    };
    const prevOnDamaged = proto.onDamaged;
    const newOnDamaged = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion && args[0] > 0) {
          if (!this.__gpnBackCounterReady && Date.now() >= (this.__gpnBackCounterNext || 0)) {
            this.__gpnBackCounterReady = true;
          }
        }
      } catch (e) {}
      return prevOnDamaged.apply(this, args);
    };
    const prevPF = proto.specialPlantFood;
    const newPF = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          this.__gpnUlted = true;
        }
      } catch (e) {}
      return prevPF.apply(this, args);
    };
    const prevOE = proto.specialPlantOnEnable;
    const newOE = function (...args) {
      try {
        this.__gpnUlted = false;
        this.__gpnBackCounterReady = false;
        this.__gpnBackCounterNext = 0;
        this.__gpnSplitBackPendingSet = false;
        this.__gpnSplitBackPending = null;
      } catch (e) {}
      return prevOE.apply(this, args);
    };
    const prevSAL = proto.specialPeashooterAnimationListener;
    const newSAL = function (evt) {
      const isShootR = evt && evt.name === 'ShootR';
      let res;
      try {
        if (isShootR && isSelf(this) && !this.__gpnFusion && this.__gpnUlted === true && SPLITPEA_BURST_CHANCE > 0) {
          if (Math.random() < SPLITPEA_BURST_CHANCE) {
            res = prevSAL.apply(this, arguments); 
            const self = this;
            const remain = Math.max(0, COUNT - 1);
            let n = 0;
            const timer = setInterval(() => {
              try {
                if (self.dead) { clearInterval(timer); activeTimers.delete(timer); return; }
              } catch (e) {}
              if (n >= remain) { clearInterval(timer); activeTimers.delete(timer); return; }
              try { self._shoot(); } catch (e) {}
              n++;
            }, INTERVAL_MS);
            activeTimers.add(timer);
            return res;
          }
        }
      } catch (e) {}
      return prevSAL.apply(this, arguments);
    };
    proto._shootBack = newShootBack;
    proto.onDamaged = newOnDamaged;
    proto.specialPlantFood = newPF;
    proto.specialPlantOnEnable = newOE;
    proto.specialPeashooterAnimationListener = newSAL;
    cleanups.push(() => {
      try {
        for (const tm of activeTimers) clearInterval(tm);
        activeTimers.clear();
        if (proto._shootBack === newShootBack) proto._shootBack = prevShootBack;
        if (proto.onDamaged === newOnDamaged) proto.onDamaged = prevOnDamaged;
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
        if (proto.specialPlantOnEnable === newOE) proto.specialPlantOnEnable = prevOE;
        if (proto.specialPeashooterAnimationListener === newSAL) proto.specialPeashooterAnimationListener = prevSAL;
      } catch (e) {}
    });
    if (log) log.info('PEP [SplitPea] active: stress ice=' + SPLITPEA_BACK_STRESS_ICE_CHANCE + ' icicle=' + SPLITPEA_BACK_STRESS_ICICLE_CHANCE + ' (paired shots), counter cooldown=' + SPLITPEA_BACK_COUNTER_COOLDOWN_MS + 'ms, ult back ice share=' + SPLITPEA_ULT_BACK_ICE_SHARE + ', ult forward burst chance=' + SPLITPEA_BURST_CHANCE + ' count=' + COUNT);
  })();
  (function installPrimalPeaGrowth() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? (engine.getClassByName('PrimalPeashooter') || engine.getClassByName('PrimalPeashooterPlant'))
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: PrimalPeashooter class not found, primal pea features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPeashooterAnimationListener !== 'function' ||
      typeof proto.startShooting !== 'function' ||
      typeof proto._shootPeaAnimation !== 'function' ||
      typeof proto.specialPeashooterOnEnable !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on PrimalPeashooterPlant, primal pea features skipped');
      return;
    }
    const isSelf = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const speedBoost = (self) => {
      const n = Number(self.__gpnPrimalUltCount) || 0;
      return Math.min(n, 3) * PRIMAL_SPEED_BOOST_STEP;
    };
    let SplashDamage = null;
    let ccSize = null;
    try {
      const mProj = engine.getSystemModule('chunks:///_virtual/Projectiles.ts');
      const mShot = engine.getSystemModule('chunks:///_virtual/commonShot.ts');
      SplashDamage = (mProj && mProj.SplashDamage) || (mShot && mShot.SplashDamage) || null;
      const cc = engine.getCc ? engine.getCc() : null;
      ccSize = (cc && cc.Size) || null;
    } catch (e) { SplashDamage = null; ccSize = null; }
    const fireMiniPrimal = (self2, s3) => {
      try {
        let angle = null;
        if (s3 && PRIMAL_ULT_SCATTER_SCALE > 0 && MEGA_ULT_SPREAD_ANGLES && MEGA_ULT_SPREAD_ANGLES.length) {
          angle = MEGA_ULT_SPREAD_ANGLES[(self2.__gpnPrimalSpreadCursor || 0) % MEGA_ULT_SPREAD_ANGLES.length] * PRIMAL_ULT_SCATTER_SCALE;
          self2.__gpnPrimalSpreadCursor = (self2.__gpnPrimalSpreadCursor || 0) + 1;
        }
        const p = self2._shoot(true, true, 'pea_primal');
        const apply = (pea) => {
          try {
            if (!pea) return;
            try { const cur = typeof pea.scale === 'number' ? Math.abs(pea.scale) : 1; pea.scale = cur * PRIMAL_ULT_RAIN_SCALE; } catch (e) {}
            try { if (typeof pea.setDamage === 'function') pea.setDamage(PRIMAL_ULT_RAIN_DAMAGE); } catch (e) {}
            if (SplashDamage && ccSize && typeof pea.setSplashDamages === 'function') {
              try { pea.setSplashDamages([new SplashDamage(PRIMAL_ULT_RAIN_SPLASH_DAMAGE, new ccSize(PRIMAL_ULT_RAIN_SPLASH_RANGE, PRIMAL_ULT_RAIN_SPLASH_RANGE))]); } catch (e) {}
            }
            try { if (typeof pea.setKnockBack === 'function') pea.setKnockBack(PRIMAL_ULT_RAIN_KNOCKBACK); } catch (e) {}
            try { if (PRIMAL_ULT_RAIN_STUN > 0 && typeof pea.setStun === 'function') pea.setStun(PRIMAL_ULT_RAIN_STUN); } catch (e) {}
            if (angle != null && pea.linearVelocity && typeof pea.linearVelocity.x === 'number') {
              pea.linearVelocity.y = pea.linearVelocity.x * angle;
            }
          } catch (e) {}
        };
        if (p && typeof p.then === 'function') p.then(apply, () => {}); else apply(p);
      } catch (e) {}
    };
    const finishRain = function () {
      try {
        if (this.__gpnPrimalUltMode === 'rain') {
          this.__gpnPrimalUltMode = null;
          stopRainSfx(this);
          try {
            if (this.anmControl && typeof this.anmControl.playIdle === 'function') this.anmControl.playIdle();
          } catch (e) {}
        }
      } catch (e) {}
      try { if (typeof this.foodEnd === 'function') this.foodEnd(); } catch (e) {}
    };
    proto.finishPrimalRain = finishRain;
    const prevPF = proto.specialPlantFood;
    const newPF = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          this.__gpnPrimalUltCount = (Number(this.__gpnPrimalUltCount) || 0) + 1;
          if (PRIMAL_ULT_RAIN_CHANCE > 0 && Math.random() < PRIMAL_ULT_RAIN_CHANCE) {
            this.__gpnPrimalUltMode = 'rain';
            this.__gpnRainSfxStop = false;
            this.fooding = true;
            const stage3 = (Number(this.__gpnPrimalUltCount) || 0) >= 3;
            startRainSfx(this);
            try { this.anmControl.playAnimation('FoodStart', 1, PRIMAL_ULT_RAIN_PREPARE_SPEED); } catch (e) {}
            try { this.soundRes.playFood(); } catch (e) {}
            const self = this;
            if (typeof this.scheduleOnce === 'function') {
              this.scheduleOnce(() => {
                try {
                  if (self.dead || self.__gpnPrimalUltMode !== 'rain') return;
                  if (self.anmControl) self.anmControl.playAnimation('Food', 1 / 0);
                  const total = Math.max(1, Math.floor(Number(stage3 ? PRIMAL_ULT_RAIN_COUNT_3 : PRIMAL_ULT_RAIN_COUNT) || 1));
                  const step = Math.max(16, Math.floor(2000 / total));
                  let fired = 0;
                  const timer = setInterval(() => {
                    try {
                      if (self.dead || self.__gpnPrimalUltMode !== 'rain') {
                        clearInterval(timer); activeTimers.delete(timer);
                        try { self.finishPrimalRain(); } catch (e) {}
                        return;
                      }
                    } catch (e) {}
                    if (fired >= total) {
                      clearInterval(timer); activeTimers.delete(timer);
                      try { self.finishPrimalRain(); } catch (e) {}
                      return;
                    }
                    fireMiniPrimal(self, stage3);
                    fired++;
                  }, step);
                  activeTimers.add(timer);
                } catch (err) {}
              }, PRIMAL_ULT_RAIN_PREPARE_SECONDS);
            } else {
              const total = Math.max(1, Math.floor(Number(stage3 ? PRIMAL_ULT_RAIN_COUNT_3 : PRIMAL_ULT_RAIN_COUNT) || 1));
              for (let i = 0; i < total; i++) { fireMiniPrimal(this, stage3); }
              try { this.finishPrimalRain(); } catch (e) {}
            }
            return;
          }
        }
      } catch (e) {}
      return prevPF.apply(this, args); 
    };
    const prevOE = proto.specialPeashooterOnEnable;
    const newOE = function (...args) {
      try {
        this.__gpnPrimalUltCount = 0;
        this.__gpnPrimalSpreadCursor = 0;
      } catch (e) {}
      return prevOE.apply(this, args);
    };
    const prevStart = proto.startShooting;
    const newStart = function (...args) {
      const res = prevStart.apply(this, args);
      try {
        if (isSelf(this) && !this.__gpnFusion && this.shootCD > 0) {
          const boost = speedBoost(this);
          if (boost > 0) this.shootCD /= (1 + boost);
        }
      } catch (e) {}
      return res;
    };
    const prevSPA = proto._shootPeaAnimation;
    const newSPA = function (...args) {
      let touched = false;
      let saved;
      try {
        if (isSelf(this) && !this.__gpnFusion && this.shootCD > 0) {
          const boost = speedBoost(this);
          if (boost > 0) {
            saved = this.minShootInterval;
            this.minShootInterval = this.shootCD * (1 + boost);
            touched = true;
          }
        }
      } catch (e) {}
      let res;
      try {
        res = prevSPA.apply(this, arguments);
      } finally {
        if (touched) {
          try { this.minShootInterval = saved; } catch (e) {}
        }
      }
      return res;
    };
    const prevSAL = proto.specialPeashooterAnimationListener;
    const newSAL = function (evt) {
      try {
        if (this.__gpnPrimalUltMode === 'rain') return;
        if (
          isSelf(this) && !this.__gpnFusion && evt && evt.name === 'shootFood' &&
          this.fooding && (Number(this.__gpnPrimalUltCount) || 0) >= 3 && PRIMAL_ULT_EXTRA_SHOTS > 0
        ) {
          const saved = this._objdataOwn.PlantfoodPeaCount;
          this._objdataOwn.PlantfoodPeaCount = saved + PRIMAL_ULT_EXTRA_SHOTS;
          const res = prevSAL.apply(this, arguments);
          this._objdataOwn.PlantfoodPeaCount = saved;
          return res;
        }
      } catch (e) {}
      return prevSAL.apply(this, arguments);
    };
    proto.specialPlantFood = newPF;
    proto.specialPeashooterOnEnable = newOE;
    proto.startShooting = newStart;
    proto._shootPeaAnimation = newSPA;
    proto.specialPeashooterAnimationListener = newSAL;
    cleanups.push(() => {
      try {
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
        if (proto.specialPeashooterOnEnable === newOE) proto.specialPeashooterOnEnable = prevOE;
        if (proto.startShooting === newStart) proto.startShooting = prevStart;
        if (proto._shootPeaAnimation === newSPA) proto._shootPeaAnimation = prevSPA;
        if (proto.specialPeashooterAnimationListener === newSAL) proto.specialPeashooterAnimationListener = prevSAL;
        if (proto.finishPrimalRain === finishRain) delete proto.finishPrimalRain;
      } catch (e) {}
    });
    if (log) log.info('PEP [PrimalPeashooter] active: speed boost step=' + PRIMAL_SPEED_BOOST_STEP + ' (per ult, cap 3), ult extra shots from 3rd=' + PRIMAL_ULT_EXTRA_SHOTS + ', ult rain chance=' + PRIMAL_ULT_RAIN_CHANCE + ' count=' + PRIMAL_ULT_RAIN_COUNT + '/' + PRIMAL_ULT_RAIN_COUNT_3 + ' scatter=' + PRIMAL_ULT_SCATTER_SCALE + ' pea scale=' + PRIMAL_ULT_RAIN_SCALE + ' dmg=' + PRIMAL_ULT_RAIN_DAMAGE + ' splash=' + PRIMAL_ULT_RAIN_SPLASH_DAMAGE + 'x' + PRIMAL_ULT_RAIN_SPLASH_RANGE);
  })();
  (function installGooPeashooter() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('GooPeashooterPlant')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: GooPeashooterPlant class not found, goo peashooter features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shoot !== 'function' ||
      typeof proto.startShooting !== 'function' ||
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPlantFoodEnd !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function' ||
      typeof proto.specialPeashooterAnimationListener !== 'function' ||
      typeof proto.animationCompleteAdd !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on GooPeashooterPlant, goo peashooter features skipped');
      return;
    }
    const isSelf = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const prevPF = proto.specialPlantFood;
    const newPF = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          this.__gpnUlted = true;
          this.__gpnCycleBurst = false;
          this.__gpnCycleFired = 0;
          this.__gpnGooUltCount = (Number(this.__gpnGooUltCount) || 0) + 1;
          if (GOO_ULT_RAIN_CHANCE > 0 && Math.random() < GOO_ULT_RAIN_CHANCE) {
            this.__gpnGooUltMode = 'rain';
            this.__gpnRainSfxStop = false;
            this.fooding = true;
            const stage3 = (Number(this.__gpnGooUltCount) || 0) >= 3;
            const fireRainPea = (self2, s3) => {
              try {
                let angle = null;
                if (s3 && GOO_ULT_SCATTER_SCALE > 0 && MEGA_ULT_SPREAD_ANGLES && MEGA_ULT_SPREAD_ANGLES.length) {
                  angle = MEGA_ULT_SPREAD_ANGLES[(self2.__gpnGooSpreadCursor || 0) % MEGA_ULT_SPREAD_ANGLES.length] * GOO_ULT_SCATTER_SCALE;
                  self2.__gpnGooSpreadCursor = (self2.__gpnGooSpreadCursor || 0) + 1;
                }
                const p = self2._shoot(true, true, GOO_ULT_RAIN_PEA);
                if (angle != null) {
                  const apply = (pea) => { try { if (pea && pea.linearVelocity && typeof pea.linearVelocity.x === 'number') pea.linearVelocity.y = pea.linearVelocity.x * angle; } catch (e) {} };
                  if (p && typeof p.then === 'function') p.then(apply, () => {}); else apply(p);
                }
              } catch (e) {}
            };
            startRainSfx(this);
            try { this.anmControl.playAnimation('FoodStart', 1, GOO_ULT_RAIN_PREPARE_SPEED); } catch (e) {}
            try { this.soundRes.playFood(); } catch (e) {}
            const self = this;
            if (typeof this.scheduleOnce === 'function') {
              this.scheduleOnce(() => {
                try {
                  if (self.dead || self.__gpnGooUltMode !== 'rain') return;
                  if (self.anmControl) self.anmControl.playAnimation('Food', 1 / 0);
                  const total = Math.max(1, Math.floor(Number(stage3 ? GOO_ULT_RAIN_COUNT_3 : GOO_ULT_RAIN_COUNT) || 1));
                  const step = Math.max(16, Math.floor(2000 / total));
                  let fired = 0;
                  const timer = setInterval(() => {
                    try {
                      if (self.dead || self.__gpnGooUltMode !== 'rain') {
                        clearInterval(timer); activeTimers.delete(timer);
                        try { if (typeof self.foodEnd === 'function') self.foodEnd(); } catch (e) {}
                        return;
                      }
                    } catch (e) {}
                    if (fired >= total) {
                      clearInterval(timer); activeTimers.delete(timer);
                      try { if (typeof self.foodEnd === 'function') self.foodEnd(); } catch (e) {}
                      return;
                    }
                    fireRainPea(self, stage3);
                    fired++;
                  }, step);
                  activeTimers.add(timer);
                } catch (err) {}
              }, GOO_ULT_RAIN_PREPARE_SECONDS);
            } else {
              const total = Math.max(1, Math.floor(Number(stage3 ? GOO_ULT_RAIN_COUNT_3 : GOO_ULT_RAIN_COUNT) || 1));
              for (let i = 0; i < total; i++) { fireRainPea(this, stage3); }
              try { if (typeof this.foodEnd === 'function') this.foodEnd(); } catch (e) {}
            }
            return;
          }
        }
      } catch (e) {}
      return prevPF.apply(this, args); 
    };
    const prevPFEnd = proto.specialPlantFoodEnd;
    const newPFEnd = function (...args) {
      try {
        if (this.__gpnGooUltMode === 'rain') {
          this.__gpnGooUltMode = null;
          stopRainSfx(this);
          try {
            if (this.anmControl && typeof this.anmControl.playIdle === 'function') this.anmControl.playIdle();
          } catch (e) {}
        }
      } catch (e) {}
      return prevPFEnd.apply(this, args);
    };
    const prevOE = proto.specialPlantOnEnable;
    const newOE = function (...args) {
      try {
        this.__gpnUlted = false;
        this.__gpnCycleBurst = false;
        this.__gpnCycleFired = 0;
        this.__gpnGooUltCount = 0;
        this.__gpnGooSpreadCursor = 0;
        this.__gpnGooUltMode = null;
        stopRainSfx(this);
      } catch (e) {}
      return prevOE.apply(this, args);
    };
    const prevSAL = proto.specialPeashooterAnimationListener;
    const newSAL = function (evt) {
      try {
        if (this.__gpnGooUltMode === 'rain') return;
      } catch (e) {}
      return prevSAL.apply(this, arguments);
    };
    const prevACA = proto.animationCompleteAdd;
    const newACA = function (...args) {
      try {
        if (this.__gpnGooUltMode === 'rain') return;
      } catch (e) {}
      return prevACA.apply(this, args);
    };
    const prevStart = proto.startShooting;
    const newStart = function (...args) {
      try {
        if (isSelf(this)) {
          if (this.__gpnUlted === true && GOO_BURST_CHANCE > 0) {
            this.__gpnCycleBurst = Math.random() < GOO_BURST_CHANCE;
          } else {
            this.__gpnCycleBurst = false;
          }
          this.__gpnCycleFired = 0;
        }
      } catch (e) {}
      return prevStart.apply(this, args);
    };
    const prevShoot = proto._shoot;
    const newShoot = function (...args) {
      const isFoodShot = args[0] === true;
      const result = prevShoot.apply(this, args);
      try {
        if (
          isSelf(this) && !this.__gpnFusion && !isFoodShot &&
          this.__gpnUlted === true && this.__gpnCycleBurst === true &&
          this.__gpnCycleFired === 0
        ) {
          this.__gpnCycleFired = 1;
          const self = this;
          const remain = Math.max(0, COUNT - 1);
          let n = 0;
          const timer = setInterval(() => {
            try {
              if (self.dead) { clearInterval(timer); activeTimers.delete(timer); return; }
            } catch (e) {}
            if (n >= remain) { clearInterval(timer); activeTimers.delete(timer); return; }
            try { self._shoot(); } catch (e) {}
            n++;
          }, INTERVAL_MS);
          activeTimers.add(timer);
        }
      } catch (e) {}
      return result;
    };
    proto.specialPlantFood = newPF;
    proto.specialPlantFoodEnd = newPFEnd;
    proto.specialPlantOnEnable = newOE;
    proto.specialPeashooterAnimationListener = newSAL;
    proto.animationCompleteAdd = newACA;
    proto.startShooting = newStart;
    proto._shoot = newShoot;
    cleanups.push(() => {
      try {
        for (const tm of activeTimers) clearInterval(tm);
        activeTimers.clear();
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
        if (proto.specialPlantFoodEnd === newPFEnd) proto.specialPlantFoodEnd = prevPFEnd;
        if (proto.specialPlantOnEnable === newOE) proto.specialPlantOnEnable = prevOE;
        if (proto.specialPeashooterAnimationListener === newSAL) proto.specialPeashooterAnimationListener = prevSAL;
        if (proto.animationCompleteAdd === newACA) proto.animationCompleteAdd = prevACA;
        if (proto.startShooting === newStart) proto.startShooting = prevStart;
        if (proto._shoot === newShoot) proto._shoot = prevShoot;
      } catch (e) {}
    });
    if (log) log.info('PEP [GooPeashooter] active: ult rain chance=' + GOO_ULT_RAIN_CHANCE + ' peas=' + GOO_ULT_RAIN_COUNT + ' (hit sfx=PopSound), ult burst chance=' + GOO_BURST_CHANCE + ' count=' + COUNT + ' interval=' + INTERVAL_MS + 'ms, 3rd+ rain scatter=' + GOO_ULT_SCATTER_SCALE + ' count=' + GOO_ULT_RAIN_COUNT_3);
  })();
  (function installElectricPeashooter() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? (engine.getClassByName('ElectricPeashooter') || engine.getClassByName('ElectricPeashooterPlant'))
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: ElectricPeashooter class not found, electric peashooter features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shoot !== 'function' ||
      typeof proto.startShooting !== 'function' ||
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPlantFoodEnd !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function' ||
      typeof proto.animationListener !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on ElectricPeashooter, electric peashooter features skipped');
      return;
    }
    const isSelf = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const prevPF = proto.specialPlantFood;
    const newPF = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          this.__gpnElecUlted = true;
          this.__gpnElecCycleBurst = false;
          this.__gpnElecCycleFired = 0;
          this.__gpnElecUltCount = (Number(this.__gpnElecUltCount) || 0) + 1;
          if (ELECTRIC_ULT_RAIN_CHANCE > 0 && Math.random() < ELECTRIC_ULT_RAIN_CHANCE) {
            this.__gpnElecUltMode = 'rain';
            this.__gpnRainSfxStop = false;
            this.fooding = true;
            startRainSfx(this);
            try { this.anmControl.playAnimation('FoodStart', 1, ELECTRIC_ULT_RAIN_PREPARE_SPEED); } catch (e) {}
            try { this.soundRes.playFood(); } catch (e) {}
            const stage3 = (Number(this.__gpnElecUltCount) || 0) >= 3;
            const fireRainPea = (self2, s3) => {
              try {
                const peaType = Math.random() < ELECTRIC_ULT_RAIN_SMALL_SHARE ? 'electricpea_small' : 'electricpea';
                let angle = null;
                if (s3 && ELECTRIC_ULT_SCATTER_SCALE > 0 && MEGA_ULT_SPREAD_ANGLES && MEGA_ULT_SPREAD_ANGLES.length) {
                  angle = MEGA_ULT_SPREAD_ANGLES[(self2.__gpnElecSpreadCursor || 0) % MEGA_ULT_SPREAD_ANGLES.length] * ELECTRIC_ULT_SCATTER_SCALE;
                  self2.__gpnElecSpreadCursor = (self2.__gpnElecSpreadCursor || 0) + 1;
                }
                const p = self2._shoot(true, true, peaType);
                if (angle != null) {
                  const apply = (pea) => { try { if (pea && pea.linearVelocity && typeof pea.linearVelocity.x === 'number') pea.linearVelocity.y = pea.linearVelocity.x * angle; } catch (e) {} };
                  if (p && typeof p.then === 'function') p.then(apply, () => {}); else apply(p);
                }
              } catch (e) {}
            };
            const self = this;
            if (typeof this.scheduleOnce === 'function') {
              this.scheduleOnce(() => {
                try {
                  if (self.dead || self.__gpnElecUltMode !== 'rain') return;
                  if (self.anmControl) self.anmControl.playAnimation('Food', 1 / 0);
                  const total = Math.max(1, Math.floor(Number(stage3 ? ELECTRIC_ULT_RAIN_COUNT_3 : ELECTRIC_ULT_RAIN_COUNT) || 1));
                  const step = Math.max(16, Math.floor(2000 / total));
                  let fired = 0;
                  const timer = setInterval(() => {
                    try {
                      if (self.dead || self.__gpnElecUltMode !== 'rain') {
                        clearInterval(timer); activeTimers.delete(timer);
                        try { if (typeof self.foodEnd === 'function') self.foodEnd(); } catch (e) {}
                        return;
                      }
                    } catch (e) {}
                    if (fired >= total) {
                      clearInterval(timer); activeTimers.delete(timer);
                      try { if (typeof self.foodEnd === 'function') self.foodEnd(); } catch (e) {}
                      return;
                    }
                    fireRainPea(self, stage3);
                    fired++;
                  }, step);
                  activeTimers.add(timer);
                } catch (err) {}
              }, ELECTRIC_ULT_RAIN_PREPARE_SECONDS);
            } else {
              const total = Math.max(1, Math.floor(Number(stage3 ? ELECTRIC_ULT_RAIN_COUNT_3 : ELECTRIC_ULT_RAIN_COUNT) || 1));
              for (let i = 0; i < total; i++) { fireRainPea(this, stage3); }
              try { if (typeof this.foodEnd === 'function') this.foodEnd(); } catch (e) {}
            }
            return;
          }
        }
      } catch (e) {}
      return prevPF.apply(this, args); 
    };
    const prevPFEnd = proto.specialPlantFoodEnd;
    const newPFEnd = function (...args) {
      try {
        if (this.__gpnElecUltMode === 'rain') {
          this.__gpnElecUltMode = null;
          stopRainSfx(this);
        }
      } catch (e) {}
      return prevPFEnd.apply(this, args);
    };
    const prevOE = proto.specialPlantOnEnable;
    const newOE = function (...args) {
      try {
        this.__gpnElecUlted = false;
        this.__gpnElecCycleBurst = false;
        this.__gpnElecCycleFired = 0;
        this.__gpnElecUltCount = 0;
        this.__gpnElecSpreadCursor = 0;
        this.__gpnElecUltMode = null;
        stopRainSfx(this);
      } catch (e) {}
      return prevOE.apply(this, args);
    };
    const prevAL = proto.animationListener;
    const newAL = function (evt) {
      try {
        if (this.__gpnElecUltMode === 'rain') return;
        if (
          isSelf(this) && !this.__gpnFusion && evt && evt.name === 'foodShoot' &&
          (Number(this.__gpnElecUltCount) || 0) >= 3 && ELECTRIC_ULT_MEGA_EXTRA > 0
        ) {
          const saved = this._objdataOwn.PlantfoodPeaCount;
          this._objdataOwn.PlantfoodPeaCount = saved + ELECTRIC_ULT_MEGA_EXTRA;
          const res = prevAL.apply(this, arguments);
          this._objdataOwn.PlantfoodPeaCount = saved;
          return res;
        }
      } catch (e) {}
      return prevAL.apply(this, arguments);
    };
    const prevStart = proto.startShooting;
    const newStart = function (...args) {
      try {
        if (isSelf(this)) {
          if (this.__gpnElecUlted === true && ELECTRIC_BURST_CHANCE > 0) {
            this.__gpnElecCycleBurst = Math.random() < ELECTRIC_BURST_CHANCE;
          } else {
            this.__gpnElecCycleBurst = false;
          }
          this.__gpnElecCycleFired = 0;
        }
      } catch (e) {}
      return prevStart.apply(this, args);
    };
    const prevShoot = proto._shoot;
    const newShoot = function (...args) {
      const isFoodShot = args[0] === true;
      const result = prevShoot.apply(this, args);
      try {
        if (
          isSelf(this) && !this.__gpnFusion && !isFoodShot &&
          this.__gpnElecUlted === true && this.__gpnElecCycleBurst === true &&
          this.__gpnElecCycleFired === 0
        ) {
          this.__gpnElecCycleFired = 1;
          const self = this;
          const remain = Math.max(0, COUNT - 1);
          let n = 0;
          const timer = setInterval(() => {
            try {
              if (self.dead) { clearInterval(timer); activeTimers.delete(timer); return; }
            } catch (e) {}
            if (n >= remain) { clearInterval(timer); activeTimers.delete(timer); return; }
            try { self._shoot(); } catch (e) {}
            n++;
          }, INTERVAL_MS);
          activeTimers.add(timer);
        }
      } catch (e) {}
      return result;
    };
    proto.specialPlantFood = newPF;
    proto.specialPlantFoodEnd = newPFEnd;
    proto.specialPlantOnEnable = newOE;
    proto.animationListener = newAL;
    proto.startShooting = newStart;
    proto._shoot = newShoot;
    cleanups.push(() => {
      try {
        for (const tm of activeTimers) clearInterval(tm);
        activeTimers.clear();
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
        if (proto.specialPlantFoodEnd === newPFEnd) proto.specialPlantFoodEnd = prevPFEnd;
        if (proto.specialPlantOnEnable === newOE) proto.specialPlantOnEnable = prevOE;
        if (proto.animationListener === newAL) proto.animationListener = prevAL;
        if (proto.startShooting === newStart) proto.startShooting = prevStart;
        if (proto._shoot === newShoot) proto._shoot = prevShoot;
      } catch (e) {}
    });
    if (log) log.info('PEP [ElectricPeashooter] active: ult rain chance=' + ELECTRIC_ULT_RAIN_CHANCE + ' peas=' + ELECTRIC_ULT_RAIN_COUNT + ' small-share=' + ELECTRIC_ULT_RAIN_SMALL_SHARE + ', ult mega extra from 3rd=' + ELECTRIC_ULT_MEGA_EXTRA + ', 3rd+ rain scatter=' + ELECTRIC_ULT_SCATTER_SCALE + ' count=' + ELECTRIC_ULT_RAIN_COUNT_3 + ', ult burst chance=' + ELECTRIC_BURST_CHANCE + ' count=' + COUNT);
  })();
  (function installOurMegaGatling() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('MegaGatlingPeaPlant')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: MegaGatlingPeaPlant class not found, our mega gatling features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shoot !== 'function' ||
      typeof proto._shootPeaAnimation !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on MegaGatlingPeaPlant, our mega gatling features skipped');
      return;
    }
    const isSelf = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const pickAttr = (self) => {
      try {
        if (self) {
          if (self.__gpnFlameFoodPea) return self.__gpnFlameFoodPea;
          if (self.__gpnFlamePea) return self.__gpnFlamePea;
          if (self.__gpnElecFoodPea) return self.__gpnElecFoodPea;
          if (self.__gpnElecPea) return self.__gpnElecPea;
          if (self.__gpnForm) return self.__gpnFormFoodPea || self.__gpnFormPea || 'pea';
        }
      } catch (e) {}
      try { return MEGA_ATTR_POOL[Math.floor(Math.random() * MEGA_ATTR_POOL.length)] || 'pea'; } catch (e) { return 'pea'; }
    };
    const prevShoot = proto._shoot;
    const newShoot = function (...args) {
      const isFoodShot = args[0] === true;
      let fireArgs = args;
      let spreadAngle = null;
      let elecEnh = false; 
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          if (isFoodShot) {
            try {
              const enhForm = this.__gpnFlamePea || this.__gpnElecPea || (this.__gpnForm && this.__gpnFormEnhPea && this.__gpnFormFoodPea !== this.__gpnFormPea);
              if (enhForm && this.upgraded !== true && this._upgraded !== true) {
                this.upgraded = true;
              }
            } catch (e) {}
            if (this.__gpnElecPea) elecEnh = true;
            fireArgs = args.slice();
            fireArgs[2] = pickAttr(this);
            if (MEGA_ULT_SPREAD_ANGLES && MEGA_ULT_SPREAD_ANGLES.length) {
              spreadAngle = MEGA_ULT_SPREAD_ANGLES[(this.__gpnSpreadCursor || 0) % MEGA_ULT_SPREAD_ANGLES.length];
              this.__gpnSpreadCursor = (this.__gpnSpreadCursor || 0) + 1;
            }
          } else {
            const fixedPea = this.__gpnFlamePea || this.__gpnElecPea || (this.__gpnForm ? this.__gpnFormPea : null) || null;
            if (fixedPea) {
              let pea = fixedPea;
              const enhPea = this.__gpnFlameFoodPea || (this.__gpnForm ? this.__gpnFormEnhPea : null) || null;
              const hasEnh = !!enhPea && enhPea !== fixedPea;
              try {
                if (this.__gpnElecPea && (this.upgraded || this._upgraded)) {
                  const now = Date.now();
                  const lastAt = this.__gpnElecBurstAt || 0;
                  if (now - lastAt > 1000) {
                    this.__gpnElecBurstAt = now;
                    const full = (Number(this.__gpnPepUltCount) || 0) >= FULL_ULT_COUNT;
                    this.__gpnElecBurstEnh = full || Math.random() < 0.5;
                  }
                  elecEnh = this.__gpnElecBurstEnh === true;
                }
              } catch (e) {}
              try {
                if (hasEnh && (this.upgraded || this._upgraded)) {
                  const now = Date.now();
                  const lastAt = this.__gpnFormBurstAt || 0;
                  if (now - lastAt > 1000) {
                    this.__gpnFormBurstAt = now;
                    const full = (Number(this.__gpnPepUltCount) || 0) >= FULL_ULT_COUNT;
                    this.__gpnFormBurstPea = full ? enhPea : (Math.random() < 0.5 ? fixedPea : enhPea);
                  }
                  if (this.__gpnFormBurstPea) pea = this.__gpnFormBurstPea;
                }
              } catch (e) {}
              fireArgs = args.slice();
              fireArgs[2] = pea;
            } else {
              const now = Date.now();
              if (now - (this.__gpnMegaBurstAt || 0) > MEGA_BURST_UNIFY_MS) {
                this.__gpnMegaBurstAt = now;
                this.__gpnMegaBurstAttr = (MEGA_ATTR_CHANCE > 0 && Math.random() < MEGA_ATTR_CHANCE) ? pickAttr(this) : null;
              }
              if (this.__gpnMegaBurstAttr) {
                fireArgs = args.slice();
                fireArgs[2] = this.__gpnMegaBurstAttr;
              }
            }
          }
        }
      } catch (e) {}
      const result = prevShoot.apply(this, fireArgs);
      try {
        const mark = (pea) => {
          try {
            if (pea) {
              pea.__gpnMegaPea = true;
              pea.__gpnMegaOwner = this;
              if (elecEnh) {
                try {
                  const cur = typeof pea.scale === 'number' ? Math.abs(pea.scale) : 1;
                  let base = cur;
                  if (cur >= 1.5) base = cur / 1.5;
                  pea.scale = Math.max(1, base) * 1.5;
                } catch (e) {}
                try { if (typeof pea.setDamage === 'function') pea.setDamage(60); } catch (e) {}
              }
            }
          } catch (e) {}
        };
        if (result && typeof result.then === 'function') {
          result.then(mark, () => {});
        } else {
          mark(result);
        }
      } catch (e) {}
      if (spreadAngle != null) {
        try {
          const scatter = (pea) => {
            try {
              if (pea && pea.linearVelocity && typeof pea.linearVelocity.x === 'number') {
                pea.linearVelocity.y = pea.linearVelocity.x * spreadAngle;
              }
            } catch (e) {}
          };
          if (result && typeof result.then === 'function') {
            result.then(scatter, () => {});
          } else {
            scatter(result);
          }
        } catch (e) {}
      }
      return result;
    };
    const prevSPA = proto._shootPeaAnimation;
    const newSPA = function (...args) {
      let saved;
      let touched = false;
      try {
        if (isSelf(this) && !this.__gpnFusion && this._objdataOwn) {
          saved = this._objdataOwn.ChanceToPlantfood;
          this._objdataOwn.ChanceToPlantfood = Math.min(0.03 + (Number(this.__gpnMegaKills) || 0) * MEGA_KILL_BONUS, MEGA_KILL_MAX);
          touched = true;
        }
      } catch (e) {}
      let res;
      try {
        res = prevSPA.apply(this, arguments);
      } finally {
        if (touched) {
          try { this._objdataOwn.ChanceToPlantfood = saved; } catch (e) {}
        }
      }
      return res;
    };
    const prevOE = proto.specialPlantOnEnable;
    const newOE = function (...args) {
      try {
        this.__gpnMegaKills = 0;
        this.__gpnSpreadCursor = 0;
        this.__gpnMegaBurstAt = 0;
        this.__gpnMegaBurstAttr = null;
      } catch (e) {}
      return prevOE.apply(this, args);
    };
    let commonShotCls = null;
    try {
      commonShotCls = engine.getClassByName('commonShot') || null;
    } catch (e) { commonShotCls = null; }
    let prevDeal = null;
    let newDeal = null;
    let prevCE = null;
    let newCE = null;
    if (commonShotCls && commonShotCls.prototype) {
      if (typeof commonShotCls.prototype.dealDamageToZombie === 'function') {
        prevDeal = commonShotCls.prototype.dealDamageToZombie;
        newDeal = function (zombie, ...rest) {
          const wasAlive = zombie && typeof zombie.isAlive === 'function' ? zombie.isAlive() : false;
          const res = prevDeal.apply(this, arguments);
          try {
            if (
              this.__gpnMegaPea && zombie && typeof zombie.isAlive === 'function' &&
              wasAlive && !zombie.isAlive()
            ) {
              const owner = this.__gpnMegaOwner;
              if (owner && typeof owner.__gpnMegaKills === 'number') {
                owner.__gpnMegaKills += 1;
              }
            }
          } catch (e) {}
          return res;
        };
        commonShotCls.prototype.dealDamageToZombie = newDeal;
      }
      if (typeof commonShotCls.prototype.characterOnEnable === 'function') {
        prevCE = commonShotCls.prototype.characterOnEnable;
        newCE = function (...args) {
          try {
            this.__gpnMegaPea = false;
            this.__gpnMegaOwner = null;
          } catch (e) {}
          return prevCE.apply(this, args);
        };
        commonShotCls.prototype.characterOnEnable = newCE;
      }
    }
    proto._shoot = newShoot;
    proto._shootPeaAnimation = newSPA;
    proto.specialPlantOnEnable = newOE;
    cleanups.push(() => {
      try {
        if (proto._shoot === newShoot) proto._shoot = prevShoot;
        if (proto._shootPeaAnimation === newSPA) proto._shootPeaAnimation = prevSPA;
        if (proto.specialPlantOnEnable === newOE) proto.specialPlantOnEnable = prevOE;
        if (commonShotCls && commonShotCls.prototype) {
          if (newDeal && commonShotCls.prototype.dealDamageToZombie === newDeal) {
            commonShotCls.prototype.dealDamageToZombie = prevDeal;
          }
          if (newCE && commonShotCls.prototype.characterOnEnable === newCE) {
            commonShotCls.prototype.characterOnEnable = prevCE;
          }
        }
      } catch (e) {}
    });
    if (log) log.info('PEP [OurMegaGatling] active: attr chance=' + MEGA_ATTR_CHANCE + ' pool=' + MEGA_ATTR_POOL.length + ', kill bonus=' + MEGA_KILL_BONUS + ' cap=' + MEGA_KILL_MAX + ' (base 0.03), ult spread=' + (MEGA_ULT_SPREAD_ANGLES ? MEGA_ULT_SPREAD_ANGLES.length : 0) + ' angles, burst unify=' + MEGA_BURST_UNIFY_MS + 'ms');
  })();
  const pepArmOf = (d) => { try { return typeof d.armature === 'function' ? d.armature() : d._armature || (d._displayProxy && d._displayProxy._armature) || null; } catch (e) { return null; } };
  const pepCollectSlots = (arm, out, seen) => {
    try {
      if (!arm || seen.has(arm)) return out;
      seen.add(arm);
      const cur = typeof arm.getSlots === 'function' ? arm.getSlots() : Array.isArray(arm._slots) ? arm._slots : [];
      for (const s of cur) { if (!s) continue; out.push(s); pepCollectSlots(s.childArmature || s._childArmature, out, seen); }
    } catch (e) {}
    return out;
  };
  const pepCloneRuntime = (src) => {
    if (!src || (typeof src !== 'object' && typeof src !== 'function')) return src;
    const c = Object.create(Object.getPrototypeOf(src));
    for (const k of Reflect.ownKeys(src)) { try { const d = Object.getOwnPropertyDescriptor(src, k); if (d) Object.defineProperty(c, k, d); else c[k] = src[k]; } catch (e) { try { c[k] = src[k]; } catch (e2) {} } }
    return c;
  };
  const pepCloneSpriteFrame = (sf, tex, SF) => {
    if (!sf) return null;
    let f = null;
    try { if (typeof sf.clone === 'function') f = sf.clone(); } catch (e) {}
    if (!f && typeof SF === 'function') { try { f = new SF(); } catch (e) {} }
    if (!f || f === sf) f = pepCloneRuntime(sf);
    try { f.texture = tex; } catch (e) { try { f._texture = tex; } catch (e2) { return null; } }
    try { if (f.texture !== tex) f._texture = tex; } catch (e) {}
    return f;
  };
  const pepDimsMatch = (a, b, allowPrimalBig = false) => {
    const aw = Number(a && a.width), ah = Number(a && a.height);
    const bw = Number(b && b.width), bh = Number(b && b.height);
    if (aw > 0 && ah > 0 && bw > 0 && bh > 0) {
      if (aw === bw && ah === bh) return true;
      if (allowPrimalBig && aw === 256 && ah === 512 && bw === 512 && bh === 512) return true;
      return false;
    }
    return true;
  };
  const pepApplySlotTex = (rec) => {
    try {
      if (!rec.active || !rec.slot || !rec.targetTexture) return false;
      const h = rec.host;
      if (h && (!h.node || !h.node.isValid || h.dead || h[rec.formFlag] !== true)) return false;
      const td = rec.slot._textureData;
      const sf = td && td.spriteFrame;
      if (!sf || !pepDimsMatch(sf.texture, rec.targetTexture, rec.allowBig === true)) return false;
      try {
        const tex = rec.targetTexture;
        const srcTex = sf.texture;
        if (typeof tex.setFilters === 'function' && srcTex && Number.isFinite(srcTex._minFilter)) {
          tex.setFilters(srcTex._minFilter, srcTex._magFilter);
        }
      } catch (e) {}
      if (sf.texture === rec.targetTexture) return true;
      const data = pepCloneRuntime(td);
      if (!data) return false;
      data.spriteFrame = pepCloneSpriteFrame(sf, rec.targetTexture, rec.SpriteFrame);
      if (!data.spriteFrame) return false;
      if (rec.regionOverride) {
        try {
          const region = pepCloneRuntime(data.region) ?? {};
          for (const k of ['x', 'y', 'width', 'height']) region[k] = rec.regionOverride[k];
          data.region = region;
          data.frame = null;
          data.rotated = false;
        } catch (e) {}
        try {
          const frame = data.spriteFrame;
          const rx = Number(rec.regionOverride.x), ry = Number(rec.regionOverride.y);
          const rw = Number(rec.regionOverride.width), rh = Number(rec.regionOverride.height);
          if ([rx, ry, rw, rh].every(Number.isFinite)) {
            const setVec = (prop, vals) => {
              try {
                let cur = null;
                try { cur = frame[prop]; } catch (e) {}
                if (!cur) { try { cur = frame['_' + prop]; } catch (e) {} }
                if (cur && typeof cur.set === 'function') { try { cur.set(...vals); return true; } catch (e) {} }
                if (cur && typeof cur === 'object') {
                  try {
                    if (prop === 'originalSize') { Object.assign(cur, { width: vals[0], height: vals[1] }); delete cur.x; delete cur.y; }
                    else Object.assign(cur, { x: vals[0], y: vals[1], ...(vals.length > 2 ? { width: vals[2], height: vals[3] } : {}) });
                    return true;
                  } catch (e) {}
                }
                try { frame[prop] = prop === 'originalSize' ? { width: vals[0], height: vals[1] } : { x: vals[0], y: vals[1], width: vals[2], height: vals[3] }; return true; } catch (e) { try { frame['_' + prop] = prop === 'originalSize' ? { width: vals[0], height: vals[1] } : { x: vals[0], y: vals[1], width: vals[2], height: vals[3] }; return true; } catch (e2) { return false; } }
              } catch (e) { return false; }
            };
            setVec('rect', [rx, ry, rw, rh]);
            setVec('originalSize', [rw, rh]);
            setVec('offset', [0, 0]);
            try { frame.rotated = false; } catch (e) { try { frame._rotated = false; } catch (e2) {} }
            try { if (typeof frame._calculateUV === 'function') frame._calculateUV(); } catch (e) {}
          }
        } catch (e) {}
      }
      if (rec.pivotOverride) {
        try {
          if (rec.pivotOverride.relative === true) {
            rec.slot._pivotX = (rec.originalPivotX ?? 0) + rec.pivotOverride.pivotX;
            rec.slot._pivotY = (rec.originalPivotY ?? 0) + rec.pivotOverride.pivotY;
          } else {
            rec.slot._pivotX = rec.pivotOverride.pivotX;
            rec.slot._pivotY = rec.pivotOverride.pivotY;
          }
          rec.slot._transformDirty = true;
          rec.slot._worldMatrixDirty = true;
        } catch (e) {}
      }
      rec.slot._textureData = data;
      if (rec.slot._updateFrame) rec.slot._updateFrame();
      if (rec.regionOverride && rec.slot._updateTransform) rec.slot._updateTransform();
      return true;
    } catch (e) { return false; }
  };
  const pepInstallTexState = (host, tex, formFlag, opts = null) => {
    try {
      const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
      const display = host.anmControl ? host.anmControl.db : null;
      const arm = pepArmOf(display);
      if (!cc || !display || !arm) return null;
      const slotNameOf = (slot) => { try { return String(slot.name ?? (slot._slotData && slot._slotData.name) ?? ''); } catch (e) { return ''; } };
      const records = pepCollectSlots(arm, [], new Set()).map((slot) => {
        const name = slotNameOf(slot);
        const ov = (opts && opts.regions && opts.regions[name]) || null;
        const pv = (opts && opts.pivots && opts.pivots[name]) || null;
        const rec = { slot, host, formFlag, src: true, SpriteFrame: cc.SpriteFrame, originalTextureData: slot._textureData, originalUpdate: slot._updateDisplayData, hadOwn: Object.prototype.hasOwnProperty.call(slot, '_updateDisplayData'), active: true, targetTexture: tex, hooked: false, allowBig: !!(opts && opts.allowBig), regionOverride: ov, pivotOverride: pv, originalPivotX: Number(slot._pivotX ?? 0), originalPivotY: Number(slot._pivotY ?? 0) };
        try {
          const st = slot.getTexture ? slot.getTexture()
            : slot._textureData && slot._textureData.spriteFrame ? slot._textureData.spriteFrame.texture : null;
          if (st && typeof tex.setFilters === 'function' && Number.isFinite(st._minFilter)) {
            tex.setFilters(st._minFilter, st._magFilter);
          }
        } catch (e) {}
        if (typeof rec.originalUpdate === 'function') {
          const wrapped = function (...args) {
            try {
              const h = rec.host;
              const ok = h && !h.dead && h.node && h.node.isValid && h[rec.formFlag] === true;
              if (!ok) {
                rec.active = false;
                if (rec.hooked) { if (rec.hadOwn) slot._updateDisplayData = rec.originalUpdate; else delete slot._updateDisplayData; rec.hooked = false; }
                try { slot._textureData = rec.originalTextureData; if (slot._updateFrame) slot._updateFrame(); } catch (e) {}
                return rec.originalUpdate.apply(this, args);
              }
            } catch (e) {}
            const r = rec.originalUpdate.apply(this, args);
            pepApplySlotTex(rec);
            return r;
          };
          try { slot._updateDisplayData = wrapped; rec.hooked = slot._updateDisplayData === wrapped; } catch (e) {}
        }
        pepApplySlotTex(rec);
        return rec;
      });
      try { if (display.markForUpdateRenderData) display.markForUpdateRenderData(); } catch (e) {}
      return { display, records, active: true };
    } catch (e) { return null; }
  };
  const pepRestoreTexState = (st) => {
    if (!st || !st.active) return;
    st.active = false;
    for (const rec of st.records) {
      const slot = rec.slot;
      if (!slot) continue;
      try {
        if (rec.hooked) { if (rec.hadOwn) slot._updateDisplayData = rec.originalUpdate; else delete slot._updateDisplayData; }
        if (typeof rec.originalUpdate === 'function') rec.originalUpdate.call(slot);
        else slot._textureData = rec.originalTextureData;
        if (slot._updateFrame) slot._updateFrame();
      } catch (e) { try { slot._textureData = rec.originalTextureData; if (slot._updateFrame) slot._updateFrame(); } catch (e2) {} }
    }
    try { if (st.display && st.display.markForUpdateRenderData) st.display.markForUpdateRenderData(); } catch (e) {}
  };
  const clearAllForms = (host) => {
    try {
      if (!host) return;
      if (host.__gpnFlameForm) host.__gpnFlameForm = false;
      host.__gpnFlamePea = null;
      host.__gpnFlameFoodPea = null;
      pepRestoreTexState(host.__gpnFormState);
      host.__gpnFormState = null;
      if (host.__gpnElectricForm) host.__gpnElectricForm = false;
      host.__gpnElecPea = null;
      host.__gpnElecFoodPea = null;
      try {
        const od = host._objdataOwn || null;
        if (od) {
          od.CallsElectricCurrant = false;
          od.RedAttackStunDuration = undefined;
          if (host.__gpnElecCurrantBackup) {
            od.CallsElectricCurrant = host.__gpnElecCurrantBackup.calls ?? false;
            od.RedAttackStunDuration = host.__gpnElecCurrantBackup.stun;
          }
        }
        host.__gpnElecCurrantBackup = null;
        try { host.highRedCD = 0; } catch (e2) {}
        try { if (typeof host.shouldMaterial === 'function') host.shouldMaterial(); } catch (e2) {}
      } catch (e2) {}
      try {
        const spark = host.__gpnElecSpark;
        if (spark) {
          if (spark.timer) { try { clearInterval(spark.timer); activeTimers.delete(spark.timer); } catch (e3) {} }
          if (spark.node) { if (spark.node.destroy) spark.node.destroy(); else spark.node.active = false; }
        }
        host.__gpnElecSpark = null;
      } catch (e2) {}
      pepRestoreTexState(host.__gpnElecFormState);
      host.__gpnElecFormState = null;
      host.__gpnForm = null;
      host.__gpnFormPea = null;
      host.__gpnFormFoodPea = null;
      if (host.__gpnIceForm) host.__gpnIceForm = false;
      if (host.__gpnGooForm) host.__gpnGooForm = false;
      if (host.__gpnPrimalForm) host.__gpnPrimalForm = false;
      if (host.__gpnShadowForm) host.__gpnShadowForm = false;
      pepRestoreTexState(host.__gpnIceFormState);
      host.__gpnIceFormState = null;
      pepRestoreTexState(host.__gpnGooFormState);
      host.__gpnGooFormState = null;
      pepRestoreTexState(host.__gpnPrimalFormState);
      host.__gpnPrimalFormState = null;
      pepRestoreTexState(host.__gpnShadowFormState);
      host.__gpnShadowFormState = null;
    } catch (e) {}
  };
  (function installFlameGatling() {
    const MG = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('MegaGatlingPeaPlant') : null;
    const FIRE = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('FirePeashooterPlant') : null;
    if (!MG || !MG.prototype || !FIRE || !FIRE.prototype) {
      if (log) log.warn('PEP: MegaGatling/FirePeashooter class missing, flame gatling skipped');
      return;
    }
    const ATLAS = 'assets/atlases/mega-gatling-fire.png.b64';
    let texPromise = null;
    const loadHtmlImage = (b64) => new Promise((resolve, reject) => {
      try {
        const img = typeof Image === 'function' ? new Image() : document.createElement('img');
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error('atlas decode failed'));
        img.src = 'data:image/png;base64,' + b64;
      } catch (e) { reject(e); }
    });
    const getFireTexture = () => {
      if (texPromise) return texPromise;
      texPromise = (async () => {
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        if (!cc || !cc.ImageAsset || !cc.Texture2D) throw new Error('no cc tex api');
        let enc = null;
        try { enc = await ctx.data.readText(ATLAS); } catch (e) {}
        if (!enc || typeof enc !== 'string') throw new Error('atlas missing ' + ATLAS);
        const img = await loadHtmlImage(enc.trim());
        if (img.width !== 256 || img.height !== 512) throw new Error('bad atlas size');
        const tex = new cc.Texture2D();
        tex.image = new cc.ImageAsset(img);
        return tex;
      })();
      texPromise.catch(() => { texPromise = null; });
      return texPromise;
    };
    const armOf = (d) => { try { return typeof d.armature === 'function' ? d.armature() : d._armature || (d._displayProxy && d._displayProxy._armature) || null; } catch (e) { return null; } };
    const collectSlots = (arm, out, seen) => {
      try {
        if (!arm || seen.has(arm)) return out;
        seen.add(arm);
        const cur = typeof arm.getSlots === 'function' ? arm.getSlots() : Array.isArray(arm._slots) ? arm._slots : [];
        for (const s of cur) { if (!s) continue; out.push(s); collectSlots(s.childArmature || s._childArmature, out, seen); }
      } catch (e) {}
      return out;
    };
    const cloneRuntime = (src) => {
      if (!src || (typeof src !== 'object' && typeof src !== 'function')) return src;
      const c = Object.create(Object.getPrototypeOf(src));
      for (const k of Reflect.ownKeys(src)) { try { const d = Object.getOwnPropertyDescriptor(src, k); if (d) Object.defineProperty(c, k, d); else c[k] = src[k]; } catch (e) { try { c[k] = src[k]; } catch (e2) {} } }
      return c;
    };
    const cloneSpriteFrame = (sf, tex, SF) => {
      if (!sf) return null;
      let f = null;
      try { if (typeof sf.clone === 'function') f = sf.clone(); } catch (e) {}
      if (!f && typeof SF === 'function') { try { f = new SF(); } catch (e) {} }
      if (!f || f === sf) f = cloneRuntime(sf);
      try { f.texture = tex; } catch (e) { try { f._texture = tex; } catch (e2) { return null; } }
      try { if (f.texture !== tex) f._texture = tex; } catch (e) {}
      return f;
    };
    const dimsMatch = (a, b) => {
      const aw = Number(a && a.width), ah = Number(a && a.height);
      const bw = Number(b && b.width), bh = Number(b && b.height);
      if (aw > 0 && ah > 0 && bw > 0 && bh > 0) return aw === bw && ah === bh;
      return true;
    };
    const applySlotTex = (rec) => {
      try {
        if (!rec.active || !rec.slot || !rec.targetTexture) return false;
        const h = rec.host;
        if (h && (!h.node || !h.node.isValid || h.dead || h.__gpnFlameForm !== true)) return false;
        const td = rec.slot._textureData;
        const sf = td && td.spriteFrame;
        if (!sf || !dimsMatch(sf.texture, rec.targetTexture)) return false;
        try {
          const tex = rec.targetTexture;
          const srcTex = sf.texture;
          if (typeof tex.setFilters === 'function' && srcTex && Number.isFinite(srcTex._minFilter)) {
            tex.setFilters(srcTex._minFilter, srcTex._magFilter);
          }
        } catch (e) {}
        if (sf.texture === rec.targetTexture) return true;
        const data = cloneRuntime(td);
        if (!data) return false;
        data.spriteFrame = cloneSpriteFrame(sf, rec.targetTexture, rec.SpriteFrame);
        if (!data.spriteFrame) return false;
        rec.slot._textureData = data;
        if (rec.slot._updateFrame) rec.slot._updateFrame();
        return true;
      } catch (e) { return false; }
    };
    const installTexState = (host, tex) => {
      try {
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        const display = host.anmControl ? host.anmControl.db : null;
        const arm = armOf(display);
        if (!cc || !display || !arm) return null;
        const records = collectSlots(arm, [], new Set()).map((slot) => {
          const rec = { slot, host, src: true, SpriteFrame: cc.SpriteFrame, originalTextureData: slot._textureData, originalUpdate: slot._updateDisplayData, hadOwn: Object.prototype.hasOwnProperty.call(slot, '_updateDisplayData'), active: true, targetTexture: tex, hooked: false };
          try {
            const st = slot.getTexture ? slot.getTexture()
              : slot._textureData && slot._textureData.spriteFrame ? slot._textureData.spriteFrame.texture : null;
            if (st && typeof tex.setFilters === 'function' && Number.isFinite(st._minFilter)) {
              tex.setFilters(st._minFilter, st._magFilter);
            }
          } catch (e) {}
          if (typeof rec.originalUpdate === 'function') {
            const wrapped = function (...args) {
              try {
                const h = rec.host;
                const ok = h && !h.dead && h.node && h.node.isValid && h.__gpnFlameForm === true;
                if (!ok) {
                  rec.active = false;
                  if (rec.hooked) { if (rec.hadOwn) slot._updateDisplayData = rec.originalUpdate; else delete slot._updateDisplayData; rec.hooked = false; }
                  try { slot._textureData = rec.originalTextureData; if (slot._updateFrame) slot._updateFrame(); } catch (e) {}
                  return rec.originalUpdate.apply(this, args);
                }
              } catch (e) {}
              const r = rec.originalUpdate.apply(this, args);
              applySlotTex(rec);
              return r;
            };
            try { slot._updateDisplayData = wrapped; rec.hooked = slot._updateDisplayData === wrapped; } catch (e) {}
          }
          applySlotTex(rec);
          return rec;
        });
        try { if (display.markForUpdateRenderData) display.markForUpdateRenderData(); } catch (e) {}
        return { display, records, active: true };
      } catch (e) { return null; }
    };
    const restoreTexState = (st) => {
      if (!st || !st.active) return;
      st.active = false;
      for (const rec of st.records) {
        const slot = rec.slot;
        if (!slot) continue;
        try {
          if (rec.hooked) { if (rec.hadOwn) slot._updateDisplayData = rec.originalUpdate; else delete slot._updateDisplayData; }
          if (typeof rec.originalUpdate === 'function') rec.originalUpdate.call(slot);
          else slot._textureData = rec.originalTextureData;
          if (slot._updateFrame) slot._updateFrame();
        } catch (e) { try { slot._textureData = rec.originalTextureData; if (slot._updateFrame) slot._updateFrame(); } catch (e2) {} }
      }
      try { if (st.display && st.display.markForUpdateRenderData) st.display.markForUpdateRenderData(); } catch (e) {}
    };
    const doFuse = (host) => {
      try {
        if (host.__gpnFlameForm) return;
        clearAllForms(host);
        host.__gpnFlameForm = true;
        host.__gpnFlamePea = 'pea_flame_yellow';   
        host.__gpnFlameFoodPea = 'pea_flame_blue'; 
        getFireTexture().then((tex) => {
          try {
            if (!host.node || !host.node.isValid || host.dead || !host.__gpnFlameForm) return;
            restoreTexState(host.__gpnFormState);
            host.__gpnFormState = null;
            const st = installTexState(host, tex);
            if (st) host.__gpnFormState = st;
          } catch (e) {}
        }).catch(() => {});
        if (log) log.info('PEP [FlameGatling] fused: MegaGatling + FirePeashooter -> flame gatling (atk=pea_flame_yellow food=pea_flame_blue)');
      } catch (e) {}
    };
    const unfuse = (host) => {
      try {
        if (host.__gpnFlameForm) host.__gpnFlameForm = false;
        host.__gpnFlamePea = null;
        host.__gpnFlameFoodPea = null;
        restoreTexState(host.__gpnFormState);
        host.__gpnFormState = null;
      } catch (e) {}
    };
    try {
      const LnC = engine.getClassByName ? engine.getClassByName('LnC') : null;
      if (LnC && LnC.prototype && typeof LnC.prototype.putPlantAvailable === 'function' && !LnC.prototype.__gpnFlameOverlap) {
        LnC.prototype.__gpnFlameOverlap = true;
        const orig = LnC.prototype.putPlantAvailable;
        LnC.prototype.putPlantAvailable = function (t, e, n, i, o, a) {
          try {
            const id = Number(e);
            if (id === 9 || id === 16) {
              const arr = this.plantInSquare;
              if (Array.isArray(arr) && arr.length > 0) {
                const need = id === 9 ? 16 : 9; 
                let has = false;
                try {
                  has = arr.some((pl) => {
                    try {
                      if (!pl || pl.dead) return false;
                      const pid = Number(pl.ID != null ? pl.ID : pl._plantID);
                      if (pid === need) return true;
                      if (need === 16 && pl.constructor === FIRE) return true;
                      if (need === 9 && (pid === 9 || pl.constructor === MG)) return true;
                      return false;
                    } catch (e2) { return false; }
                  });
                } catch (e2) { has = false; }
                if (has) {
                  if (log) log.info('PEP [FlameGatling] overlap allow: plant=' + id + ' need=' + need + ' sq=' + arr.length);
                  return true; 
                }
                if (log) log.info('PEP [FlameGatling] overlap deny: plant=' + id + ' need=' + need + ' sq=' + arr.length);
              }
            }
          } catch (e) {}
          return orig.apply(this, arguments);
        };
        cleanups.push(() => {
          try { if (LnC.prototype.putPlantAvailable && LnC.prototype.__gpnFlameOverlap) LnC.prototype.putPlantAvailable = orig; } catch (e) {}
          try { delete LnC.prototype.__gpnFlameOverlap; } catch (e) {}
        });
        if (log) log.info('PEP [FlameGatling] overlap planting ON via putPlantAvailable (MG+Fire only)');
      }
    } catch (e) {}
    let scanTimer = null;
    try {
      scanTimer = setInterval(() => {
        try {
          const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
          const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
          if (!cc || !PlantF) return;
          const scene = cc.director.getScene();
          if (!scene) return;
          const list = scene.getComponentsInChildren(PlantF);
          if (!Array.isArray(list)) return;
          for (const p of list) {
            try {
              if (!p.node || !p.node.isValid || p.dead) continue;
              const lc = p.plantInLnC || p.inLnC;
              if (!lc || !lc.plantInSquare || !lc.plantInSquare.length) continue;
              const isMG = p.constructor === MG || p.ID === 9;
              const isFire = p.constructor === FIRE || p.ID === 16;
              if (!isMG && !isFire) continue;
              for (const other of lc.plantInSquare) {
                if (!other || other === p || !other.node || !other.node.isValid || other.dead) continue;
                if (isMG && (other.constructor === FIRE || other.ID === 16)) {
                  if (other.__gpnFlameAbsorbed) continue;
                  other.__gpnFlameAbsorbed = true;
                  try { if (other.node) other.node.active = false; } catch (e) {}
                  const idx = lc.plantInSquare.indexOf(other);
                  if (idx >= 0) lc.plantInSquare.splice(idx, 1);
                  try { if (typeof lc.readIndex === 'function') lc.readIndex(); } catch (e) {}
                  doFuse(p);
                  break;
                }
                if (isFire && (other.constructor === MG || other.ID === 9)) {
                  if (p.__gpnFlameAbsorbed) continue;
                  p.__gpnFlameAbsorbed = true;
                  try { if (p.node) p.node.active = false; } catch (e) {}
                  const idx = lc.plantInSquare.indexOf(p);
                  if (idx >= 0) lc.plantInSquare.splice(idx, 1);
                  try { if (typeof lc.readIndex === 'function') lc.readIndex(); } catch (e) {}
                  doFuse(other);
                  break;
                }
              }
            } catch (e) {}
          }
        } catch (e) {}
      }, 200);
      cleanups.push(() => { try { clearInterval(scanTimer); } catch (e) {} });
    } catch (e) {}
    try {
      const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
      if (PlantF && PlantF.prototype && !PlantF.prototype.__gpnFlameCOD) {
        PlantF.prototype.__gpnFlameCOD = true;
        const prevCOD = PlantF.prototype.characterOnDisable;
        PlantF.prototype.characterOnDisable = function (...args) {
          try { if (this.__gpnFlameForm === true) unfuse(this); } catch (e) {}
          return prevCOD.apply(this, args);
        };
        cleanups.push(() => {
          try { if (PlantF.prototype.characterOnDisable && PlantF.prototype.__gpnFlameCOD) PlantF.prototype.characterOnDisable = prevCOD; } catch (e) {}
          try { delete PlantF.prototype.__gpnFlameCOD; } catch (e) {}
        });
      }
    } catch (e) {}
  })();
  {
    try {
      if (ctx && ctx.settings && typeof ctx.settings.set === 'function') {
        ctx.settings.set('__pep_fire_block__', 'loaded').catch(() => {});
      }
    } catch (e) {}
    const FIRE_EXPORT = 'assets/atlases/firepeashooter-export.png.b64';
    let fireExported = false;
    const doExportFire = async () => {
      try {
        if (fireExported) return;
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        const FIRE = engine.getClassByName ? engine.getClassByName('FirePeashooterPlant') : null;
        pepDiag.export = 'cc=' + !!cc + ' fire=' + !!FIRE;
        if (!cc || !FIRE) return;
        const scene = cc.director.getScene();
        if (!scene) return;
        const list = scene.getComponentsInChildren(FIRE);
        pepDiag.export += ' count=' + (Array.isArray(list) ? list.length : 'n/a');
        if (!Array.isArray(list) || !list.length) return;
        const plant = list[0];
        const display = plant.anmControl ? plant.anmControl.db : null;
        pepDiag.export += ' anm=' + !!display;
        if (!display || !display.armature) return;
        const arm = typeof display.armature === 'function' ? display.armature() : null;
        pepDiag.export += ' arm=' + !!arm;
        if (!arm) return;
        const slots = typeof arm.getSlots === 'function' ? arm.getSlots() : [];
        pepDiag.export += ' slots=' + slots.length;
        for (const s of slots) {
          try {
            const tex = s.getTexture ? s.getTexture() : null;
            const img = tex && tex.image && (tex.image._image || tex.image.image || tex.image);
            if (img && (typeof img.toDataURL === 'function' || typeof img.src === 'string')) {
              const canvas = document.createElement('canvas');
              canvas.width = img.naturalWidth || img.width || 256;
              canvas.height = img.naturalHeight || img.height || 512;
              const g = canvas.getContext('2d');
              g.clearRect(0, 0, canvas.width, canvas.height);
              g.drawImage(img, 0, 0);
              const dataUrl = canvas.toDataURL('image/png');
              const b64 = dataUrl.replace(/^data:image\/png;base64,/, '');
              pepDiag.export += ' img=' + canvas.width + 'x' + canvas.height;
              try {
                if (ctx && ctx.settings && typeof ctx.settings.set === 'function') {
                  await ctx.settings.set('__pep_fire_export__', b64);
                  fireExported = true;
                  pepDiag.export += ' saved';
                  if (log) log.info('PEP [ExportFire] saved ' + canvas.width + 'x' + canvas.height + ' via settings');
                }
              } catch (e) {
                pepDiag.export += ' save-err:' + (e && e.message);
              }
              return;
            }
          } catch (e) { pepDiag.export += ' slot-err'; }
        }
        if (log) log.warn('PEP [ExportFire] no slot texture found: ' + pepDiag.export);
      } catch (e) {}
    };
    let fireExportTimer = null;
    try {
      fireExportTimer = setInterval(async () => {
        try {
          await doExportFire();
          try {
            if (ctx && ctx.settings && typeof ctx.settings.set === 'function') {
              await ctx.settings.set('__pep_diag__', {
                t: pepDiag.t, enum: pepDiag.enum, feat: pepDiag.feat,
                store: pepDiag.store, lc: pepDiag.lc, pfc: pepDiag.pfc, rc: pepDiag.rc, au: pepDiag.au, bw: pepDiag.bw,
                injected: pepUpgradeInjected,
                sample: pepDiag.sample || '', sampleCount: pepDiag.sampleCount || 0,
                lastItem: pepDiag.lastItem || '', lastRender: pepDiag.lastRender || '',
                feats: pepDiag.feats || '', export: pepDiag.export || '',
              });
            }
          } catch (e) {}
        } catch (e) {}
        if (fireExported) { clearInterval(fireExportTimer); fireExportTimer = null; }
      }, 1000);
      cleanups.push(() => { try { if (fireExportTimer) clearInterval(fireExportTimer); } catch (e) {} });
    } catch (e) {}
  }
  (function installElectricGatling() {
    const MG2 = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('MegaGatlingPeaPlant') : null;
    const ELEC = engine && typeof engine.getClassByName === 'function' ? (engine.getClassByName('ElectricPeashooterPlant') || engine.getClassByName('ElectricPeashooter')) : null;
    if (!MG2 || !MG2.prototype || !ELEC || !ELEC.prototype) {
      if (log) log.warn('PEP: MegaGatling/ElectricPeashooter class missing, electric gatling skipped');
      return;
    }
    const ATLAS = 'assets/atlases/mega-gatling-electric.png.b64';
    let texPromise = null;
    const loadHtmlImage = (b64) => new Promise((resolve, reject) => {
      try {
        const img = typeof Image === 'function' ? new Image() : document.createElement('img');
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error('atlas decode failed'));
        img.src = 'data:image/png;base64,' + b64;
      } catch (e) { reject(e); }
    });
    const getElectricTexture = () => {
      if (texPromise) return texPromise;
      texPromise = (async () => {
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        if (!cc || !cc.ImageAsset || !cc.Texture2D) throw new Error('no cc tex api');
        let enc = null;
        try { enc = await ctx.data.readText(ATLAS); } catch (e) {}
        if (!enc || typeof enc !== 'string') throw new Error('atlas missing ' + ATLAS);
        const img = await loadHtmlImage(enc.trim());
        if (img.width !== 256 || img.height !== 512) throw new Error('bad atlas size');
        const tex = new cc.Texture2D();
        tex.image = new cc.ImageAsset(img);
        return tex;
      })();
      texPromise.catch(() => { texPromise = null; });
      return texPromise;
    };
    const doElecFuse = (host, elecPlant) => {
      try {
        if (host.__gpnElectricForm) return;
        clearAllForms(host);
        host.__gpnElectricForm = true;
        host.__gpnElecPea = 'electricpea';       
        host.__gpnElecFoodPea = 'electricpea';   
        try {
          const od = host._objdataOwn || null;
          if (od) {
            if (!Object.prototype.hasOwnProperty.call(host, '__gpnElecCurrantBackup')) {
              host.__gpnElecCurrantBackup = {
                calls: od.CallsElectricCurrant,
                stun: od.RedAttackStunDuration,
              };
            }
            od.CallsElectricCurrant = true;
            od.RedAttackStunDuration = 0.25;
          }
        } catch (e) {}
        getElectricTexture().then((tex) => {
          try {
            if (!host.node || !host.node.isValid || host.dead || !host.__gpnElectricForm) return;
            pepRestoreTexState(host.__gpnElecFormState);
            host.__gpnElecFormState = null;
            const st = pepInstallTexState(host, tex, '__gpnElectricForm');
            if (st) host.__gpnElecFormState = st;
          } catch (e) {}
        }).catch(() => {});
        if (log) log.info('PEP [ElecGatling] fused: MegaGatling + ElectricPeashooter -> electric gatling (atk=electricpea food=electricpea)');
      } catch (e) {}
    };
    const unfuseElec = (host) => {
      try {
        if (host.__gpnElectricForm) host.__gpnElectricForm = false;
        host.__gpnElecPea = null;
        host.__gpnElecFoodPea = null;
        try {
          const od = host._objdataOwn || null;
          if (od) {
            od.CallsElectricCurrant = false;
            od.RedAttackStunDuration = undefined;
            if (host.__gpnElecCurrantBackup) {
              od.CallsElectricCurrant = host.__gpnElecCurrantBackup.calls ?? false;
              od.RedAttackStunDuration = host.__gpnElecCurrantBackup.stun;
            }
          }
          host.__gpnElecCurrantBackup = null;
          try { host.highRedCD = 0; } catch (e2) {}
          try { if (typeof host.shouldMaterial === 'function') host.shouldMaterial(); } catch (e2) {}
        } catch (e) {}
        try {
          const spark = host.__gpnElecSpark;
          if (spark) {
            if (spark.timer) { try { clearInterval(spark.timer); } catch (e) {} }
            if (spark.node) { if (spark.node.destroy) spark.node.destroy(); else spark.node.active = false; }
          }
          host.__gpnElecSpark = null;
        } catch (e) {}
        pepRestoreTexState(host.__gpnElecFormState);
        host.__gpnElecFormState = null;
      } catch (e) {}
    };
    try {
      const LnC = engine.getClassByName ? engine.getClassByName('LnC') : null;
      if (LnC && LnC.prototype && typeof LnC.prototype.putPlantAvailable === 'function' && !LnC.prototype.__gpnElecOverlap) {
        LnC.prototype.__gpnElecOverlap = true;
        const orig = LnC.prototype.putPlantAvailable;
        LnC.prototype.putPlantAvailable = function (t, e, n, i, o, a) {
          try {
            const id = Number(e);
            if (id === 9 || id === 66) {
              const arr = this.plantInSquare;
              if (Array.isArray(arr) && arr.length > 0) {
                const need = id === 9 ? 66 : 9;
                const has = arr.some((pl) => {
                  try {
                    if (!pl || pl.dead) return false;
                    const pid = Number(pl.ID != null ? pl.ID : pl._plantID);
                    if (pid === need) return true;
                    if (need === 66 && pl.constructor === ELEC) return true;
                    if (need === 9 && (pid === 9 || pl.constructor === MG2)) return true;
                    return false;
                  } catch (e2) { return false; }
                });
                if (has) return true;
              }
            }
          } catch (e) {}
          return orig.apply(this, arguments);
        };
        cleanups.push(() => {
          try { if (LnC.prototype.putPlantAvailable && LnC.prototype.__gpnElecOverlap) LnC.prototype.putPlantAvailable = orig; } catch (e) {}
          try { delete LnC.prototype.__gpnElecOverlap; } catch (e) {}
        });
        if (log) log.info('PEP [ElecGatling] overlap ON (MG+Electric)');
      }
    } catch (e) {}
    let elecScanTimer = null;
    try {
      elecScanTimer = setInterval(() => {
        try {
          const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
          const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
          if (!cc || !PlantF) return;
          const scene = cc.director.getScene();
          if (!scene) return;
          const list = scene.getComponentsInChildren(PlantF);
          if (!Array.isArray(list)) return;
          for (const p of list) {
            try {
              if (!p.node || !p.node.isValid || p.dead) continue;
              const lc = p.plantInLnC || p.inLnC;
              if (!lc || !lc.plantInSquare || !lc.plantInSquare.length) continue;
              const isMG = p.constructor === MG2 || p.ID === 9;
              const isElec = p.constructor === ELEC || p.ID === 66;
              if (!isMG && !isElec) continue;
              for (const other of lc.plantInSquare) {
                if (!other || other === p || !other.node || !other.node.isValid || other.dead) continue;
                if (isMG && (other.constructor === ELEC || other.ID === 66)) {
                  if (other.__gpnElecAbsorbed) continue;
                  other.__gpnElecAbsorbed = true;
                  try { if (other.node) other.node.active = false; } catch (e) {}
                  const idx = lc.plantInSquare.indexOf(other);
                  if (idx >= 0) lc.plantInSquare.splice(idx, 1);
                  try { if (typeof lc.readIndex === 'function') lc.readIndex(); } catch (e) {}
                  doElecFuse(p, other);
                  break;
                }
                if (isElec && (other.constructor === MG2 || other.ID === 9)) {
                  if (p.__gpnElecAbsorbed) continue;
                  p.__gpnElecAbsorbed = true;
                  try { if (p.node) p.node.active = false; } catch (e) {}
                  const idx = lc.plantInSquare.indexOf(p);
                  if (idx >= 0) lc.plantInSquare.splice(idx, 1);
                  try { if (typeof lc.readIndex === 'function') lc.readIndex(); } catch (e) {}
                  doElecFuse(other, p);
                  break;
                }
              }
            } catch (e) {}
          }
        } catch (e) {}
      }, 200);
      cleanups.push(() => { try { clearInterval(elecScanTimer); } catch (e) {} });
    } catch (e) {}
    try {
      const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
      if (PlantF && PlantF.prototype && !PlantF.prototype.__gpnElecCOD) {
        PlantF.prototype.__gpnElecCOD = true;
        const prevCOD = PlantF.prototype.characterOnDisable;
        PlantF.prototype.characterOnDisable = function (...args) {
          try { if (this.__gpnElectricForm === true) unfuseElec(this); } catch (e) {}
          return prevCOD.apply(this, args);
        };
        cleanups.push(() => {
          try { if (PlantF.prototype.characterOnDisable && PlantF.prototype.__gpnElecCOD) PlantF.prototype.characterOnDisable = prevCOD; } catch (e) {}
          try { delete PlantF.prototype.__gpnElecCOD; } catch (e) {}
        });
      }
    } catch (e) {}
  })();
  (function installElementGatlings() {
    const MG3 = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('MegaGatlingPeaPlant') : null;
    if (!MG3 || !MG3.prototype) {
      if (log) log.warn('PEP: MegaGatlingPeaPlant class missing, element gatlings skipped');
      return;
    }
    const ELEMS = [
      { id: 28,  clsNames: ['SnowPeaPlant', 'SnowPea'],            atlas: 'assets/atlases/mega-gatling-ice.png.b64',     pea: 'pea_snow',     enhPea: 'snowdrop_freeze', key: 'ice',     flag: '__gpnIceForm',     state: '__gpnIceFormState' },
      { id: 206, clsNames: ['GooPeashooterPlant', 'GooPeashooter'], atlas: 'assets/atlases/mega-gatling-goo.png.b64',     pea: 'pea_goo',      key: 'goo',     flag: '__gpnGooForm',     state: '__gpnGooFormState' },
      { id: 18,  clsNames: ['PrimalPeashooter', 'PrimalPeashooterPlant'], atlas: 'assets/atlases/mega-gatling-primal.png.b64', pea: 'pea_primal',  key: 'primal',  flag: '__gpnPrimalForm',  state: '__gpnPrimalFormState' },
    ];
    const ACTIVE = [];
    for (const f of ELEMS) {
      let cls = null;
      for (const cn of f.clsNames) { try { const c = engine.getClassByName(cn); if (c && c.prototype) { cls = c; break; } } catch (e) {} }
      if (cls) { f.cls = cls; ACTIVE.push(f); }
      else if (log) log.warn('PEP [ElemGatling] class missing for id=' + f.id + ' (' + f.clsNames.join('/') + '), skipped');
    }
    if (!ACTIVE.length) return;
    const texCache = new Map();
    const loadHtmlImage = (b64) => new Promise((resolve, reject) => {
      try {
        const img = typeof Image === 'function' ? new Image() : document.createElement('img');
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error('atlas decode failed'));
        img.src = 'data:image/png;base64,' + b64;
      } catch (e) { reject(e); }
    });
    const getElemTexture = (f) => {
      if (texCache.has(f.key)) return texCache.get(f.key);
      const p = (async () => {
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        if (!cc || !cc.ImageAsset || !cc.Texture2D) throw new Error('no cc tex api');
        let enc = null;
        try { enc = await ctx.data.readText(f.atlas); } catch (e) {}
        if (!enc || typeof enc !== 'string') throw new Error('atlas missing ' + f.atlas);
        const img = await loadHtmlImage(enc.trim());
        const expectW = f.key === 'primal' ? 512 : 256;
        const expectH = f.key === 'primal' ? 512 : 512;
        if (img.width !== expectW || img.height !== expectH) throw new Error('bad atlas size');
        const tex = new cc.Texture2D();
        tex.image = new cc.ImageAsset(img);
        return tex;
      })();
      p.catch(() => { texCache.delete(f.key); });
      texCache.set(f.key, p);
      return p;
    };
    const primalOpts = () => ({
      allowBig: true,
      regions: {
        helmet_UG: { x: 272, y: 16, width: 160, height: 128 }, 
      },
      pivots: {
        helmet_UG: { pivotX: 16, pivotY: 16, relative: true }, 
      },
    });
    const doElemFuse = (host, f) => {
      try {
        if (host[f.flag]) return;
        clearAllForms(host);
        host[f.flag] = true;
        host.__gpnForm = f.key;
        host.__gpnFormPea = f.pea;
        host.__gpnFormEnhPea = f.enhPea || f.pea; 
        host.__gpnFormFoodPea = f.enhPea || f.pea; 
        getElemTexture(f).then((tex) => {
          try {
            if (!host.node || !host.node.isValid || host.dead || !host[f.flag]) return;
            pepRestoreTexState(host[f.state]);
            host[f.state] = null;
            const st = pepInstallTexState(host, tex, f.flag, f.key === 'primal' ? primalOpts() : null);
            if (st) host[f.state] = st;
          } catch (e) {}
        }).catch(() => {});
        if (log) log.info('PEP [ElemGatling] fused: MegaGatling + id=' + f.id + ' -> ' + f.key + ' gatling (pea=' + f.pea + ')');
      } catch (e) {}
    };
    const unfuseElem = (host) => {
      try {
        for (const f of ACTIVE) {
          if (host[f.flag]) host[f.flag] = false;
          pepRestoreTexState(host[f.state]);
          host[f.state] = null;
        }
        host.__gpnForm = null;
        host.__gpnFormPea = null;
        host.__gpnFormEnhPea = null;
        host.__gpnFormFoodPea = null;
      } catch (e) {}
    };
    try {
      const LnC = engine.getClassByName ? engine.getClassByName('LnC') : null;
      if (LnC && LnC.prototype && typeof LnC.prototype.putPlantAvailable === 'function' && !LnC.prototype.__gpnElemOverlap) {
        LnC.prototype.__gpnElemOverlap = true;
        const orig = LnC.prototype.putPlantAvailable;
        LnC.prototype.putPlantAvailable = function (t, e, n, i, o, a) {
          try {
            const id = Number(e);
            if (id === 9 || ACTIVE.some((f) => f.id === id)) {
              const arr = this.plantInSquare;
              if (Array.isArray(arr) && arr.length > 0) {
                let has = false;
                if (id === 9) {
                  has = arr.some((pl) => {
                    try {
                      if (!pl || pl.dead) return false;
                      if (pl.__gpnRubyForm === true) return false;
                      const pid = Number(pl.ID != null ? pl.ID : pl._plantID);
                      return ACTIVE.some((f) => pid === f.id || pl.constructor === f.cls);
                    } catch (e2) { return false; }
                  });
                } else {
                  has = arr.some((pl) => {
                    try {
                      if (!pl || pl.dead) return false;
                      const pid = Number(pl.ID != null ? pl.ID : pl._plantID);
                      return pid === 9 || pl.constructor === MG3;
                    } catch (e2) { return false; }
                  });
                }
                if (has) return true;
              }
            }
          } catch (e) {}
          return orig.apply(this, arguments);
        };
        cleanups.push(() => {
          try { if (LnC.prototype.putPlantAvailable && LnC.prototype.__gpnElemOverlap) LnC.prototype.putPlantAvailable = orig; } catch (e) {}
          try { delete LnC.prototype.__gpnElemOverlap; } catch (e) {}
        });
        if (log) log.info('PEP [ElemGatling] overlap ON (MG + ice/goo/primal)');
      }
    } catch (e) {}
    let elemScanTimer = null;
    try {
      elemScanTimer = setInterval(() => {
        try {
          const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
          const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
          if (!cc || !PlantF) return;
          const scene = cc.director.getScene();
          if (!scene) return;
          const list = scene.getComponentsInChildren(PlantF);
          if (!Array.isArray(list)) return;
          for (const p of list) {
            try {
              if (!p.node || !p.node.isValid || p.dead) continue;
              const lc = p.plantInLnC || p.inLnC;
              if (!lc || !lc.plantInSquare || !lc.plantInSquare.length) continue;
              const isMG = p.constructor === MG3 || p.ID === 9;
              const isElem = !(p.__gpnRubyForm === true) && ACTIVE.some((f) => p.constructor === f.cls || p.ID === f.id);
              if (!isMG && !isElem) continue;
              for (const other of lc.plantInSquare) {
                if (!other || other === p || !other.node || !other.node.isValid || other.dead) continue;
                if (other.__gpnRubyForm === true) continue;
                const otherElem = ACTIVE.find((f) => other.constructor === f.cls || other.ID === f.id);
                if (isMG && otherElem) {
                  if (other.__gpnElemAbsorbed) continue;
                  other.__gpnElemAbsorbed = true;
                  try { if (other.node) other.node.active = false; } catch (e) {}
                  const idx = lc.plantInSquare.indexOf(other);
                  if (idx >= 0) lc.plantInSquare.splice(idx, 1);
                  try { if (typeof lc.readIndex === 'function') lc.readIndex(); } catch (e) {}
                  doElemFuse(p, otherElem);
                  break;
                }
                if (isElem && (other.constructor === MG3 || other.ID === 9)) {
                  if (p.__gpnElemAbsorbed) continue;
                  p.__gpnElemAbsorbed = true;
                  try { if (p.node) p.node.active = false; } catch (e) {}
                  const idx = lc.plantInSquare.indexOf(p);
                  if (idx >= 0) lc.plantInSquare.splice(idx, 1);
                  try { if (typeof lc.readIndex === 'function') lc.readIndex(); } catch (e) {}
                  const myElem = ACTIVE.find((f) => p.constructor === f.cls || p.ID === f.id);
                  if (myElem) doElemFuse(other, myElem);
                  break;
                }
              }
            } catch (e) {}
          }
        } catch (e) {}
      }, 200);
      cleanups.push(() => { try { clearInterval(elemScanTimer); } catch (e) {} });
    } catch (e) {}
    try {
      const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
      if (PlantF && PlantF.prototype && !PlantF.prototype.__gpnElemCOD) {
        PlantF.prototype.__gpnElemCOD = true;
        const prevCOD = PlantF.prototype.characterOnDisable;
        PlantF.prototype.characterOnDisable = function (...args) {
          try { if (this.__gpnForm) unfuseElem(this); } catch (e) {}
          return prevCOD.apply(this, args);
        };
        cleanups.push(() => {
          try { if (PlantF.prototype.characterOnDisable && PlantF.prototype.__gpnElemCOD) PlantF.prototype.characterOnDisable = prevCOD; } catch (e) {}
          try { delete PlantF.prototype.__gpnElemCOD; } catch (e) {}
        });
      }
    } catch (e) {}
  })();
  (function installShadowGatling() {
    const MG4 = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('MegaGatlingPeaPlant') : null;
    const SHADOW = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('ShadowPeashooterPlant') : null;
    if (!MG4 || !MG4.prototype || !SHADOW || !SHADOW.prototype) {
      if (log) log.warn('PEP: MegaGatling/ShadowPeashooter class missing, shadow gatling skipped');
      return;
    }
    const ATLAS = 'assets/atlases/shadow-gatling.png.b64';
    let SHADOW_SHARD_ANGLES = [-0.35, 0, 0.35]; 
    let SHADOW_KILL_DAMAGE_TYPE = 1;    
    const SHADOW_SRC_W = 1024, SHADOW_SRC_H = 1024;
    const SHADOW_ATLAS_W = 1024, SHADOW_ATLAS_H = 1536;
    const SHADOW_ACC_SLOT = 'COS0';
    const SHADOW_ACC_Z = 13.5;
    const SHADOW_EYE_PATTERN = /^eye_[RL](?:_closed)?(?:_|$)/i;
    const SHADOW_REGIONS = {
      L1:   { x: 16,  y: 1040, width: 273, height: 208, pivotX: 136.5, pivotY: 104 },
      L3:   { x: 304, y: 1040, width: 273, height: 208, pivotX: 136.5, pivotY: 104 },
      DARK1: { x: 592, y: 1040, width: 273, height: 208, pivotX: 136.5, pivotY: 104 },
      DARK3: { x: 16,  y: 1264, width: 273, height: 208, pivotX: 136.5, pivotY: 104 },
    };
    let texPromise = null;
    const shadowStates = new Map();
    const loadHtmlImage = (b64) => new Promise((resolve, reject) => {
      try {
        const img = typeof Image === 'function' ? new Image() : document.createElement('img');
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error('atlas decode failed'));
        img.src = 'data:image/png;base64,' + b64;
      } catch (e) { reject(e); }
    });
    const getShadowTexture = () => {
      if (texPromise) return texPromise;
      texPromise = (async () => {
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        if (!cc || !cc.ImageAsset || !cc.Texture2D) throw new Error('no cc tex api');
        let enc = null;
        try { enc = await ctx.data.readText(ATLAS); } catch (e) {}
        if (!enc || typeof enc !== 'string') throw new Error('atlas missing ' + ATLAS);
        const img = await loadHtmlImage(enc.trim());
        if (img.width !== SHADOW_ATLAS_W || img.height !== SHADOW_ATLAS_H) throw new Error('bad atlas size');
        const tex = new cc.Texture2D();
        tex.image = new cc.ImageAsset(img);
        return tex;
      })();
      texPromise.catch(() => { texPromise = null; });
      return texPromise;
    };
    const isShadowSrcTex = (slotName) => slotName === SHADOW_ACC_SLOT;
    const shadowRegionFor = (slotName, state) => {
      if (slotName !== SHADOW_ACC_SLOT) return null;
      if (state.dark) return state.upgraded ? SHADOW_REGIONS.DARK3 : SHADOW_REGIONS.DARK1;
      return state.upgraded ? SHADOW_REGIONS.L3 : SHADOW_REGIONS.L1;
    };
    const shadowDispIdx = (slotName) => {
      if (slotName === SHADOW_ACC_SLOT) return 0;
      return null;
    };
    const installShadowTexState = (plant, tex) => {
      try {
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        const display = plant.anmControl ? plant.anmControl.db : null;
        const arm = pepArmOf(display);
        if (!cc || !display || !arm) return null;
        const slotNameOf = (slot) => { try { return String(slot.name ?? (slot._slotData && slot._slotData.name) ?? ''); } catch (e) { return ''; } };
        const state = { display, armature: arm, records: [], upgraded: !!(plant.upgraded || plant._upgraded), dark: plant.ShadowPowered === true, active: true };
        state.records = pepCollectSlots(arm, [], new Set()).map((slot) => {
          const name = slotNameOf(slot);
          const hadOwn = Object.prototype.hasOwnProperty.call(slot, '_updateDisplayData');
          const origUpdate = slot._updateDisplayData;
          const rec = {
            slot, name, state, SpriteFrame: cc.SpriteFrame, targetTexture: tex, originalTextureData: slot._textureData,
            originalUpdate: origUpdate, hadOwn, originalDisplayIndex: Number(slot.displayIndex ?? slot._displayIndex ?? -1),
            originalPivotX: Number(slot._pivotX ?? 0), originalPivotY: Number(slot._pivotY ?? 0),
            originalZOrder: Number(slot._zOrder ?? 0), regionOverride: shadowRegionFor(name, state), active: true, hooked: false, eligible: false,
          };
          try {
            const diagTex = (() => { try { const st = slot.getTexture ? slot.getTexture() : (slot._textureData && slot._textureData.spriteFrame ? slot._textureData.spriteFrame.texture : null); return st ? st.width + 'x' + st.height : 'null'; } catch (e) { return 'err'; } })();
            pepDiag.elec = 'shadow[s=' + diagTex + ' t=' + (tex && tex.width) + 'x' + (tex && tex.height) + ' slot=' + name + ' disp=' + (slot.displayIndex ?? slot._displayIndex ?? '?') + ' reg=' + (rec.regionOverride ? (rec.regionOverride.x + ',' + rec.regionOverride.y) : '-') + ']';
          } catch (e) {}
          const wantIdx = shadowDispIdx(name);
          if (wantIdx !== null) {
            try { if (Number(slot.displayIndex) !== wantIdx) slot.displayIndex = wantIdx; } catch (e) { try { if (slot._setDisplayIndex) slot._setDisplayIndex(wantIdx, true); } catch (e2) {} }
          }
          let srcTex = null;
          try {
            srcTex = slot.getTexture ? slot.getTexture()
              : slot._textureData && slot._textureData.spriteFrame ? slot._textureData.spriteFrame.texture : null;
          } catch (e) {}
          rec.eligible = name === SHADOW_ACC_SLOT;
          if (srcTex && typeof tex.setFilters === 'function' && Number.isFinite(srcTex._minFilter)) {
            try { tex.setFilters(srcTex._minFilter, srcTex._magFilter); } catch (e) {}
          }
          if (typeof origUpdate === 'function') {
            const wrapped = function (...args) {
              const r = origUpdate.apply(this, args);
              try {
                const st = rec.state;
                if (!st || !st.active) return r;
                rec.regionOverride = shadowRegionFor(rec.name, st);
                const di = shadowDispIdx(rec.name);
                if (di !== null) {
                  try { if (Number(rec.slot.displayIndex) !== di) rec.slot.displayIndex = di; } catch (e) { try { if (rec.slot._setDisplayIndex) rec.slot._setDisplayIndex(di, true); } catch (e2) {} }
                }
                applyShadowSlotTex(rec);
              } catch (e) {}
              return r;
            };
            try { slot._updateDisplayData = wrapped; rec.hooked = slot._updateDisplayData === wrapped; } catch (e) {}
          }
          applyShadowSlotTex(rec);
          return rec;
        });
        const acc = state.records.find((r) => r.name === SHADOW_ACC_SLOT);
        if (acc && acc.slot) {
          try {
            if (typeof acc.slot._setZorder === 'function') acc.slot._setZorder(SHADOW_ACC_Z);
            else { acc.slot._zOrder = SHADOW_ACC_Z; acc.slot._zOrderDirty = true; }
          } catch (e) {}
          try { arm._slotsDirty = true; } catch (e) {}
        }
        try { if (display.markForUpdateRenderData) display.markForUpdateRenderData(); } catch (e) {}
        return state;
      } catch (e) { return null; }
    };
    const applyShadowSlotTex = (rec) => {
      try {
        if (!rec.active || !rec.slot || !rec.targetTexture) return false;
        if (rec.name !== SHADOW_ACC_SLOT) return false;
        const td = rec.slot._textureData;
        const sf = td && td.spriteFrame;
        if (!sf) return false;
        if (sf.texture !== rec.targetTexture && !isShadowSrcTex(rec.name)) return false;
        const reg = rec.regionOverride;
        const regSame = !reg || (Number(td.region && td.region.x) === reg.x && Number(td.region && td.region.y) === reg.y && Number(td.region && td.region.width) === reg.width && Number(td.region && td.region.height) === reg.height);
        if (sf.texture === rec.targetTexture && regSame) {
          if (reg) { rec.slot._pivotX = reg.pivotX; rec.slot._pivotY = reg.pivotY; rec.slot._transformDirty = true; rec.slot._worldMatrixDirty = true; }
          return true;
        }
        const data = pepCloneRuntime(td);
        if (!data) return false;
        data.spriteFrame = pepCloneSpriteFrame(sf, rec.targetTexture, rec.SpriteFrame);
        if (!data.spriteFrame) return false;
        if (reg) {
          try {
            const region = pepCloneRuntime(data.region) ?? {};
            for (const k of ['x', 'y', 'width', 'height']) region[k] = reg[k];
            data.region = region;
            data.frame = null;
            data.rotated = false;
          } catch (e) {}
          try {
            const frame = data.spriteFrame;
            const rx = Number(reg.x), ry = Number(reg.y), rw = Number(reg.width), rh = Number(reg.height);
            if ([rx, ry, rw, rh].every(Number.isFinite)) {
              const setVec = (prop, vals) => {
                try {
                  let cur = null;
                  try { cur = frame[prop]; } catch (e) {}
                  if (!cur) { try { cur = frame['_' + prop]; } catch (e) {} }
                  if (cur && typeof cur.set === 'function') { try { cur.set(...vals); return true; } catch (e) {} }
                  if (cur && typeof cur === 'object') {
                    try {
                      if (prop === 'originalSize') { Object.assign(cur, { width: vals[0], height: vals[1] }); delete cur.x; delete cur.y; }
                      else Object.assign(cur, { x: vals[0], y: vals[1], ...(vals.length > 2 ? { width: vals[2], height: vals[3] } : {}) });
                      return true;
                    } catch (e) {}
                  }
                  try { frame[prop] = prop === 'originalSize' ? { width: vals[0], height: vals[1] } : { x: vals[0], y: vals[1], width: vals[2], height: vals[3] }; return true; } catch (e) { try { frame['_' + prop] = prop === 'originalSize' ? { width: vals[0], height: vals[1] } : { x: vals[0], y: vals[1], width: vals[2], height: vals[3] }; return true; } catch (e2) { return false; } }
                } catch (e) { return false; }
              };
              setVec('rect', [rx, ry, rw, rh]);
              setVec('originalSize', [rw, rh]);
              setVec('offset', [0, 0]);
              try { frame.rotated = false; } catch (e) { try { frame._rotated = false; } catch (e2) {} }
              try { if (typeof frame._calculateUV === 'function') frame._calculateUV(); } catch (e) {}
            }
          } catch (e) {}
          try { rec.slot._pivotX = reg.pivotX; rec.slot._pivotY = reg.pivotY; rec.slot._transformDirty = true; rec.slot._worldMatrixDirty = true; } catch (e) {}
        }
        rec.slot._textureData = data;
        if (rec.slot._updateFrame) rec.slot._updateFrame();
        if (reg && rec.slot._updateTransform) rec.slot._updateTransform();
        return true;
      } catch (e) { return false; }
    };
    const refreshShadowTexState = (state, upgraded, dark) => {
      try {
        if (!state || !state.active) return;
        state.upgraded = !!upgraded;
        state.dark = !!dark;
        for (const rec of state.records) {
          rec.regionOverride = shadowRegionFor(rec.name, state);
          const di = shadowDispIdx(rec.name);
          if (di !== null) {
            try { if (Number(rec.slot.displayIndex) !== di) rec.slot.displayIndex = di; } catch (e) { try { if (rec.slot._setDisplayIndex) rec.slot._setDisplayIndex(di, true); } catch (e2) {} }
          }
          applyShadowSlotTex(rec);
        }
        try { if (state.display.markForUpdateRenderData) state.display.markForUpdateRenderData(); } catch (e) {}
      } catch (e) {}
    };
    const restoreShadowTexState = (state) => {
      try {
        if (!state || !state.active) return;
        state.active = false;
        for (const rec of state.records) {
          rec.active = false;
          const slot = rec.slot;
          if (!slot) continue;
          try {
            if (rec.hooked) { if (rec.hadOwn) slot._updateDisplayData = rec.originalUpdate; else delete slot._updateDisplayData; }
            try { if (Number(slot.displayIndex) !== rec.originalDisplayIndex) slot.displayIndex = rec.originalDisplayIndex; } catch (e) { try { if (slot._setDisplayIndex) slot._setDisplayIndex(rec.originalDisplayIndex, true); } catch (e2) {} }
            if (typeof rec.originalUpdate === 'function') rec.originalUpdate.call(slot);
            else slot._textureData = rec.originalTextureData;
            slot._pivotX = rec.originalPivotX;
            slot._pivotY = rec.originalPivotY;
            slot._transformDirty = true;
            slot._worldMatrixDirty = true;
            try { slot._zOrder = rec.originalZOrder; slot._zOrderDirty = true; } catch (e) {}
            if (slot._updateFrame) slot._updateFrame();
            if (slot._updateTransform) slot._updateTransform();
          } catch (e) { try { slot._textureData = rec.originalTextureData; slot._pivotX = rec.originalPivotX; slot._pivotY = rec.originalPivotY; if (slot._updateFrame) slot._updateFrame(); } catch (e2) {} }
        }
        try { if (state.display.markForUpdateRenderData) state.display.markForUpdateRenderData(); } catch (e) {}
      } catch (e) {}
    };
    const applyShadowPeaFx = (pea) => {
      try {
        if (!pea) return;
        if (SHADOW_ULT_RAIN_PEA_SCALE > 1) {
          try {
            const cur = typeof pea.scale === 'number' ? Math.abs(pea.scale) : 1;
            let base = cur;
            if (cur >= SHADOW_ULT_RAIN_PEA_SCALE) base = cur / SHADOW_ULT_RAIN_PEA_SCALE;
            pea.scale = Math.max(1, base) * SHADOW_ULT_RAIN_PEA_SCALE;
          } catch (e) {}
        }
        if (typeof pea.setDamage === 'function') {
          try { pea.setDamage(SHADOW_ULT_RAIN_DMG_SHADOW2); } catch (e) {}
        } else {
        }
        try { pea.__gpnPerfumeSeconds = SHADOW_ULT_RAIN_PERFUME_SECONDS; } catch (e) {}
      } catch (e) {}
    };
    const shadowHarvestBurst = (pea, killed) => {
      try {
        if (!killed || !(SHADOW_HARVEST_DAMAGE > 0) || !PepZombieCls) return;
        const zcls = PepZombieCls || (killed && killed.constructor);
        if (!zcls) return;
        const cc2 = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        if (!cc2) return;
        const scene2 = cc2.director.getScene();
        if (!scene2) return;
        const list2 = scene2.getComponentsInChildren(zcls);
        if (!Array.isArray(list2)) return;
        const tx = Number(killed.worldPositionX) || 0;
        const ty = Number(killed.worldPositionY) || 0;
        for (const z of list2) {
          try {
            if (!z || z === killed || !z.node || !z.node.isValid || z.dead) continue;
            if (Math.abs((Number(z.worldPositionX) || 0) - tx) < SHADOW_HARVEST_RANGE && Math.abs((Number(z.worldPositionY) || 0) - ty) < SHADOW_HARVEST_RANGE && typeof z.defaultDealDamage === 'function') {
              z.defaultDealDamage({ damage: SHADOW_HARVEST_DAMAGE, armorProtection: true, armorKnockSound: null, bodyKnockSound: false, damageDirection: null, damageType: pea && pea.damageType, flash: true, armorAlsoDamagedWhenNotProtecting: false });
            }
          } catch (e3) {}
        }
      } catch (e) {}
    };
    let prjFnsCacheS = null;
    const getPrjFns = () => {
      try {
        if (prjFnsCacheS) return prjFnsCacheS;
        prjFnsCacheS = engine && typeof engine.getModuleExport === 'function' ? engine.getModuleExport('chunks:///_virtual/Projectiles.ts', 'PrjFunctions') : null;
        return prjFnsCacheS;
      } catch (e) { return null; }
    };
    const spawnShadowShards = (pea, hitZombie) => {
      try {
        const ccS2 = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        const Vec2S = ccS2 && ccS2.Vec2;
        const PrjF = getPrjFns();
        if (!ccS2 || typeof Vec2S !== 'function' || !PrjF || typeof PrjF.shootOnePea !== 'function') return;
        const pos = pea.worldPosition ?? (pea.node && pea.node.worldPosition);
        const px = Number(pos && pos.x != null ? pos.x : pea.worldPositionX);
        const py = Number(pos && pos.y != null ? pos.y : pea.worldPositionY);
        const height = Number(pea.height);
        const layer = pea.node ? pea.node.parent : (pea.inLane && pea.inLane.prjLayer);
        const enemyType = pea.enemyType;
        if (!Number.isFinite(px) || !Number.isFinite(py) || !layer) return;
        const lv = pea.linearVelocity;
        const speed = (lv && Math.sqrt((lv.x || 0) * (lv.x || 0) + (lv.y || 0) * (lv.y || 0))) || 8;
        const dirX = (lv && lv.x) >= 0 ? 1 : -1;
        for (let i = 0; i < SHADOW_SHARD_COUNT; i++) {
          const ang = SHADOW_SHARD_ANGLES && SHADOW_SHARD_ANGLES.length ? (SHADOW_SHARD_ANGLES[i % SHADOW_SHARD_ANGLES.length] || 0) : 0;
          const vx = dirX * speed * Math.cos(ang);
          const vy = speed * Math.sin(ang);
          let child = null;
          try {
            child = PrjF.shootOnePea('pea_shadow', new Vec2S(px, py), height, layer, new Vec2S(vx, vy), enemyType, false);
          } catch (e) { continue; }
          const mark = (c) => {
            try {
              if (!c) return;
              c.__gpnShadowHarvestPea = true;   
              if (SHADOW_SHARD_SCALE > 0 && SHADOW_SHARD_SCALE !== 1) {
                const cur = typeof c.scale === 'number' ? Math.abs(c.scale) : 1;
                c.scale = Math.max(0.1, cur) * SHADOW_SHARD_SCALE;
              }
            } catch (e2) {}
          };
          if (child && typeof child.then === 'function') child.then(mark, () => {}); else mark(child);
        }
      } catch (e) {}
    };
    const tryShadowKill = (pea, zombie) => {
      try {
        if (!zombie || typeof zombie.defaultDealDamage !== 'function') return;
        const hp = Number(zombie.health);
        if (!Number.isFinite(hp) || hp >= SHADOW_KILL_HP) return;
        zombie.defaultDealDamage({
          damage: Math.max(100, hp + 9999),
          armorProtection: false,
          armorKnockSound: null,
          bodyKnockSound: false,
          damageDirection: null,
          damageType: SHADOW_KILL_DAMAGE_TYPE,
          flash: true,
          armorAlsoDamagedWhenNotProtecting: false
        });
      } catch (e) {}
    };
    const prevShootS = SHADOW.prototype._shoot;
    const fireShadowPea = (self, args, opts) => {
      const playSound = !opts || opts.playSound !== false;
      const wasInShoot = self.__gpnShadowInShoot === true;
      const wasPowered = self.ShadowPowered === true;
      if (wasPowered) { try { self.ShadowPowered = false; } catch (e) {} }
      self.__gpnShadowInShoot = true;
      try {
        const r = prevShootS.apply(self, args);
        if (wasInShoot || self.__gpnShadowForm !== true) return r;
        const apply = (pea) => {
          try {
            if (pea) {
              applyShadowPeaFx(pea);
              try { pea.__gpnShadowGatlingPea = true; } catch (e) {}
              try { pea.__gpnShadowHarvestPowered = self.ShadowPowered === true; } catch (e) {}
              try { pea.__gpnShadowUltPea = self.fooding === true; } catch (e) {}
            }
          } catch (e) {}
        };
        if (r && typeof r.then === 'function') r.then(apply, () => {}); else apply(r);
        if (playSound) {
          try {
            const s = self.__gpnShadowSound || self.soundRes;
            if (s) {
              const now = Date.now();
              if (!self.__gpnShadowSndAt || now - self.__gpnShadowSndAt > 120) {
                self.__gpnShadowSndAt = now;
                if (self.upgraded || self._upgraded) { if (typeof s.playShoot5 === 'function') s.playShoot5(0.3); }
                else { if (typeof s.playShoot === 'function') s.playShoot(0.3); }
              }
            }
          } catch (e) {}
        }
        return r;
      } finally {
        self.__gpnShadowInShoot = wasInShoot;
        if (wasPowered) { try { self.ShadowPowered = true; } catch (e) {} }
      }
    };
    const shadowShoot = function (...args) {
      const result = fireShadowPea(this, args);
      try {
        if (this.__gpnShadowForm === true && this.fooding !== true && !this.__gpnShadowBursting) {
          this.__gpnShadowBursting = true;
          const upgraded = !!(this.upgraded || this._upgraded);
          const total = (upgraded ? 5 : 4) - 1; 
          let n = 0;
          const timer = setInterval(() => {
            try {
              if (this.dead || !this.__gpnShadowForm || this.fooding === true) {
                clearInterval(timer); activeTimers.delete(timer);
                this.__gpnShadowBursting = false;
                return;
              }
            } catch (e) {}
            if (n >= total) {
              clearInterval(timer); activeTimers.delete(timer);
              this.__gpnShadowBursting = false;
              return;
            }
            try { fireShadowPea(this, args, { playSound: false }); } catch (e) {}
            n++;
          }, 50);
          activeTimers.add(timer);
        }
      } catch (e) {}
      return result;
    };
    const prevRayPar = SHADOW.prototype._ray_par;
    const shadowRayPar = function (...args) {
      return prevRayPar.apply(this, args);
    };
    const prevRay = SHADOW.prototype._ray;
    const shadowRay = function (...args) {
      return prevRay.apply(this, args);
    };
    SHADOW.prototype._shoot = shadowShoot;
    SHADOW.prototype._ray_par = shadowRayPar;
    SHADOW.prototype._ray = shadowRay;
    cleanups.push(() => {
      try { if (SHADOW.prototype._shoot === shadowShoot) SHADOW.prototype._shoot = prevShootS; } catch (e) {}
      try { if (SHADOW.prototype._ray_par === shadowRayPar) SHADOW.prototype._ray_par = prevRayPar; } catch (e) {}
      try { if (SHADOW.prototype._ray === shadowRay) SHADOW.prototype._ray = prevRay; } catch (e) {}
    });
    try {
      const csH = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('commonShot') : null;
      if (csH && csH.prototype && typeof csH.prototype.dealDamageToZombie === 'function') {
        const prevHitH = csH.prototype.dealDamageToZombie;
        const newHitH = function (zombie, ...rest) {
          const rH = prevHitH.apply(this, arguments);
          try {
            if (!zombie) return rH;
            if (this.__gpnShadowUltPea === true && this.__gpnShadowHarvestPowered === true) spawnShadowShards(this, zombie);
            if (this.__gpnShadowGatlingPea === true && this.__gpnShadowHarvestPowered === true) {
              const alive = typeof zombie.isAlive === 'function' ? zombie.isAlive() : !zombie.dead;
              if (!alive) shadowHarvestBurst(this, zombie);
            }
            if (this.__gpnShadowHarvestPea === true) tryShadowKill(this, zombie);
          } catch (e) {}
          return rH;
        };
        csH.prototype.dealDamageToZombie = newHitH;
        cleanups.push(() => {
          try { if (csH.prototype.dealDamageToZombie === newHitH) csH.prototype.dealDamageToZombie = prevHitH; } catch (e) {}
        });
      }
      if (csH && csH.prototype && typeof csH.prototype.characterOnEnable === 'function') {
        const prevCEH = csH.prototype.characterOnEnable;
        const newCEH = function (...a) {
          try { this.__gpnShadowGatlingPea = false; this.__gpnShadowHarvestPowered = false; this.__gpnShadowUltPea = false; this.__gpnShadowHarvestPea = false; } catch (e) {}
          return prevCEH.apply(this, a);
        };
        csH.prototype.characterOnEnable = newCEH;
        cleanups.push(() => {
          try { if (csH.prototype.characterOnEnable === newCEH) csH.prototype.characterOnEnable = prevCEH; } catch (e) {}
        });
      }
    } catch (e) {}
    const prevShadowHide = SHADOW.prototype.detectEnemy_toHide;
    if (typeof prevShadowHide === 'function') {
      const shadowNoHide = function (...args) {
        try {
          if (this.__gpnShadowForm === true) return;
        } catch (e) {}
        return prevShadowHide.apply(this, args);
      };
      SHADOW.prototype.detectEnemy_toHide = shadowNoHide;
      cleanups.push(() => {
        try { if (SHADOW.prototype.detectEnemy_toHide === shadowNoHide) SHADOW.prototype.detectEnemy_toHide = prevShadowHide; } catch (e) {}
      });
    }
    const endShadowRain = (self) => {
      try {
        self.fooding = false;
        try { self.__gpnRainSfxStop = true; } catch (e) {}
        try { stopRainSfx(self); } catch (e) {}
        try {
          if (self.anmControl && typeof self.anmControl.playIdle === 'function') self.anmControl.playIdle();
          else if (self.anmControl && self.anmControl.db && typeof self.anmControl.db.playAnimation === 'function') self.anmControl.db.playAnimation('Idle', Infinity);
        } catch (e) {}
        try { if (typeof self.foodEnd === 'function') self.foodEnd(); } catch (e) {}
      } catch (e) {}
    };
    const prevShadowPF = SHADOW.prototype.specialPlantFood;
    const shadowPF = function (...args) {
      try {
        if (this.__gpnShadowForm === true) {
          const self = this;
          self.__gpnShadowUlted = true;
          self.__gpnShadowUltCount = (Number(self.__gpnShadowUltCount) || 0) + 1;
          self.fooding = true;
          self.__gpnRainSfxStop = false;
          try {
            if (self.upgraded !== true && self._upgraded !== true) { try { self.upgraded = true; } catch (e) {} }
          } catch (e) {}
          try {
            const st = shadowStates.get(self);
            if (st && st.active) refreshShadowTexState(st, true, self.ShadowPowered === true);
          } catch (e) {}
          try { self.anmControl.playAnimation('FoodStart', 1, SHADOW_ULT_RAIN_PREPARE_SPEED || 2); } catch (e) {}
          try {
            let s = self.__gpnShadowSound || null;
            if (!s || typeof s.playFood !== 'function') {
              try {
                const ccS = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
                if (ccS) {
                  const scS = ccS.director.getScene();
                  if (scS) {
                    const listS = scS.getComponentsInChildren(MG4);
                    if (Array.isArray(listS)) {
                      for (const pl of listS) {
                        try {
                          if (pl && pl.soundRes && !pl.__gpnAbsorbed && typeof pl.soundRes.playFood === 'function') { s = pl.soundRes; break; }
                        } catch (e2) {}
                      }
                    }
                  }
                }
              } catch (e2) {}
            }
            if (s) { if (typeof s.playFood === 'function') s.playFood(); else if (typeof s.playShoot === 'function') s.playShoot(0.3); }
          } catch (e) {}
          const total = Math.max(1, Math.floor(Number(150) || 150));
          const step = Math.max(16, Math.floor(2000 / total));
          const angles = SHADOW_ULT_SPREAD_ANGLES && SHADOW_ULT_SPREAD_ANGLES.length ? SHADOW_ULT_SPREAD_ANGLES : [-0.11, -0.055, 0, 0.055, 0.11];
          let fired = 0;
          let cursor = 0;
          if (typeof self.scheduleOnce === 'function') {
            self.scheduleOnce(() => {
              try {
                if (self.dead || !self.__gpnShadowForm) {
                  try { stopRainSfx(self); } catch (e) {}
                  try { self.foodEnd(); } catch (e) {}
                  return;
                }
                try { self.anmControl.playAnimation('Food', 1 / 0); } catch (e) {}
                const timer = setInterval(() => {
                  try {
                    if (self.dead || !self.__gpnShadowForm) {
                      clearInterval(timer); activeTimers.delete(timer);
                      try { stopRainSfx(self); } catch (e) {}
                      endShadowRain(self);
                      return;
                    }
                  } catch (e) {}
                  if (fired >= total) {
                    clearInterval(timer); activeTimers.delete(timer);
                    try { stopRainSfx(self); } catch (e) {}
                    endShadowRain(self);
                    return;
                  }
                  try {
                    const angle = angles[cursor % angles.length];
                    cursor++;
                    const r = fireShadowPea(self, [self._objdataOwn && self._objdataOwn.PeaType ? self._objdataOwn.PeaType : 'pea_shadow'], { playSound: false });
                    const scatter = (pea) => {
                      try {
                        if (pea && pea.linearVelocity && typeof pea.linearVelocity.x === 'number') {
                          const jitter = (Math.random() - 0.5) * 0.25;
                          pea.linearVelocity.y = pea.linearVelocity.x * (angle + jitter);
                        }
                      } catch (e) {}
                    };
                    if (r && typeof r.then === 'function') r.then(scatter, () => {}); else scatter(r);
                  } catch (e) {}
                  fired++;
                }, step);
                activeTimers.add(timer);
              } catch (err) {}
            }, SHADOW_ULT_RAIN_PREPARE_SECONDS != null ? SHADOW_ULT_RAIN_PREPARE_SECONDS : 0.4);
          } else {
            for (let i = 0; i < total; i++) { try { fireShadowPea(self, ['pea_shadow'], { playSound: false }); } catch (e) {} }
            try { stopRainSfx(self); } catch (e) {}
            endShadowRain(self);
          }
          return;
        }
      } catch (e) {}
      return prevShadowPF.apply(this, args);
    };
    SHADOW.prototype.specialPlantFood = shadowPF;
    cleanups.push(() => {
      try { if (SHADOW.prototype.specialPlantFood === shadowPF) SHADOW.prototype.specialPlantFood = prevShadowPF; } catch (e) {}
    });
    const prevShadowAL = SHADOW.prototype.animationListener;
    const shadowAL = function (evt) {
      try {
        if (this.__gpnShadowForm === true) {
          const name = evt && evt.name;
          if (name === 'food_prj' || name === 'throw' || name === 'foodEnd' || name === 'food' || name === 'playFooding' || name === 'playFood') {
            return; 
          }
          if (name === 'shoot_sound') {
            return;
          }
          if (name === 'shoot' || name === 'ray_par' || name === 'ray') {
            try {
              if (this.fooding !== true) {
                const now = Date.now();
                if (!this.__gpnShadowShotAt || now - this.__gpnShadowShotAt > 200) {
                  this.__gpnShadowShotAt = now;
                  this._shoot(this._objdataOwn && this._objdataOwn.PeaType ? this._objdataOwn.PeaType : 'pea_shadow');
                }
              }
            } catch (e) {}
            return;
          }
        }
      } catch (e) {}
      return prevShadowAL.apply(this, arguments);
    };
    SHADOW.prototype.animationListener = shadowAL;
    cleanups.push(() => {
      try { if (SHADOW.prototype.animationListener === shadowAL) SHADOW.prototype.animationListener = prevShadowAL; } catch (e) {}
    });
    const prevShadowFoodPrj = SHADOW.prototype._food_prj;
    if (typeof prevShadowFoodPrj === 'function') {
      SHADOW.prototype._food_prj = function (...args) {
        try {
          if (this.__gpnShadowForm === true) return;
        } catch (e) {}
        return prevShadowFoodPrj.apply(this, args);
      };
      cleanups.push(() => {
        try { if (SHADOW.prototype._food_prj && SHADOW.prototype._food_prj.__gpnShadowFpj) SHADOW.prototype._food_prj = prevShadowFoodPrj; } catch (e) {}
        try { delete SHADOW.prototype._food_prj.__gpnShadowFpj; } catch (e) {}
      });
      try { SHADOW.prototype._food_prj.__gpnShadowFpj = true; } catch (e) {}
    }
    if (typeof SHADOW.prototype.finishShadowRain !== 'function') {
      const finishRainLocal = function () {
        try {
          this.fooding = false;
          stopRainSfx(this);
          try { if (this.anmControl && typeof this.anmControl.playIdle === 'function') this.anmControl.playIdle(); } catch (e) {}
        } catch (e) {}
        try { if (typeof this.foodEnd === 'function') this.foodEnd(); } catch (e) {}
      };
      SHADOW.prototype.finishShadowRain = finishRainLocal;
      cleanups.push(() => {
        try { if (SHADOW.prototype.finishShadowRain === finishRainLocal) delete SHADOW.prototype.finishShadowRain; } catch (e) {}
      });
    }
    const doShadowFuse = (shadowPlant) => {
      try {
        if (shadowPlant.__gpnShadowForm) return;
        shadowPlant.__gpnShadowForm = true;
        shadowPlant.__gpnFusion = { src: 195, peaType: 'pea_shadow', triple: false }; 
        try {
          const snd = shadowPlant.__gpnShadowSound;
          if (snd && typeof snd.playFood === 'function') shadowPlant.soundRes = snd;
          pepDiag.elec = 'shadowSound=' + (shadowPlant.__gpnShadowSound ? 'mg' : 'self') + ' playShoot5=' + (typeof (shadowPlant.soundRes && shadowPlant.soundRes.playShoot5) === 'function') + ' playShoot=' + (typeof (shadowPlant.soundRes && shadowPlant.soundRes.playShoot) === 'function') + ' playFood=' + (typeof (shadowPlant.soundRes && shadowPlant.soundRes.playFood) === 'function');
        } catch (e) { pepDiag.elec = 'shadowSoundErr'; }
        const patch = {
          ShootInterval: 1.35,
          ShootIntervalAdditional: 0.15,
          ChanceToPlantfood: 0.05,
          PeaType: 'pea_shadow',
          PeaTypePlantfood: 'pea_shadow',
          Toughness: 300,
        };
        try { if (typeof shadowPlant.modObjdataOwn === 'function') shadowPlant.modObjdataOwn(patch); } catch (e) {}
        try { if (shadowPlant._objdataOwn) Object.assign(shadowPlant._objdataOwn, patch); } catch (e) {}
        try { shadowPlant.minShootInterval = 1.1; } catch (e) {}
        try { shadowPlant.ProjectileSpeedMult = 1.7; } catch (e) {}
        getShadowTexture().then((tex) => {
          try {
            if (!shadowPlant.node || !shadowPlant.node.isValid || shadowPlant.dead || !shadowPlant.__gpnShadowForm) { pepDiag.elec = 'shadowFuse:nodeDead'; return; }
            restoreShadowTexState(shadowStates.get(shadowPlant));
            shadowStates.delete(shadowPlant);
            const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
            const disp = shadowPlant.anmControl ? (shadowPlant.anmControl.db || shadowPlant.anmControl._db) : null;
            const arm = pepArmOf(disp);
            pepDiag.elec = 'shadowFuse:tex=' + (tex && tex.width) + 'x' + (tex && tex.height) + ' disp=' + (disp ? 'Y' : 'N') + ' arm=' + (arm ? 'Y' : 'N') + ' db=' + (shadowPlant.anmControl ? (shadowPlant.anmControl.db ? 'db' : (shadowPlant.anmControl._db ? '_db' : 'none')) : 'noAnm');
            const st = installShadowTexState(shadowPlant, tex);
            if (st) { shadowStates.set(shadowPlant, st); pepDiag.elec += ' st=ok(' + st.records.length + ')'; }
            else pepDiag.elec += ' st=null';
          } catch (e) { pepDiag.elec = 'shadowFuse:err:' + (e && e.message); }
        }).catch(() => { pepDiag.elec = 'shadowFuse:texLoadErr'; });
        if (log) log.info('PEP [ShadowGatling] fused: MegaGatling absorbed by ShadowPeashooter -> shadow base gatling (pea=pea_shadow big/40dmg/perfume, moonflower switches cap region)');
      } catch (e) {}
    };
    const unfuseShadow = (host) => {
      try {
        if (host.__gpnShadowForm) host.__gpnShadowForm = false;
        delete host.__gpnFusion;
        delete host.__gpnShadowSound;
        restoreShadowTexState(shadowStates.get(host));
        shadowStates.delete(host);
      } catch (e) {}
    };
    try {
      const LnC = engine.getClassByName ? engine.getClassByName('LnC') : null;
      if (LnC && LnC.prototype && typeof LnC.prototype.putPlantAvailable === 'function' && !LnC.prototype.__gpnShadowOverlap) {
        LnC.prototype.__gpnShadowOverlap = true;
        const orig = LnC.prototype.putPlantAvailable;
        LnC.prototype.putPlantAvailable = function (t, e, n, i, o, a) {
          try {
            const id = Number(e);
            if (id === 9 || id === 195) {
              const arr = this.plantInSquare;
              if (Array.isArray(arr) && arr.length > 0) {
                const need = id === 9 ? 195 : 9;
                const has = arr.some((pl) => {
                  try {
                    if (!pl || pl.dead) return false;
                    const pid = Number(pl.ID != null ? pl.ID : pl._plantID);
                    if (pid === need) return true;
                    if (need === 195 && pl.constructor === SHADOW) return true;
                    if (need === 9 && (pid === 9 || pl.constructor === MG4)) return true;
                    return false;
                  } catch (e2) { return false; }
                });
                if (has) {
                  if (log) log.info('PEP [ShadowGatling] overlap ALLOW plant=' + id + ' need=' + need);
                  return true;
                }
                if (log) log.info('PEP [ShadowGatling] overlap DENY plant=' + id + ' need=' + need);
              } else if (log) { log.info('PEP [ShadowGatling] overlap empty sq plant=' + id); }
            }
          } catch (e) {}
          return orig.apply(this, arguments);
        };
        cleanups.push(() => {
          try { if (LnC.prototype.putPlantAvailable && LnC.prototype.__gpnShadowOverlap) LnC.prototype.putPlantAvailable = orig; } catch (e) {}
          try { delete LnC.prototype.__gpnShadowOverlap; } catch (e) {}
        });
        if (log) log.info('PEP [ShadowGatling] overlap ON (MG+Shadow)');
      }
    } catch (e) {}
    let shadowScanTimer = null;
    try {
      shadowScanTimer = setInterval(() => {
        try {
          const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
          const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
          if (!cc || !PlantF) return;
          const scene = cc.director.getScene();
          if (!scene) return;
          const list = scene.getComponentsInChildren(PlantF);
          if (!Array.isArray(list)) return;
          for (const p of list) {
            try {
              if (!p.node || !p.node.isValid || p.dead) continue;
              const lc = p.plantInLnC || p.inLnC;
              if (!lc || !lc.plantInSquare || !lc.plantInSquare.length) continue;
              const isMG = p.constructor === MG4 || p.ID === 9;
              const isShadow = p.constructor === SHADOW || p.ID === 195;
              if (!isMG && !isShadow) continue;
              if (isMG) {
                for (const other of lc.plantInSquare) {
                  if (!other || other === p || !other.node || !other.node.isValid || other.dead) continue;
                  if (other.constructor === SHADOW || other.ID === 195) {
                    try {
                      const s1 = p[BOSS_SOUND] || null;
                      const s2 = p.soundRes || null;
                      other.__gpnShadowSound = (s1 && typeof s1.playShoot5 === 'function') ? s1 : ((s2 && typeof s2.playShoot5 === 'function') ? s2 : (s2 || null));
                    } catch (e) { try { other.__gpnShadowSound = p.soundRes || null; } catch (e2) {} }
                    try {
                      other.__gpnAbsorbed = true;
                      const idx2 = lc.plantInSquare.indexOf(p);
                      if (idx2 >= 0) lc.plantInSquare.splice(idx2, 1);
                      try { if (typeof lc.readIndex === 'function') lc.readIndex(); } catch (e) {}
                      try { if (p.node) { if (p.node.destroy) p.node.destroy(); else p.node.active = false; } } catch (e) {}
                      try { if (typeof p.die === 'function') p.die(false, false, false, false, true); } catch (e) {}
                    } catch (e) {}
                    doShadowFuse(other);
                    break;
                  }
                }
              } else if (isShadow) {
                for (const other of lc.plantInSquare) {
                  if (!other || other === p || !other.node || !other.node.isValid || other.dead) continue;
                  if (other.constructor === MG4 || other.ID === 9) {
                    try {
                      const s1 = other[BOSS_SOUND] || null;
                      const s2 = other.soundRes || null;
                      p.__gpnShadowSound = (s1 && typeof s1.playShoot5 === 'function') ? s1 : ((s2 && typeof s2.playShoot5 === 'function') ? s2 : (s2 || null));
                    } catch (e) { try { p.__gpnShadowSound = other.soundRes || null; } catch (e2) {} }
                    try {
                      other.__gpnAbsorbed = true;
                      const idx2 = lc.plantInSquare.indexOf(other);
                      if (idx2 >= 0) lc.plantInSquare.splice(idx2, 1);
                      try { if (typeof lc.readIndex === 'function') lc.readIndex(); } catch (e) {}
                      try { if (other.node) { if (other.node.destroy) other.node.destroy(); else other.node.active = false; } } catch (e) {}
                      try { if (typeof other.die === 'function') other.die(false, false, false, false, true); } catch (e) {}
                    } catch (e) {}
                    doShadowFuse(p);
                    break;
                  }
                }
              }
            } catch (e) {}
          }
        } catch (e) {}
      }, 200);
      cleanups.push(() => { try { clearInterval(shadowScanTimer); } catch (e) {} });
    } catch (e) {}
    try {
      const prevUpdate = SHADOW.prototype.update;
      if (typeof prevUpdate === 'function' && !SHADOW.prototype.__gpnShadowUpd) {
        SHADOW.prototype.__gpnShadowUpd = true;
        SHADOW.prototype.update = function (...args) {
          const r = prevUpdate.apply(this, args);
          try {
            if (this.__gpnShadowForm === true) {
              const st = shadowStates.get(this);
              if (st && st.active) {
                const up = !!(this.upgraded || this._upgraded);
                const dark = this.ShadowPowered === true;
                if (st.upgraded !== up || st.dark !== dark) refreshShadowTexState(st, up, dark);
              }
            }
          } catch (e) {}
          return r;
        };
        cleanups.push(() => {
          try { if (SHADOW.prototype.update && SHADOW.prototype.__gpnShadowUpd) SHADOW.prototype.update = prevUpdate; } catch (e) {}
          try { delete SHADOW.prototype.__gpnShadowUpd; } catch (e) {}
        });
      }
    } catch (e) {}
    try {
      const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
      if (PlantF && PlantF.prototype && !PlantF.prototype.__gpnShadowCOD) {
        PlantF.prototype.__gpnShadowCOD = true;
        const prevCOD = PlantF.prototype.characterOnDisable;
        PlantF.prototype.characterOnDisable = function (...args) {
          try { if (this.__gpnShadowForm === true) unfuseShadow(this); } catch (e) {}
          return prevCOD.apply(this, args);
        };
        cleanups.push(() => {
          try { if (PlantF.prototype.characterOnDisable && PlantF.prototype.__gpnShadowCOD) PlantF.prototype.characterOnDisable = prevCOD; } catch (e) {}
          try { delete PlantF.prototype.__gpnShadowCOD; } catch (e) {}
        });
      }
    } catch (e) {}
  })();
  (function installRubyShooter() {
    const SNOW = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('SnowPeaPlant') : null;
    if (!SNOW || !SNOW.prototype) {
      if (log) log.warn('PEP: SnowPeaPlant class missing, ruby shooter skipped');
      return;
    }
    const proto = SNOW.prototype;
    const RUBY_FLAG = '__gpnRubyForm';
    const RUBY_PEA = 'snowdrop_freeze'; 
    const isRuby = (self) => { try { return self && self[RUBY_FLAG] === true; } catch (e) { return false; } };
    const startRubyCharge = (host) => {
      try {
        if (host.__gpnRubyChargeTimer) return;
        const apply = () => {
          try {
            if (!host || host.dead || !host.node || !host.node.isValid || !isRuby(host)) return;
            host.highRedCD = 0.3;
            try { if (typeof host.shouldMaterial === 'function') host.shouldMaterial(); } catch (e2) {}
          } catch (e2) {}
        };
        apply();
        const timer = setInterval(apply, RUBY_CHARGE_MS);
        host.__gpnRubyChargeTimer = timer;
        activeTimers.add(timer);
      } catch (e) {}
    };
    const stopRubyCharge = (host) => {
      try {
        if (host.__gpnRubyChargeTimer) {
          clearInterval(host.__gpnRubyChargeTimer);
          activeTimers.delete(host.__gpnRubyChargeTimer);
          host.__gpnRubyChargeTimer = null;
        }
        try { host.highRedCD = 0; } catch (e) {}
        try { if (typeof host.shouldMaterial === 'function') host.shouldMaterial(); } catch (e) {}
      } catch (e) {}
    };
    const doRubyFuse = (host) => {
      try {
        if (host[RUBY_FLAG]) return;
        host[RUBY_FLAG] = true;
        host.__gpnFusion = { src: 81, peaType: RUBY_PEA, triple: false };
        try { host.__gpnSnowUltCount = 0; } catch (e) {}
        try { host.__gpnRubyUltCount = 0; } catch (e) {}  
        try { host.__gpnUlted = false; } catch (e) {}
        try { host.__gpnCycleBurst = false; } catch (e) {}
        try { host.__gpnCycleFired = 0; } catch (e) {}
        try { host.__gpnSnowUltActive = false; } catch (e) {}
        try { host.__gpnSnowIcicleShare = 0; } catch (e) {}
        try { host.__gpnSnowSpreadCursor = 0; } catch (e) {}
        try {
          if (host._objdataOwn) {
            host._objdataOwn.PeaType = RUBY_PEA;
            host._objdataOwn.PeaTypePlantfood = RUBY_PEA;
          }
        } catch (e) {}
        try {
          if (host._objdataOwn) {
            if (!Object.prototype.hasOwnProperty.call(host, '__gpnRubyBackup')) {
              host.__gpnRubyBackup = { calls: host._objdataOwn.CallsElectricCurrant, stun: host._objdataOwn.RedAttackStunDuration };
            }
            host._objdataOwn.CallsElectricCurrant = true;
            host._objdataOwn.RedAttackStunDuration = 0.25;
          }
        } catch (e) {}
        startRubyCharge(host);
        if (log) log.info('PEP [RubyShooter] fused: SnowPea + ElectricCurrant -> ruby shooter (pea=snowdrop_freeze 40dmg no-slow no-freeze, permanent red charge)');
      } catch (e) {}
    };
    const unfuseRuby = (host) => {
      try {
        if (host[RUBY_FLAG]) host[RUBY_FLAG] = false;
        stopRubyCharge(host);
        try { delete host.__gpnFusion; } catch (e) {}
        try {
          if (host._objdataOwn && host.__gpnRubyBackup) {
            host._objdataOwn.CallsElectricCurrant = host.__gpnRubyBackup.calls ?? false;
            host._objdataOwn.RedAttackStunDuration = host.__gpnRubyBackup.stun;
          }
          host.__gpnRubyBackup = null;
        } catch (e) {}
        try {
          if (host._objdataOwn) {
            host._objdataOwn.PeaType = 'pea_snow';
            host._objdataOwn.PeaTypePlantfood = 'pea_snow';
          }
        } catch (e) {}
      } catch (e) {}
    };
    const applyRubyFx = (pea) => {
      try {
        if (!pea) return;
        const isRubyUlt = pea.__gpnRubyUlt === true;
        try { if (typeof pea.setDamage === 'function') pea.setDamage(isRubyUlt ? RUBY_ULT_DAMAGE : RUBY_DAMAGE); } catch (e) {}
        if (isRubyUlt) {
          try {
            const cur = typeof pea.scale === 'number' ? Math.abs(pea.scale) : 1;
            let base = cur;
            if (cur >= RUBY_ULT_SCALE) base = cur / RUBY_ULT_SCALE;
            pea.scale = Math.max(1, base) * RUBY_ULT_SCALE;
          } catch (e) {}
          try { pea.__gpnRubyPierce = true; } catch (e) {}
          try { pea.__gpnRubyPierceHits = null; } catch (e) {}
          try { pea.popSoundCDScale = 0; } catch (e) {}
          try { if (pea.linearVelocity && typeof pea.linearVelocity.x === 'number') pea.__gpnRubyPierceVelX = pea.linearVelocity.x; } catch (e) {}
        }
        try { if (typeof pea.setPerfume === 'function') pea.setPerfume(0); } catch (e) {}
        try { if (typeof pea.setFrozen === 'function') pea.setFrozen(0); } catch (e) {}
        try { if (typeof pea.setFreeze === 'function') pea.setFreeze(0); } catch (e) {}
        try { if (typeof pea.setSlow === 'function') pea.setSlow(0); } catch (e) {}
        try { if (typeof pea.setStun === 'function') pea.setStun(0); } catch (e) {}
        try { if (typeof pea.setChill === 'function') pea.setChill(0); } catch (e) {}
        try { if (pea.slow !== undefined) pea.slow = 0; } catch (e) {}
        try { if (pea._slow !== undefined) pea._slow = 0; } catch (e) {}
        try { if (pea.freeze !== undefined) pea.freeze = 0; } catch (e) {}
        try { if (pea._freeze !== undefined) pea._freeze = 0; } catch (e) {}
        try { if (pea.chill !== undefined) pea.chill = 0; } catch (e) {}
        try { if (pea._chill !== undefined) pea._chill = 0; } catch (e) {}
        try { pea.__gpnRuby = true; } catch (e) {}
      } catch (e) {}
    };
    const prevShootR = proto._shoot;
    if (typeof prevShootR === 'function') {
      const rubyShoot = function (...args) {
        if (isRuby(this) && this.__gpnRubyUlting === true) return;
        const self = this;
        try {
          if (isRuby(self) && self.fooding !== true) {
            const isFull = (self.__gpnRubyUltCount || 0) >= FULL_ULT_COUNT;
            if (isFull || ((self.__gpnRubyUltCount || 0) > 0 && Math.random() < RUBY_DOUBLE_CHANCE)) {
              let rr = null;
              try { rr = prevShootR.apply(self, [false, false, 'snowdrop_freeze']); } catch (e) {}
              try {
                setTimeout(() => {
                  try {
                    if (self.dead || !isRuby(self)) return;
                    const r2 = prevShootR.apply(self, [false, false, RUBY_PEA]);
                    const apply2 = (pea) => { try { applyRubyFx(pea); } catch (e) {} };
                    if (r2 && typeof r2.then === 'function') r2.then(apply2, () => {}); else apply2(r2);
                  } catch (e) {}
                }, RUBY_DOUBLE_DELAY_MS);
              } catch (e) {}
              return rr;
            }
          }
        } catch (e) {}
        const r = prevShootR.apply(this, args);
        try {
          if (isRuby(this) && this.fooding !== true) {
            const apply = (pea) => { try { applyRubyFx(pea); } catch (e) {} };
            if (r && typeof r.then === 'function') r.then(apply, () => {}); else apply(r);
          }
        } catch (e) {}
        return r;
      };
      proto._shoot = rubyShoot;
      cleanups.push(() => { try { if (proto._shoot === rubyShoot) proto._shoot = prevShootR; } catch (e) {} });
    }
    const startRubyField = (host) => {
      try {
        stopRubyField(host);
        if (host.__gpnRubyFieldTimer) return;
        const scan = () => {
          try {
            if (!PepZombieCls) return;
            const cc2 = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
            if (!cc2) return;
            const scene2 = cc2.director.getScene();
            if (!scene2) return;
            const y = Number(host.worldPositionY) || 0;
            const list2 = scene2.getComponentsInChildren(PepZombieCls);
            if (!Array.isArray(list2)) return;
            const ulting = host.__gpnRubyUlting === true;
            let keep = false;
            for (const z of list2) {
              try {
                if (!z || !z.node || !z.node.isValid || z.dead) { z.__gpnRubyField = false; continue; }
                const sameRow = Math.abs((Number(z.worldPositionY) || 0) - y) < RUBY_FIELD_ROW;
                const affected = Number(z.chill) > 0 || Number(z.freeze) > 0 || Number(z._chill) > 0 || Number(z._freeze) > 0;
                if (ulting) {
                  z.__gpnRubyField = !!(sameRow && affected);
                } else if (z.__gpnRubyField === true) {
                  if (sameRow && affected) keep = true;
                  else z.__gpnRubyField = false;
                }
              } catch (e3) {}
            }
            if (!ulting && !keep && host.__gpnRubyFieldTimer) {
              clearInterval(host.__gpnRubyFieldTimer);
              activeTimers.delete(host.__gpnRubyFieldTimer);
              host.__gpnRubyFieldTimer = null;
            }
          } catch (e3) {}
        };
        scan();
        const timer = setInterval(scan, RUBY_FIELD_SCAN_MS);
        host.__gpnRubyFieldTimer = timer;
        activeTimers.add(timer);
      } catch (e) {}
    };
    const stopRubyField = (host) => {
      try {
        if (host.__gpnRubyFieldTimer) {
          clearInterval(host.__gpnRubyFieldTimer);
          activeTimers.delete(host.__gpnRubyFieldTimer);
          host.__gpnRubyFieldTimer = null;
        }
      } catch (e) {}
      try {
        if (host.__gpnRubySfxTimer) {
          clearInterval(host.__gpnRubySfxTimer);
          activeTimers.delete(host.__gpnRubySfxTimer);
          host.__gpnRubySfxTimer = null;
        }
      } catch (e) {}
      try {
        if (host.__gpnRubySfx2Timer) {
          clearInterval(host.__gpnRubySfx2Timer);
          activeTimers.delete(host.__gpnRubySfx2Timer);
          host.__gpnRubySfx2Timer = null;
        }
      } catch (e) {}
      try {
        if (PepZombieCls) {
          const cc2 = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
          if (cc2) {
            const scene2 = cc2.director.getScene();
            if (scene2) {
              const list2 = scene2.getComponentsInChildren(PepZombieCls);
              if (Array.isArray(list2)) for (const z of list2) { try { z.__gpnRubyField = false; } catch (e3) {} }
            }
          }
        }
      } catch (e) {}
    };
    const prevPF_R = proto.specialPlantFood;
    if (typeof prevPF_R === 'function') {
      const rubyPF = function (...args) {
        if (isRuby(this)) {
          const self = this;
          try {
            self.__gpnRubyUlting = true;
            self.__gpnRubyUltCount = (self.__gpnRubyUltCount || 0) + 1;  
            startRubyField(self);
            try { self.anmControl.playAnimation('Shoot', 1 / 0, 0, 2); } catch (e) {}
            try {
              const snd = self.soundRes;
              if (snd && typeof snd.playShoot === 'function') {
                const sfxOnce = () => { try { if (self && !self.dead && isRuby(self)) snd.playShoot(2.0); } catch (e) {} };
                sfxOnce();
                const sfxTimer = setInterval(sfxOnce, RUBY_ULT_INTERVAL_MS / 2);
                self.__gpnRubySfxTimer = sfxTimer;
                activeTimers.add(sfxTimer);
              }
            } catch (e) {}
            const fire = () => {
              try {
                if (self.dead || !isRuby(self)) { stopRubyField(self); try { self.foodEnd(); } catch (e) {} self.__gpnRubyUlting = false; return; }
                let fired = 0;
                const timer = setInterval(() => {
                  try {
                    if (self.dead || !isRuby(self)) {
                      clearInterval(timer); activeTimers.delete(timer);
                      stopRubyField(self);
                      try { self.foodEnd(); } catch (e) {}
                      self.__gpnRubyUlting = false;
                      return;
                    }
                    if (fired >= RUBY_ULT_COUNT) {
                      clearInterval(timer); activeTimers.delete(timer);
                      try { if (self.__gpnRubySfxTimer) { clearInterval(self.__gpnRubySfxTimer); activeTimers.delete(self.__gpnRubySfxTimer); self.__gpnRubySfxTimer = null; } } catch (e) {}
                      try { if (self.__gpnRubySfx2Timer) { clearInterval(self.__gpnRubySfx2Timer); activeTimers.delete(self.__gpnRubySfx2Timer); self.__gpnRubySfx2Timer = null; } } catch (e) {}
                      try { self.foodEnd(); } catch (e) {}
                      self.__gpnRubyUlting = false;
                      return;
                    }
                    const r = prevShootR.apply(self, [false, false, RUBY_PEA]);
                    const apply = (pea) => {
                      try {
                        if (pea) pea.__gpnRubyUlt = true;
                        applyRubyFx(pea);
                        try { if (pea && typeof pea.playPopSound === 'function') pea.playPopSound(); } catch (e3) {}
                      } catch (e) {}
                    };
                    if (r && typeof r.then === 'function') r.then(apply, () => {}); else apply(r);
                    fired++;
                  } catch (e) {}
                }, RUBY_ULT_INTERVAL_MS);
                activeTimers.add(timer);
              } catch (e) { stopRubyField(self); try { self.foodEnd(); } catch (e2) {} self.__gpnRubyUlting = false; }
            };
            if (typeof self.scheduleOnce === 'function') self.scheduleOnce(fire, 0.25);
            else fire();
            return;
          } catch (e) {}
        }
        return prevPF_R.apply(this, args);
      };
      proto.specialPlantFood = rubyPF;
      cleanups.push(() => { try { if (proto.specialPlantFood === rubyPF) proto.specialPlantFood = prevPF_R; } catch (e) {} });
    }
    try {
      const LnC = engine.getClassByName ? engine.getClassByName('LnC') : null;
      if (LnC && LnC.prototype && typeof LnC.prototype.putPlantAvailable === 'function' && !LnC.prototype.__gpnRubyOverlap) {
        LnC.prototype.__gpnRubyOverlap = true;
        const orig = LnC.prototype.putPlantAvailable;
        LnC.prototype.putPlantAvailable = function (t, e, n, i, o, a) {
          try {
            const id = Number(e);
            if (id === 28 || id === 81) {
              const arr = this.plantInSquare;
              if (Array.isArray(arr) && arr.length > 0) {
                const need = id === 28 ? 81 : 28;
                const has = arr.some((pl) => {
                  try {
                    if (!pl || pl.dead) return false;
                    const pid = Number(pl.ID != null ? pl.ID : pl._plantID);
                    if (pid === need) return true;
                    if (need === 28 && pl.constructor === SNOW) return true;
                    return false;
                  } catch (e2) { return false; }
                });
                if (has) {
                  if (log) log.info('PEP [RubyShooter] overlap ALLOW plant=' + id + ' need=' + need);
                  return true;
                }
              }
            }
          } catch (e) {}
          return orig.apply(this, arguments);
        };
        cleanups.push(() => {
          try { if (LnC.prototype.putPlantAvailable && LnC.prototype.__gpnRubyOverlap) LnC.prototype.putPlantAvailable = orig; } catch (e) {}
          try { delete LnC.prototype.__gpnRubyOverlap; } catch (e) {}
        });
        if (log) log.info('PEP [RubyShooter] overlap ON (SnowPea+ElectricCurrant)');
      }
    } catch (e) {}
    let rubyScanTimer = null;
    try {
      rubyScanTimer = setInterval(() => {
        try {
          const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
          const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
          if (!cc || !PlantF) return;
          const scene = cc.director.getScene();
          if (!scene) return;
          const list = scene.getComponentsInChildren(PlantF);
          if (!Array.isArray(list)) return;
          for (const p of list) {
            try {
              if (!p.node || !p.node.isValid || p.dead) continue;
              const lc = p.plantInLnC || p.inLnC;
              if (!lc || !lc.plantInSquare || !lc.plantInSquare.length) continue;
              const isSnow = p.constructor === SNOW || p.ID === 28;
              const isCur = p.ID === 81;
              if (!isSnow && !isCur) continue;
              for (const other of lc.plantInSquare) {
                if (!other || other === p || !other.node || !other.node.isValid || other.dead) continue;
                if (isSnow && other.ID === 81) {
                  if (other.__gpnRubyAbsorbed) continue;
                  other.__gpnRubyAbsorbed = true;
                  try { p.__gpnRubySnd = other.soundRes || null; } catch (e) {}
                  try { if (other.node) other.node.active = false; } catch (e) {}
                  const idx = lc.plantInSquare.indexOf(other);
                  if (idx >= 0) lc.plantInSquare.splice(idx, 1);
                  try { if (typeof lc.readIndex === 'function') lc.readIndex(); } catch (e) {}
                  doRubyFuse(p);
                  break;
                }
                if (isCur && (other.constructor === SNOW || other.ID === 28)) {
                  if (p.__gpnRubyAbsorbed) continue;
                  p.__gpnRubyAbsorbed = true;
                  try { other.__gpnRubySnd = p.soundRes || null; } catch (e) {}
                  try { if (p.node) p.node.active = false; } catch (e) {}
                  const idx = lc.plantInSquare.indexOf(p);
                  if (idx >= 0) lc.plantInSquare.splice(idx, 1);
                  try { if (typeof lc.readIndex === 'function') lc.readIndex(); } catch (e) {}
                  doRubyFuse(other);
                  break;
                }
              }
            } catch (e) {}
          }
        } catch (e) {}
      }, 200);
      cleanups.push(() => { try { clearInterval(rubyScanTimer); } catch (e) {} });
    } catch (e) {}
    try {
      const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
      if (PlantF && PlantF.prototype && !PlantF.prototype.__gpnRubyCOD) {
        PlantF.prototype.__gpnRubyCOD = true;
        const prevCOD = PlantF.prototype.characterOnDisable;
        PlantF.prototype.characterOnDisable = function (...args) {
          try { if (this[RUBY_FLAG] === true) unfuseRuby(this); } catch (e) {}
          return prevCOD.apply(this, args);
        };
        cleanups.push(() => {
          try { if (PlantF.prototype.characterOnDisable && PlantF.prototype.__gpnRubyCOD) PlantF.prototype.characterOnDisable = prevCOD; } catch (e) {}
          try { delete PlantF.prototype.__gpnRubyCOD; } catch (e) {}
        });
      }
    } catch (e) {}
  })();
  (function installTripleGatlingBoss() {
    if (log) log.info('PEP [TripleBoss] disabled in preview build');
    return;
    const MG5 = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('MegaGatlingPeaPlant') : null;
    const TP = engine && typeof engine.getClassByName === 'function' ? (engine.getClassByName('ThreePeater') || engine.getClassByName('ThreePeaterPlant')) : null;
    const PS = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('PeashooterPlant') : null;
    if (!MG5 || !MG5.prototype || !TP || !TP.prototype || !PS || !PS.prototype) {
      if (log) log.warn('PEP: MegaGatling/ThreePeater/Peashooter class missing, triple boss skipped');
      return;
    }
    const BOSS_KEY = '__gpnTripleBoss';
    const BOSS_UPGRADED = '__gpnTripleUpgraded';
    const BOSS_PENDING = '__gpnTriplePending';
    const BOSS_SOUND = '__gpnTripleSound';
    const BOSS_BARREL_T = 8 / 30;
    const BOSS_ATLAS = 'assets/atlases/threepeater-gatling.png.b64';
    const BOSS_R_HEAD = { x: 272, y: 16, width: 176, height: 160, pivotX: 88, pivotY: 84 };
    const BOSS_R_B4 = { x: 528, y: 16, width: 240, height: 160, pivotX: 88, pivotY: 84 };
    const BOSS_R_B5 = { x: 768, y: 16, width: 240, height: 160, pivotX: 88, pivotY: 84 };
    const BOSS_R_H1 = { x: 272, y: 192, width: 176, height: 160, pivotX: 104.854, pivotY: 118.322 };
    const BOSS_R_H3 = { x: 272, y: 352, width: 176, height: 160, pivotX: 104.854, pivotY: 118.322 };
    const BOSS_BONES = {
      faceR: { scaleX: 0.85, scaleY: 0.85 },
      faceM: { scaleX: 0.85, scaleY: 0.85 },
      faceL: { scaleX: 0.85, scaleY: 0.85 },
      eyeRR: { x: 4.5, y: 0.25 },
      eyeRM: { x: 4.5, y: 0.25 },
      eyeRL: { x: 4.5, y: 0.25 },
      eyeLR: { x: 4.9, y: 1.4 },
      eyeLM: { x: 4.9, y: 1.4 },
      eyeLL: { x: 4.9, y: 1.4 },
    };
    let bossTexturePromise = null;
    let bossTextureRef = null;
    const bossStates = new Map();
    const bossSnapshots = new Map();
    const pfScatterCounts = new WeakMap();
    const loadHtmlImage5 = (b64) => new Promise((resolve, reject) => {
      try {
        const img = typeof Image === 'function' ? new Image() : document.createElement('img');
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error('atlas decode failed'));
        img.src = 'data:image/png;base64,' + b64;
      } catch (e) { reject(e); }
    });
    const ensureBossTexture = () => {
      if (bossTexturePromise) return bossTexturePromise;
      bossTexturePromise = (async () => {
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        if (!cc || typeof cc.ImageAsset !== 'function' || typeof cc.Texture2D !== 'function') throw new Error('cc tex api unavailable');
        const encoded = await ctx.data.readText(BOSS_ATLAS);
        const base64 = typeof encoded === 'string' ? encoded.trim() : '';
        if (!base64) throw new Error('boss atlas missing');
        const image = await loadHtmlImage5(base64);
        if (image.width !== 1024 || image.height !== 512) throw new Error('bad boss atlas ' + image.width + 'x' + image.height);
        const ia = new cc.ImageAsset(image);
        const tex = new cc.Texture2D();
        tex.image = ia;
        bossTextureRef = tex;
        return tex;
      })();
      bossTexturePromise.catch(() => { bossTexturePromise = null; });
      return bossTexturePromise;
    };
    const gpnPlantAlive = (pl) => {
      try {
        return !!pl && !pl.dead && (typeof pl.isAlive !== 'function' || pl.isAlive());
      } catch (e) {}
      return !!pl && !pl.dead;
    };
    const gpnHealthRatio = (pl) => {
      try {
        const hp = Number(pl && pl.health);
        const th = Number((pl && (pl.toughness ?? (pl._objdataOwn && pl._objdataOwn.Toughness))) || 0);
        if (!(hp >= 0) || !(th > 0)) return 1;
        return Math.max(0, Math.min(1, hp / th));
      } catch (e) {}
      return 1;
    };
    const gpnApplyHealthRatio = (pl, ratio) => {
      try {
        const th = Number((pl && (pl.toughness ?? (pl._objdataOwn && pl._objdataOwn.Toughness))) || 0);
        if (!(th > 0)) return;
        pl.health = Math.max(1, Math.min(th, th * ratio));
      } catch (e) {}
    };
    const gpnPickSoundRes = (pl) => {
      try {
        const s = pl && pl[BOSS_SOUND];
        if (s && typeof s.playShoot5 === 'function') return s;
        const s2 = pl && pl.soundRes;
        if (s2 && typeof s2.playShoot5 === 'function') return s2;
      } catch (e) {}
      return null;
    };
    const gpnRemoveQuietly = (pl) => {
      try { pl.__gpnAbsorbed = true; } catch (e) {}
      try {
        const lc = pl.plantInLnC || pl.inLnC;
        if (lc && Array.isArray(lc.plantInSquare)) {
          const idx = lc.plantInSquare.indexOf(pl);
          if (idx >= 0) lc.plantInSquare.splice(idx, 1);
          if (typeof lc.readIndex === 'function') lc.readIndex();
        }
      } catch (e) {}
      try {
        if (typeof pl.die === 'function') pl.die(false, false, false, false, true);
      } catch (e) {}
      try {
        if (pl.node) {
          if (pl.node.destroy) pl.node.destroy();
          else pl.node.active = false;
        }
      } catch (e) {}
    };
    const gpnBossSlotName = (slot) => {
      try {
        return String(slot.name ?? (slot._slotData && slot._slotData.name) ?? '');
      } catch (e) {}
      return '';
    };
    const gpnBossIsSrcTex = (tex) =>
      Number(tex && tex.width) === 256 && Number(tex && tex.height) === 512;
    const gpnBossDispIdx = (name) => {
      if (/^COS2_[RML]$/.test(name)) return 0;
      if (/^COS[01]_[RML]$/.test(name)) return -1;
      return null;
    };
    const gpnBossRegion = (name, state) => {
      const hm = /^head([RML])$/.exec(name);
      if (hm && state.visibleBarrels.has(hm[1])) {
        return state.upgraded ? BOSS_R_B5 : BOSS_R_B4;
      }
      if (/^COS2_[RML]$/.test(name)) {
        return state.upgraded ? BOSS_R_H3 : BOSS_R_H1;
      }
      if (/^head[RML]$/.test(name)) return BOSS_R_HEAD;
      return null;
    };
    const gpnCloneTexDataRegion = (srcData, tex, SpriteFrame, region) => {
      if (!srcData || !srcData.spriteFrame) return null;
      const data = pepCloneRuntime(srcData);
      const frame = pepCloneSpriteFrame(srcData.spriteFrame, tex, SpriteFrame);
      if (!data || !frame) return null;
      data.spriteFrame = frame;
      if (region) {
        const reg = pepCloneRuntime(srcData.region) ?? {};
        for (const k of ['x', 'y', 'width', 'height']) reg[k] = region[k];
        data.region = reg;
        data.frame = null;
        data.rotated = false;
      }
      return data;
    };
    const gpnBossPivot = (record) => {
      try {
        const ov = record.regionOverride;
        if (!ov || !record.slot) return;
        record.slot._pivotX = ov.pivotX;
        record.slot._pivotY = ov.pivotY;
        record.slot._transformDirty = true;
        record.slot._worldMatrixDirty = true;
      } catch (e) {}
    };
    const gpnBossApplySlot = (record) => {
      try {
        if (!record.active || !record.slot || !record.targetTexture) return;
        const td = record.slot._textureData;
        const sf = td && td.spriteFrame;
        if (!sf) return;
        const isTarget = sf.texture === record.targetTexture;
        if (!isTarget && !gpnBossIsSrcTex(sf.texture)) return;
        record.eligible = true;
        const reg = record.regionOverride;
        const regSame =
          !reg ||
          (Number(td.region && td.region.x) === reg.x &&
            Number(td.region && td.region.y) === reg.y &&
            Number(td.region && td.region.width) === reg.width &&
            Number(td.region && td.region.height) === reg.height);
        if (isTarget && regSame) {
          gpnBossPivot(record);
          return;
        }
        const data = gpnCloneTexDataRegion(td, record.targetTexture, record.SpriteFrame, reg);
        if (!data) return;
        record.slot._textureData = data;
        gpnBossPivot(record);
        if (record.slot._updateFrame) record.slot._updateFrame();
        if (record.slot._updateTransform) record.slot._updateTransform();
      } catch (e) {}
    };
    const gpnBossApplyBone = (rec) => {
      try {
        if (!rec.bone || !rec.bone.offset) return;
        let changed = false;
        for (const [k, v] of Object.entries(rec.target)) {
          if (Number(rec.bone.offset[k]) !== v) {
            rec.bone.offset[k] = v;
            changed = true;
          }
        }
        if (changed) {
          if (rec.bone.invalidUpdate) rec.bone.invalidUpdate();
          if (rec.armature && rec.armature.invalidUpdate)
            rec.armature.invalidUpdate(rec.boneName, true);
        }
      } catch (e) {}
    };
    const gpnBossInstallBones = (arm) => {
      const out = [];
      try {
        for (const [boneName, adj] of Object.entries(BOSS_BONES)) {
          let bone = null;
          try {
            bone = arm.getBone ? arm.getBone(boneName) : null;
          } catch (e) {}
          if (!bone || !bone.offset) continue;
          const original = {};
          const target = {};
          let ok = true;
          for (const [k, v] of Object.entries(adj)) {
            const cur = Number(bone.offset[k]);
            if (!isFinite(cur)) { ok = false; break; }
            original[k] = cur;
            target[k] = k.startsWith('scale') ? cur * v : cur + v;
          }
          if (!ok) continue;
          const rec = { armature: arm, bone, boneName, original, target };
          gpnBossApplyBone(rec);
          out.push(rec);
        }
      } catch (e) {}
      return out;
    };
    const gpnBossRestoreBones = (recs) => {
      for (const rec of recs || []) {
        try {
          for (const [k, v] of Object.entries(rec.original)) rec.bone.offset[k] = v;
          if (rec.bone.invalidUpdate) rec.bone.invalidUpdate();
          if (rec.armature && rec.armature.invalidUpdate)
            rec.armature.invalidUpdate(rec.boneName, true);
        } catch (e) {}
      }
    };
    const gpnBossInstall = (plant, texture, upgraded) => {
      try {
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        const display = plant.anmControl ? plant.anmControl.db : null;
        const arm = display ? pepArmOf(display) : null;
        if (!cc || !display || !arm) return null;
        const state = {
          plant, display, targetTexture: texture, SpriteFrame: cc.SpriteFrame,
          upgraded: !!upgraded, visibleBarrels: new Set(), barrelTokens: new Map(),
          records: [], bones: [], active: true,
        };
        state.records = pepCollectSlots(arm, [], new Set()).map((slot) => {
          const name = gpnBossSlotName(slot);
          const hadOwn = Object.prototype.hasOwnProperty.call(slot, '_updateDisplayData');
          const origUpdate = slot._updateDisplayData;
          const record = {
            slot, name, state, SpriteFrame: cc.SpriteFrame, targetTexture: texture,
            originalTextureData: slot._textureData, originalUpdate: origUpdate, hadOwn,
            originalDisplayIndex: Number(slot.displayIndex ?? slot._displayIndex ?? -1),
            originalPivotX: Number(slot._pivotX ?? 0), originalPivotY: Number(slot._pivotY ?? 0),
            regionOverride: gpnBossRegion(name, state), eligible: false, active: true, hooked: false,
          };
          const wantIdx = gpnBossDispIdx(name);
          if (wantIdx !== null) {
            try {
              if (Number(slot.displayIndex) !== wantIdx) slot.displayIndex = wantIdx;
            } catch (e) {
              try { if (slot._setDisplayIndex) slot._setDisplayIndex(wantIdx, true); } catch (e2) {}
            }
          }
          let srcTex = null;
          try {
            srcTex = slot.getTexture
              ? slot.getTexture()
              : slot._textureData && slot._textureData.spriteFrame
                ? slot._textureData.spriteFrame.texture
                : null;
          } catch (e) {}
          record.eligible = srcTex === texture || gpnBossIsSrcTex(srcTex);
          if (srcTex && typeof texture.setFilters === 'function' && Number.isFinite(srcTex._minFilter)) {
            try { texture.setFilters(srcTex._minFilter, srcTex._magFilter); } catch (e) {}
          }
          if (typeof origUpdate === 'function') {
            const wrapped = function (...args) {
              const r = origUpdate.apply(this, args);
              try {
                const st = record.state;
                if (!st || !st.active) return r;
                const di = gpnBossDispIdx(record.name);
                record.regionOverride = gpnBossRegion(record.name, st);
                if (di !== null) {
                  try {
                    if (Number(record.slot.displayIndex) !== di) record.slot.displayIndex = di;
                  } catch (e) {
                    try { if (record.slot._setDisplayIndex) record.slot._setDisplayIndex(di, true); } catch (e2) {}
                  }
                }
                gpnBossApplySlot(record);
              } catch (e) {}
              return r;
            };
            try {
              slot._updateDisplayData = wrapped;
              record.hooked = slot._updateDisplayData === wrapped;
            } catch (e) {}
          }
          gpnBossApplySlot(record);
          return record;
        });
        state.bones = gpnBossInstallBones(arm);
        try { if (display.markForUpdateRenderData) display.markForUpdateRenderData(); } catch (e) {}
        return state;
      } catch (e) {}
      return null;
    };
    const gpnBossRefresh = (state, upgraded) => {
      try {
        if (!state || !state.active) return;
        state.upgraded = !!upgraded;
        for (const record of state.records) {
          const di = gpnBossDispIdx(record.name);
          record.regionOverride = gpnBossRegion(record.name, state);
          if (di !== null) {
            try {
              if (Number(record.slot.displayIndex) !== di) record.slot.displayIndex = di;
            } catch (e) {
              try { if (record.slot._setDisplayIndex) record.slot._setDisplayIndex(di, true); } catch (e2) {}
            }
          }
          gpnBossApplySlot(record);
        }
        for (const rec of state.bones) gpnBossApplyBone(rec);
        try { if (state.display.markForUpdateRenderData) state.display.markForUpdateRenderData(); } catch (e) {}
      } catch (e) {}
    };
    const gpnBossRestoreState = (state) => {
      try {
        if (!state || !state.active) return;
        state.active = false;
        for (const record of state.records) {
          record.active = false;
          const slot = record.slot;
          try {
            if (record.hooked) {
              if (record.hadOwn) slot._updateDisplayData = record.originalUpdate;
              else delete slot._updateDisplayData;
            }
            try {
              const di = record.originalDisplayIndex;
              if (Number(slot.displayIndex) !== di) slot.displayIndex = di;
            } catch (e) {
              try { if (slot._setDisplayIndex) slot._setDisplayIndex(record.originalDisplayIndex, true); } catch (e2) {}
            }
            if (typeof record.originalUpdate === 'function') record.originalUpdate.call(slot);
            else slot._textureData = record.originalTextureData;
            slot._pivotX = record.originalPivotX;
            slot._pivotY = record.originalPivotY;
            slot._transformDirty = true;
            slot._worldMatrixDirty = true;
            if (slot._updateFrame) slot._updateFrame();
            if (slot._updateTransform) slot._updateTransform();
          } catch (e) {
            try {
              slot._textureData = record.originalTextureData;
              slot._pivotX = record.originalPivotX;
              slot._pivotY = record.originalPivotY;
              if (slot._updateFrame) slot._updateFrame();
            } catch (e2) {}
          }
        }
        gpnBossRestoreBones(state.bones);
        try { if (state.display.markForUpdateRenderData) state.display.markForUpdateRenderData(); } catch (e) {}
      } catch (e) {}
    };
    const gpnBossShowBarrel = (plant, laneCode) => {
      try {
        const state = bossStates.get(plant);
        if (!state || !state.active || !/^[RML]$/.test(laneCode)) return;
        const token = (state.barrelTokens.get(laneCode) ?? 0) + 1;
        state.barrelTokens.set(laneCode, token);
        state.visibleBarrels.add(laneCode);
        gpnBossRefresh(state, state.upgraded);
        const hide = () => {
          try {
            if (!state.active || state.barrelTokens.get(laneCode) !== token) return;
            state.visibleBarrels.delete(laneCode);
            gpnBossRefresh(state, state.upgraded);
          } catch (e) {}
        };
        if (typeof plant.scheduleOnce === 'function') plant.scheduleOnce(hide, BOSS_BARREL_T);
      } catch (e) {}
    };
    const BOSS_DATA_KEYS = [
      'ShootInterval', 'ShootIntervalAdditional', 'PeaType', 'PeaTypePlantfood',
      'PlantfoodPeaCount', 'ChanceToPlantfood', 'Toughness',
    ];
    const gpnCaptureBossSnapshot = (plant) => ({
      data: plant ? plant._objdataOwn : null,
      values: Object.fromEntries(
        BOSS_DATA_KEYS.map((k) => [
          k,
          {
            hadOwn: Boolean(plant && plant._objdataOwn && Object.prototype.hasOwnProperty.call(plant._objdataOwn, k)),
            value: plant && plant._objdataOwn ? plant._objdataOwn[k] : undefined,
          },
        ])
      ),
      minShootInterval: plant ? plant.minShootInterval : undefined,
      speedMult: plant ? plant.ProjectileSpeedMult : undefined,
      hadMarker: Boolean(plant && Object.prototype.hasOwnProperty.call(plant, BOSS_KEY)),
      markerValue: plant ? plant[BOSS_KEY] : undefined,
    });
    const gpnRestoreBossSnapshot = (plant, snap) => {
      try {
        if (!plant || !snap) return;
        if (snap.data) {
          for (const [k, o] of Object.entries(snap.values)) {
            if (o.hadOwn) snap.data[k] = o.value;
            else delete snap.data[k];
          }
        }
        plant.minShootInterval = snap.minShootInterval;
        plant.ProjectileSpeedMult = snap.speedMult;
        delete plant[BOSS_UPGRADED];
        delete plant[BOSS_SOUND];
        delete plant[BOSS_PENDING];
        if (snap.hadMarker) plant[BOSS_KEY] = snap.markerValue;
        else delete plant[BOSS_KEY];
      } catch (e) {}
    };
    const gpnConfigureBoss = (plant, carried) => {
      const patch = {
        ShootInterval: 1.35,
        ShootIntervalAdditional: 0.15,
        PeaType: 'pea',
        PeaTypePlantfood: 'pea',
        PlantfoodPeaCount: BOSS_PF_COUNT,
        ChanceToPlantfood: BOSS_PF_CHANCE,
        Toughness: 300,
      };
      if (typeof plant.modObjdataOwn === 'function') plant.modObjdataOwn(patch);
      Object.assign(plant._objdataOwn, patch);
      plant.minShootInterval = 1.1;
      plant.ProjectileSpeedMult = BOSS_SPEED_MULT;
      plant[BOSS_KEY] = BOSS_KEY;
      plant[BOSS_UPGRADED] = !!carried.upgraded;
      const snd = carried.soundRes;
      if (snd) plant[BOSS_SOUND] = snd;
      gpnApplyHealthRatio(plant, carried.healthRatio);
      plant.__gpnFusion = { src: 17, peaType: null, triple: true };
    };
    const gpnBossCreate = (host, threepeater) => {
      try {
        if (!host || !threepeater || threepeater[BOSS_PENDING]) return;
        if (threepeater[BOSS_KEY] === BOSS_KEY) return; 
        if (!threepeater._objdataOwn) return;
        threepeater[BOSS_PENDING] = true;
        const carried = {
          healthRatio: gpnHealthRatio(host),
          upgraded: false,
          soundRes: gpnPickSoundRes(host),
        };
        try {
          const snapshot = gpnCaptureBossSnapshot(threepeater);
          gpnConfigureBoss(threepeater, carried);
          bossSnapshots.set(threepeater, snapshot);
        } catch (e) {
          delete threepeater[BOSS_PENDING];
          return;
        }
        ensureBossTexture()
          .then((tex) => {
            try {
              if (gpnPlantAlive(threepeater) && threepeater[BOSS_KEY]) {
                const st = gpnBossInstall(threepeater, tex, carried.upgraded);
                if (st) {
                  bossStates.set(threepeater, st);
                  gpnBossRefresh(st, threepeater[BOSS_UPGRADED]);
                  if (log) log.info('PEP [TripleBoss] boss skin applied');
                }
              }
            } catch (e) {}
          })
          .catch((e) => {
            if (log) log.warn('PEP [TripleBoss] boss skin fail ' + (e && e.message ? e.message : e));
          });
        gpnRemoveQuietly(host);
        if (log) log.info('PEP [TripleBoss] created hp=' + carried.healthRatio.toFixed(2));
      } finally {
        delete threepeater[BOSS_PENDING];
      }
    };
    const tp = TP.prototype;
    const megaPF = PS.prototype.specialPlantFood;
    const makeScatterDir = (idx) => {
      try {
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        const Vec2 = cc && cc.Vec2;
        if (typeof Vec2 !== 'function') return null;
        const seq = idx % BOSS_SPREAD_SLOTS;
        const off = seq === 0 ? 0 : Math.ceil(seq / 2) * (seq % 2 === 1 ? 1 : -1);
        const maxOff = (BOSS_SPREAD_SLOTS - 1) / 2;
        const ang = ((off / maxOff) * BOSS_SPREAD_DEG * Math.PI) / 180;
        return new Vec2(Math.cos(ang), Math.sin(ang));
      } catch (e) {}
      return null;
    };
    try {
      if (typeof PS.prototype.foodShooting === 'function') {
        const prevFS = PS.prototype.foodShooting;
        PS.prototype.foodShooting = function () {
          try { if (this[BOSS_KEY] === BOSS_KEY) pfScatterCounts.set(this, 0); } catch (e) {}
          return prevFS.apply(this, arguments);
        };
        cleanups.push(() => { try { if (PS.prototype.foodShooting && PS.prototype.foodShooting.__gpnTBFood) PS.prototype.foodShooting = prevFS; } catch (e) {} });
        try { PS.prototype.foodShooting.__gpnTBFood = true; } catch (e) {}
      }
      if (typeof PS.prototype._shoot === 'function') {
        const prevShootPS = PS.prototype._shoot;
        PS.prototype._shoot = function () {
          try {
            if (this[BOSS_KEY] === BOSS_KEY && (this.fooding === true || arguments[0] === true)) {
              const idx = pfScatterCounts.get(this) ?? 0;
              const dir = makeScatterDir(idx);
              const arr = Array.from(arguments);
              if (dir) arr[4] = dir;
              pfScatterCounts.set(this, idx + 1);
              return prevShootPS.apply(this, arr);
            }
          } catch (e) {}
          return prevShootPS.apply(this, arguments);
        };
        cleanups.push(() => { try { if (PS.prototype._shoot && PS.prototype._shoot.__gpnTBShoot) PS.prototype._shoot = prevShootPS; } catch (e) {} });
        try { PS.prototype._shoot.__gpnTBShoot = true; } catch (e) {}
      }
      if (typeof tp._shoot3 === 'function') {
        const prevS3 = tp._shoot3;
        tp._shoot3 = function () {
          try {
            if (this[BOSS_KEY] !== BOSS_KEY) return prevS3.apply(this, arguments);
            if (this.fooding === true) return;
            const result = prevS3.apply(this, arguments);
            const count = this[BOSS_UPGRADED] ? BOSS_SHOTS_UP : BOSS_SHOTS;
            for (let shot = 1; shot < count; shot++) {
              const fire = () => {
                try {
                  if (this[BOSS_KEY] === BOSS_KEY && this.fooding !== true && gpnPlantAlive(this)) {
                    return prevS3.apply(this, arguments);
                  }
                } catch (e) {}
              };
              const delay = shot * BOSS_BURST;
              if (typeof this.scheduleOnce === 'function') this.scheduleOnce(fire, delay);
              else fire();
            }
            return result;
          } catch (e) {
            return prevS3 ? prevS3.apply(this, arguments) : undefined;
          }
        };
        cleanups.push(() => { try { if (tp._shoot3 && tp._shoot3.__gpnTBS3) tp._shoot3 = prevS3; } catch (e) {} });
        try { tp._shoot3.__gpnTBS3 = true; } catch (e) {}
      }
      const prevAnim = tp.animationListener;
      tp.animationListener = function () {
        try {
          if (this[BOSS_KEY] !== BOSS_KEY || !prevAnim)
            return prevAnim ? prevAnim.apply(this, arguments) : undefined;
          const eventName = arguments[0] && arguments[0].name;
          const lane =
            eventName === 'shootU' ? { code: 0, slot: 'R' }
            : eventName === 'shootM' ? { code: 1, slot: 'M' }
            : eventName === 'shootD' ? { code: 2, slot: 'L' }
            : null;
          if (!lane) return prevAnim.apply(this, arguments);
          gpnBossShowBarrel(this, lane.slot);
          const result = this._shoot3(lane.code);
          if (eventName === 'shootM') {
            const sres = this[BOSS_SOUND];
            try {
              if (this[BOSS_UPGRADED]) { if (sres && sres.playShoot5) sres.playShoot5(0.3); }
              else if (sres && sres.playShoot) sres.playShoot(0.3);
            } catch (e) {}
          }
          return result;
        } catch (e) {
          return prevAnim ? prevAnim.apply(this, arguments) : undefined;
        }
      };
      cleanups.push(() => { try { if (tp.animationListener && tp.animationListener.__gpnTBAnim) tp.animationListener = prevAnim; } catch (e) {} });
      try { tp.animationListener.__gpnTBAnim = true; } catch (e) {}
      if (typeof tp._shootPeaAnimation === 'function') {
        const prevSPA = tp._shootPeaAnimation;
        tp._shootPeaAnimation = function () {
          try {
            if (this[BOSS_KEY] === BOSS_KEY && this._objdataOwn && Math.random() <= (this._objdataOwn.ChanceToPlantfood ?? BOSS_PF_CHANCE)) {
              if (typeof this.food === 'function') return this.food();
            }
          } catch (e) {}
          return prevSPA.apply(this, arguments);
        };
        cleanups.push(() => { try { if (tp._shootPeaAnimation && tp._shootPeaAnimation.__gpnTBSpa) tp._shootPeaAnimation = prevSPA; } catch (e) {} });
        try { tp._shootPeaAnimation.__gpnTBSpa = true; } catch (e) {}
      }
      if (typeof tp.specialPlantFood === 'function') {
        const prevSPF = tp.specialPlantFood;
        tp.specialPlantFood = function () {
          try {
            if (this[BOSS_KEY] === BOSS_KEY) {
              this[BOSS_UPGRADED] = true;
              const st = bossStates.get(this);
              if (st) gpnBossRefresh(st, true);
              pfScatterCounts.set(this, 0);
              if (megaPF) return megaPF.apply(this, arguments);
            }
          } catch (e) {}
          return prevSPF.apply(this, arguments);
        };
        cleanups.push(() => { try { if (tp.specialPlantFood && tp.specialPlantFood.__gpnTBSpf) tp.specialPlantFood = prevSPF; } catch (e) {} });
        try { tp.specialPlantFood.__gpnTBSpf = true; } catch (e) {}
      }
      if (typeof tp.update === 'function') {
        const prevUpd = tp.update;
        tp.update = function () {
          const r = prevUpd.apply(this, arguments);
          try {
            if (this[BOSS_KEY] === BOSS_KEY) {
              const st = bossStates.get(this);
              if (st && st.active) gpnBossRefresh(st, this[BOSS_UPGRADED]);
            }
          } catch (e) {}
          return r;
        };
        cleanups.push(() => { try { if (tp.update && tp.update.__gpnTBUpd) tp.update = prevUpd; } catch (e) {} });
        try { tp.update.__gpnTBUpd = true; } catch (e) {}
      }
      if (log) log.info('PEP [TripleBoss] hooks installed');
    } catch (e) {}
    try {
      const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
      if (PlantF && PlantF.prototype && typeof PlantF.prototype.characterOnDisable === 'function' && !PlantF.prototype.__gpnTBCOD) {
        PlantF.prototype.__gpnTBCOD = true;
        const prevCOD = PlantF.prototype.characterOnDisable;
        PlantF.prototype.characterOnDisable = function () {
          try {
            if (bossSnapshots.has(this)) {
              const st = bossStates.get(this);
              if (st) { gpnBossRestoreState(st); bossStates.delete(this); }
              gpnRestoreBossSnapshot(this, bossSnapshots.get(this));
              bossSnapshots.delete(this);
              delete this.__gpnFusion;
            }
          } catch (e) {}
          return prevCOD.apply(this, arguments);
        };
        cleanups.push(() => {
          try { if (PlantF.prototype.characterOnDisable && PlantF.prototype.__gpnTBCOD) PlantF.prototype.characterOnDisable = prevCOD; } catch (e) {}
          try { delete PlantF.prototype.__gpnTBCOD; } catch (e) {}
        });
      }
    } catch (e) {}
    try {
      const LnC = engine.getClassByName ? engine.getClassByName('LnC') : null;
      if (LnC && LnC.prototype && typeof LnC.prototype.putPlantAvailable === 'function' && !LnC.prototype.__gpnTBOverlap) {
        LnC.prototype.__gpnTBOverlap = true;
        const orig = LnC.prototype.putPlantAvailable;
        LnC.prototype.putPlantAvailable = function (t, e, n, i, o, a) {
          try {
            const id = Number(e);
            if (id === 9 || id === 17) {
              const arr = this.plantInSquare;
              if (Array.isArray(arr) && arr.length > 0) {
                const hasBoss = arr.some((pl) => {
                  try { return !!(pl && !pl.dead && pl[BOSS_KEY] === BOSS_KEY); } catch (e2) { return false; }
                });
                if (hasBoss) {
                  if (log) log.info('PEP [TripleBoss] overlap deny: boss on square, plant=' + id);
                  return orig.apply(this, arguments);
                }
                const need = id === 9 ? 17 : 9;
                const has = arr.some((pl) => {
                  try {
                    if (!pl || pl.dead) return false;
                    const pid = Number(pl.ID != null ? pl.ID : pl._plantID);
                    if (pid === need) return true;
                    if (need === 17 && pl.constructor === TP) return true;
                    if (need === 9 && (pid === 9 || pl.constructor === MG5)) return true;
                    return false;
                  } catch (e2) { return false; }
                });
                if (has) return true;
              }
            }
          } catch (e) {}
          return orig.apply(this, arguments);
        };
        cleanups.push(() => {
          try { if (LnC.prototype.putPlantAvailable && LnC.prototype.__gpnTBOverlap) LnC.prototype.putPlantAvailable = orig; } catch (e) {}
          try { delete LnC.prototype.__gpnTBOverlap; } catch (e) {}
        });
        if (log) log.info('PEP [TripleBoss] overlap ON (MG+ThreePeater)');
      }
    } catch (e) {}
    let tbScanTimer = null;
    try {
      tbScanTimer = setInterval(() => {
        try {
          const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
          const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
          if (!cc || !PlantF) return;
          const scene = cc.director.getScene();
          if (!scene) return;
          const list = scene.getComponentsInChildren(PlantF);
          if (!Array.isArray(list)) return;
          for (const p of list) {
            try {
              if (!p.node || !p.node.isValid || p.dead) continue;
              if (p[BOSS_PENDING]) continue;
              const lc = p.plantInLnC || p.inLnC;
              if (!lc || !lc.plantInSquare || !lc.plantInSquare.length) continue;
              const isMG = p.constructor === MG5 || p.ID === 9;
              const isTP = (p.constructor === TP || p.ID === 17) && !(p[BOSS_KEY] === BOSS_KEY);
              if (!isMG && !isTP) continue;
              for (const other of lc.plantInSquare) {
                if (!other || other === p || !other.node || !other.node.isValid || other.dead) continue;
                if (isMG && (other.constructor === TP || other.ID === 17) && !(other[BOSS_KEY] === BOSS_KEY)) {
                  gpnBossCreate(p, other);
                  break;
                }
                if (isTP && (other.constructor === MG5 || other.ID === 9)) {
                  gpnBossCreate(other, p);
                  break;
                }
              }
            } catch (e) {}
          }
        } catch (e) {}
      }, 200);
      cleanups.push(() => { try { clearInterval(tbScanTimer); } catch (e) {} });
    } catch (e) {}
  })();
  (function installSplitGatling() {
    const MG6 = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('MegaGatlingPeaPlant') : null;
    const SP2 = engine && typeof engine.getClassByName === 'function' ? engine.getClassByName('SplitPeaPlant') : null;
    if (!MG6 || !MG6.prototype || !SP2 || !SP2.prototype) {
      if (log) log.warn('PEP: MegaGatling/SplitPeaPlant class missing, split gatling skipped');
      return;
    }
    const spProto = SP2.prototype;
    if (
      typeof spProto._shoot !== 'function' ||
      typeof spProto._shootBack !== 'function' ||
      typeof spProto.specialPlantFood !== 'function' ||
      typeof spProto.specialPeashooterAnimationListener !== 'function' ||
      typeof spProto.characterOnDisable !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on SplitPeaPlant, split gatling skipped');
      return;
    }
    const SPLIT_ID = 61;
    const SG_FLAG = '__gpnSplitGatling';       
    const SG_PENDING = '__gpnSplitPending';
    const SG_SOUND = '__gpnSplitSound';
    const SG_CYCLE_MS = 700;     
    const SG_PF_CHANCE = 0.05;   
    const SG_BACK_ICE_PEA = 'pea_snow';        
    const SG_BACK_ICICLE = 'snowdrop_freeze';  
    const sgPickAttr = () => { try { return MEGA_ATTR_POOL[Math.floor(Math.random() * MEGA_ATTR_POOL.length)] || 'pea'; } catch (e) { return 'pea'; } };
    const sgIsFullLevel = (self) => { try { return (Number(self.__gpnPepUltCount) || 0) >= FULL_ULT_COUNT; } catch (e) { return false; } };
    const SG_ATLAS = 'assets/atlases/mega-gatling-splitpea.png.b64';
    const sgStates = new Map();      
    const sgSnapshots = new Map();   
    let sgTexturePromise = null;
    let sgTextureRef = null;
    const sgAlive = (pl) => { try { return !!pl && !pl.dead && (typeof pl.isAlive !== 'function' || pl.isAlive()); } catch (e) {} return !!pl && !pl.dead; };
    const sgHealthRatio = (pl) => {
      try {
        const hp = Number(pl && pl.health);
        const th = Number((pl && (pl.toughness ?? (pl._objdataOwn && pl._objdataOwn.Toughness))) || 0);
        if (!(hp >= 0) || !(th > 0)) return 1;
        return Math.max(0, Math.min(1, hp / th));
      } catch (e) {}
      return 1;
    };
    const sgApplyHealthRatio = (pl, ratio) => {
      try {
        const th = Number((pl && (pl.toughness ?? (pl._objdataOwn && pl._objdataOwn.Toughness))) || 0);
        if (!(th > 0)) return;
        pl.health = Math.max(1, Math.min(th, th * ratio));
      } catch (e) {}
    };
    const sgPickSound = (pl) => {
      try {
        const s = pl && pl[SG_SOUND];
        if (s && typeof s.playShoot === 'function') return s;
        const s2 = pl && pl.soundRes;
        if (s2 && typeof s2.playShoot === 'function') return s2;
      } catch (e) {}
      return null;
    };
    const sgIsMG = (pl) => {
      try { return !!pl && (pl.constructor === MG6 || Number(pl.ID != null ? pl.ID : pl._plantID) === 9); } catch (e) { return false; }
    };
    const sgIsSplit = (pl) => {
      try {
        if (!pl || pl.dead) return false;
        if (pl[SG_FLAG] === true) return false;
        const pid = Number(pl.ID != null ? pl.ID : pl._plantID);
        return pid === SPLIT_ID || pl.constructor === SP2;
      } catch (e) { return false; }
    };
    const sgRemoveQuietly = (pl) => {
      try { pl.__gpnAbsorbed = true; } catch (e) {}
      try {
        const lc = pl.plantInLnC || pl.inLnC;
        if (lc && Array.isArray(lc.plantInSquare)) {
          const idx = lc.plantInSquare.indexOf(pl);
          if (idx >= 0) lc.plantInSquare.splice(idx, 1);
          if (typeof lc.readIndex === 'function') lc.readIndex();
        }
      } catch (e) {}
      try { if (typeof pl.die === 'function') pl.die(false, false, false, false, true); } catch (e) {}
      try {
        if (pl.node) {
          if (pl.node.destroy) pl.node.destroy();
          else pl.node.active = false;
        }
      } catch (e) {}
    };
    const sgLoadImage = (b64) => new Promise((resolve, reject) => {
      try {
        const img = typeof Image === 'function' ? new Image() : document.createElement('img');
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error('atlas decode failed'));
        img.src = 'data:image/png;base64,' + b64;
      } catch (e) { reject(e); }
    });
    const sgEnsureTexture = () => {
      if (sgTexturePromise) return sgTexturePromise;
      sgTexturePromise = (async () => {
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        if (!cc || typeof cc.ImageAsset !== 'function' || typeof cc.Texture2D !== 'function') throw new Error('cc tex api unavailable');
        const encoded = await ctx.data.readText(SG_ATLAS);
        const base64 = typeof encoded === 'string' ? encoded.trim() : '';
        if (!base64) throw new Error('split atlas missing');
        const image = await sgLoadImage(base64);
        if (image.width !== 1024 || image.height !== 1024) throw new Error('bad split atlas ' + image.width + 'x' + image.height);
        const tex = new cc.Texture2D();
        tex.image = new cc.ImageAsset(image);
        sgTextureRef = tex;
        return tex;
      })();
      sgTexturePromise.catch(() => { sgTexturePromise = null; });
      return sgTexturePromise;
    };
    const SG_SPLIT_REGIONS = Object.freeze({
      COS0_L: Object.freeze({ x: 272, y: 8, width: 240, height: 240, pivotX: 120, pivotY: 120 }),
      COS1_L: Object.freeze({ x: 520, y: 8, width: 240, height: 240, pivotX: 120, pivotY: 120 }),
      COS2_L: Object.freeze({ x: 16, y: 264, width: 240, height: 240, pivotX: 120, pivotY: 120 }),
      COS0_R: Object.freeze({ x: 264, y: 264, width: 240, height: 240, pivotX: 120, pivotY: 120 }),
      COS1_R: Object.freeze({ x: 512, y: 264, width: 240, height: 240, pivotX: 120, pivotY: 120 }),
      COS2_R: Object.freeze({ x: 16, y: 520, width: 240, height: 240, pivotX: 120, pivotY: 120 }),
    });
    const sgSlotNameOf = (slot) => {
      try { return String(slot.name ?? (slot._slotData && slot._slotData.name) ?? ''); } catch (e) {}
      return '';
    };
    const sgIsCosSlot = (name) => /^COS[012]_[LR]$/.test(name);
    const sgDispIdxFor = (name) => (sgIsCosSlot(name) ? 0 : null);
    const sgRegionFor = (name) => SG_SPLIT_REGIONS[name] ?? null;
    const sgCloneTexDataRegion = (srcData, tex, SpriteFrame, region) => {
      try {
        if (!srcData || !srcData.spriteFrame) return null;
        const data = pepCloneRuntime(srcData);
        const frame = pepCloneSpriteFrame(srcData.spriteFrame, tex, SpriteFrame);
        if (!data || !frame) return null;
        data.spriteFrame = frame;
        if (region) {
          const reg = pepCloneRuntime(srcData.region) ?? {};
          for (const k of ['x', 'y', 'width', 'height']) reg[k] = region[k];
          data.region = reg;
          data.frame = null;
          data.rotated = false;
        }
        return data;
      } catch (e) { return null; }
    };
    const sgCosIndex = (name) => { const m = /^COS([012])_([LR])$/.exec(name); return m ? { idx: Number(m[1]), side: m[2] } : null; };
    const sgZFor = (name, zMap) => {
      const ci = sgCosIndex(name);
      if (!ci) return null;
      const headName = ci.side === 'L' ? 'headBack' : 'head';
      const frontName = ci.side === 'L' ? 'mouthBack' : 'mouth';
      const headZ = Number(zMap.get(headName));
      const frontZ = Number(zMap.get(frontName));
      const bgHeadZ = Math.min(
        [zMap.get('headBack'), zMap.get('head')].map((v) => Number(v)).filter(Number.isFinite)
      );
      if (ci.idx === 0) { 
        const off = ci.side === 'L' ? -0.25 : -0.5;
        return Number.isFinite(bgHeadZ) ? bgHeadZ + off : Number.isFinite(headZ) ? headZ - 1.0 : null;
      }
      if (ci.idx === 1) { 
        return Number.isFinite(frontZ) ? frontZ - 0.75 : null;
      }
      return Number.isFinite(frontZ) ? frontZ - 0.5 : null; 
    };
    const sgSetZ = (slot, z, armature) => {
      try {
        if (typeof slot._setZorder === 'function') slot._setZorder(z);
        else { slot._zOrder = z; slot._zOrderDirty = true; }
        if (armature) armature._slotsDirty = true;
      } catch (e) {}
    };
    const sgApplySlotSkin = (record) => {
      try {
        if (!record.active || !record.slot || !record.targetTexture) return;
        const di = sgDispIdxFor(record.name);
        if (di !== null) {
          try { if (Number(record.slot.displayIndex) !== di) record.slot.displayIndex = di; } catch (e) {
            try { if (record.slot._setDisplayIndex) record.slot._setDisplayIndex(di, true); } catch (e2) {}
          }
        }
        if (Number.isFinite(record.zOrderOverride)) sgSetZ(record.slot, record.zOrderOverride, record.armature);
        const td = record.slot._textureData;
        const sf = td && td.spriteFrame;
        if (!sf) return;
        if (sf.texture === record.targetTexture) return;
        const reg = record.regionOverride;
        const data = sgCloneTexDataRegion(td, record.targetTexture, record.SpriteFrame, reg);
        if (!data) return;
        record.slot._textureData = data;
        if (reg && Number.isFinite(reg.pivotX) && Number.isFinite(reg.pivotY)) {
          record.slot._pivotX = reg.pivotX;
          record.slot._pivotY = reg.pivotY;
          record.slot._transformDirty = true;
          record.slot._worldMatrixDirty = true;
        }
        if (record.slot._updateFrame) record.slot._updateFrame();
        if (record.slot._updateTransform) record.slot._updateTransform();
      } catch (e) {}
    };
    const sgInstallSkin = (plant, tex) => {
      try {
        const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        const display = plant.anmControl ? plant.anmControl.db : null;
        const arm = display ? pepArmOf(display) : null;
        if (!cc || !display || !arm) return null;
        const slotsAll = pepCollectSlots(arm, [], new Set());
        const zMap = new Map(slotsAll.map((s) => [sgSlotNameOf(s), Number(s._zOrder ?? 0)]));
        const records = slotsAll.map((slot) => {
          const name = sgSlotNameOf(slot);
          const hadOwn = Object.prototype.hasOwnProperty.call(slot, '_updateDisplayData');
          const origUpdate = slot._updateDisplayData;
          const record = {
            slot, name, armature: arm, SpriteFrame: cc.SpriteFrame, targetTexture: tex,
            originalTextureData: slot._textureData, originalUpdate: origUpdate, hadOwn,
            originalDisplayIndex: Number(slot.displayIndex ?? slot._displayIndex ?? -1),
            originalPivotX: Number(slot._pivotX ?? 0), originalPivotY: Number(slot._pivotY ?? 0),
            originalZOrder: Number(slot._zOrder ?? 0),
            regionOverride: sgRegionFor(name), zOrderOverride: sgZFor(name, zMap),
            active: true, hooked: false,
          };
          const di = sgDispIdxFor(name);
          if (di !== null) {
            try { if (Number(slot.displayIndex) !== di) slot.displayIndex = di; } catch (e) {
              try { if (slot._setDisplayIndex) slot._setDisplayIndex(di, true); } catch (e2) {}
            }
          }
          try {
            const st = slot.getTexture ? slot.getTexture()
              : slot._textureData && slot._textureData.spriteFrame ? slot._textureData.spriteFrame.texture : null;
            if (st && typeof tex.setFilters === 'function' && Number.isFinite(st._minFilter)) {
              tex.setFilters(st._minFilter, st._magFilter);
            }
          } catch (e) {}
          if (typeof origUpdate === 'function') {
            const wrapped = function (...args) {
              const r = origUpdate.apply(this, args);
              try { if (record.active) sgApplySlotSkin(record); } catch (e) {}
              return r;
            };
            try {
              slot._updateDisplayData = wrapped;
              record.hooked = slot._updateDisplayData === wrapped;
            } catch (e) {}
          }
          sgApplySlotSkin(record);
          return record;
        });
        try { if (display.markForUpdateRenderData) display.markForUpdateRenderData(); } catch (e) {}
        return { display, records, active: true };
      } catch (e) { return null; }
    };
    const sgRestoreSkin = (state) => {
      try {
        if (!state || !state.active) return;
        state.active = false;
        for (const record of state.records) {
          record.active = false;
          const slot = record.slot;
          if (!slot) continue;
          try {
            if (record.hooked) {
              if (record.hadOwn) slot._updateDisplayData = record.originalUpdate;
              else delete slot._updateDisplayData;
            }
            const od = record.originalDisplayIndex;
            if (Number.isFinite(od) && od >= 0 && Number(slot.displayIndex) !== od) {
              try { slot.displayIndex = od; } catch (e) {
                try { if (slot._setDisplayIndex) slot._setDisplayIndex(od, true); } catch (e2) {}
              }
            }
            if (Number.isFinite(record.originalZOrder)) sgSetZ(slot, record.originalZOrder, record.armature);
            if (typeof record.originalUpdate === 'function') record.originalUpdate.call(slot);
            else slot._textureData = record.originalTextureData;
            slot._pivotX = record.originalPivotX;
            slot._pivotY = record.originalPivotY;
            slot._transformDirty = true;
            slot._worldMatrixDirty = true;
            if (slot._updateFrame) slot._updateFrame();
            if (slot._updateTransform) slot._updateTransform();
          } catch (e) {
            try {
              slot._textureData = record.originalTextureData;
              if (slot._updateFrame) slot._updateFrame();
            } catch (e2) {}
          }
        }
        try { if (state.display && state.display.markForUpdateRenderData) state.display.markForUpdateRenderData(); } catch (e) {}
      } catch (e) {}
    };
    const SG_DATA_KEYS = ['ShootInterval', 'ShootIntervalAdditional', 'PeaType', 'PeaTypePlantfood', 'PlantfoodPeaCount', 'ChanceToPlantfood', 'Toughness'];
    const sgCaptureSnapshot = (plant) => ({
      data: plant ? plant._objdataOwn : null,
      values: Object.fromEntries(SG_DATA_KEYS.map((k) => [
        k,
        { hadOwn: Boolean(plant && plant._objdataOwn && Object.prototype.hasOwnProperty.call(plant._objdataOwn, k)), value: plant && plant._objdataOwn ? plant._objdataOwn[k] : undefined },
      ])),
      hadFusion: Boolean(plant && Object.prototype.hasOwnProperty.call(plant, '__gpnFusion')),
      fusionValue: plant ? plant.__gpnFusion : undefined,
      hadFlag: Boolean(plant && Object.prototype.hasOwnProperty.call(plant, SG_FLAG)),
    });
    const sgRestoreSnapshot = (plant, snap) => {
      try {
        if (!plant || !snap) return;
        if (snap.data) {
          for (const [k, o] of Object.entries(snap.values)) {
            if (o.hadOwn) snap.data[k] = o.value;
            else delete snap.data[k];
          }
        }
        if (snap.hadFusion) plant.__gpnFusion = snap.fusionValue;
        else delete plant.__gpnFusion;
        if (!snap.hadFlag) delete plant[SG_FLAG];
      } catch (e) {}
    };
    const sgConfigureBoss = (plant, carried) => {
      plant[SG_FLAG] = true;
      plant.__gpnFusion = { src: SPLIT_ID, peaType: null, split: true }; 
      const snd = carried.soundRes;
      if (snd) plant[SG_SOUND] = snd;
      sgApplyHealthRatio(plant, carried.healthRatio);
    };
    const sgBossCreate = (host, splitPlant) => {
      try {
        if (!host || !splitPlant || splitPlant[SG_PENDING]) return;
        if (splitPlant[SG_FLAG] === true) return; 
        if (!splitPlant._objdataOwn) return;
        splitPlant[SG_PENDING] = true;
        const carried = {
          healthRatio: sgHealthRatio(host),
          soundRes: sgPickSound(host),
        };
        try {
          const snapshot = sgCaptureSnapshot(splitPlant);
          sgConfigureBoss(splitPlant, carried);
          sgSnapshots.set(splitPlant, snapshot);
        } catch (e) {
          delete splitPlant[SG_PENDING];
          return;
        }
        sgEnsureTexture().then((tex) => {
          try {
            if (sgAlive(splitPlant) && splitPlant[SG_FLAG] === true) {
              const st = sgInstallSkin(splitPlant, tex);
              if (st) sgStates.set(splitPlant, st);
              if (log) log.info('PEP [SplitGatling] boss skin applied');
            }
          } catch (e) {}
        }).catch((e) => {
          if (log) log.warn('PEP [SplitGatling] boss skin fail ' + (e && e.message ? e.message : e));
        });
        sgRemoveQuietly(host);
        if (log) log.info('PEP [SplitGatling] created: SplitPea + MegaGatling -> Split Gatling (hp=' + carried.healthRatio.toFixed(2) + ')');
      } finally {
        delete splitPlant[SG_PENDING];
      }
    };
    const sgSelfX = (self) => { try { const n = self.node && self.node.worldPosition; return n ? Number(n.x) : NaN; } catch (e) { return NaN; } };
    const sgHasFrontTarget = (self) => {
      try {
        if (!self.inLane || !self.node) return false;
        const x = sgSelfX(self);
        if (!Number.isFinite(x)) return false;
        const pool = self.inLane.zombiePool();
        if (!pool || !pool.length) return false;
        for (let i = 0; i < pool.length; i++) {
          const z = pool[i];
          if (!z || z.dead || !z.node || !z.node.worldPosition) continue;
          if (Number(z.node.worldPosition.x) > x) return true;
        }
      } catch (e) {}
      return false;
    };
    const sgHasBackTarget = (self) => {
      try {
        if (!self.inLane || !self.node) return false;
        const x = sgSelfX(self);
        if (!Number.isFinite(x)) return false;
        const pool = self.inLane.zombiePool();
        if (!pool || !pool.length) return false;
        for (let i = 0; i < pool.length; i++) {
          const z = pool[i];
          if (!z || z.dead || !z.node || !z.node.worldPosition) continue;
          if (Number(z.node.worldPosition.x) < x) return true;
        }
      } catch (e) {}
      return false;
    };
    const prevSPAL = spProto.specialPeashooterAnimationListener;
    const newSPAL = function (evt) {
      try {
        if (this[SG_FLAG] !== true) return prevSPAL.apply(this, arguments);
        const name = evt && evt.name;
        if (name !== 'ShootR' && name !== 'ShootL') return prevSPAL.apply(this, arguments);
        if (this.fooding === true) return; 
        const now = Date.now();
        let plan = this.__gpnSplitPlan;
        if (!plan || now - plan.t > SG_CYCLE_MS) {
          const frontOn = sgHasFrontTarget(this);
          const backOn = sgHasBackTarget(this);
          let fc = 0, bc = 0;
          if (frontOn && backOn) { fc = SG_SHOT_BOTH_F; bc = SG_SHOT_BOTH_B; }
          else if (frontOn) { fc = SG_SHOT_FRONT_ONLY; }
          else if (backOn) { bc = SG_SHOT_BACK_ONLY; }
          const attr = sgIsFullLevel(this) || (MEGA_ATTR_CHANCE > 0 && Math.random() < MEGA_ATTR_CHANCE) ? sgPickAttr() : null;
          let backType = 'pea';
          if (sgIsFullLevel(this)) {
            backType = Math.random() < SG_BACK_ICE_ICICLE_SHARE ? SG_BACK_ICICLE : SG_BACK_ICE_PEA;
          } else if (SG_BACK_ICE_CHANCE > 0 && Math.random() < SG_BACK_ICE_CHANCE) {
            backType = Math.random() < SG_BACK_ICE_ICICLE_SHARE ? SG_BACK_ICICLE : SG_BACK_ICE_PEA;
          }
          plan = { t: now, fc, bc, attr, backType, frontDone: false, backDone: false };
          this.__gpnSplitPlan = plan;
        }
        const self = this;
        const isFront = name === 'ShootR';
        const count = isFront ? plan.fc : plan.bc;
        if (!(count > 0)) return; 
        if (isFront) { if (plan.frontDone) return; plan.frontDone = true; }
        else { if (plan.backDone) return; plan.backDone = true; }
        const fireOne = () => {
          try {
            if (self.dead || self[SG_FLAG] !== true || self.fooding === true) return;
            if (isFront) {
              self._shoot(false, false, plan.attr || 'pea');
            } else {
              self._shootBack(false, false, plan.backType || 'pea');
            }
          } catch (e) {}
        };
        fireOne(); 
        for (let shot = 1; shot < count; shot++) {
          const fireExtra = () => { fireOne(); };
          if (typeof self.scheduleOnce === 'function') self.scheduleOnce(fireExtra, shot * (SG_BURST_MS / 1000));
          else fireOne();
        }
        return;
      } catch (e) {
        return prevSPAL ? prevSPAL.apply(this, arguments) : undefined;
      }
    };
    const SG_PF_SPEED = 8; 
    const sgPlantfoodBursts = new WeakMap();
    const sgCancelPlantfood = (plant) => {
      const st = sgPlantfoodBursts.get(plant);
      if (!st) return;
      sgPlantfoodBursts.delete(plant);
      st.active = false;
      try { if (st.scheduledCallback) plant.unschedule?.(st.scheduledCallback); } catch (e) {}
      try { plant.shooting = false; } catch (e) {}
      try { plant.fooding = false; } catch (e) {}
      try { plant.shootCD = 0; } catch (e) {}
    };
    const sgCanContinuePf = (plant, st) => Boolean(st && st.active === true && sgPlantfoodBursts.get(plant) === st && plant[SG_FLAG] === true && plant.fooding === true && sgAlive(plant));
    const sgFirePfShot = (plant, st, isFront) => {
      if (!sgCanContinuePf(plant, st)) return false;
      try {
        const ccU2 = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
        const Vec2U2 = ccU2 && ccU2.Vec2;
        if (typeof Vec2U2 !== 'function' || typeof plant._shoot !== 'function') return false;
        let rel = 0;
        if (isFront) {
          rel = MEGA_ULT_SPREAD_ANGLES[(st.frontFired % MEGA_ULT_SPREAD_ANGLES.length)] || 0; 
        } else {
          rel = ((Math.random() * 2 - 1) * (SG_BACK_ARC_DEG / 2) * Math.PI) / 180; 
        }
        const dir = new Vec2U2(Math.cos(rel), Math.sin(rel));
        const isElec = !isFront && Math.random() < SG_ULT_BACK_ELEC_SHARE;
        const type = isFront ? sgPickAttr() : (isElec ? 'electricpea' : SG_BACK_ICICLE);
        const flip = (pea) => {
          try {
            if (!pea) return;
            if (!isFront) {
              if (Number.isFinite(pea.linearVelocity && pea.linearVelocity.x)) pea.linearVelocity.x *= -1; 
              if (Number.isFinite(pea.worldPositionX)) pea.worldPositionX -= 50;
              if (isElec && SG_ELEC_SCALE > 0 && SG_ELEC_SCALE !== 1) {
                const cur = typeof pea.scale === 'number' ? Math.abs(pea.scale) : 1;
                pea.scale = Math.max(0.1, cur) * SG_ELEC_SCALE;
              }
            }
          } catch (e) {}
        };
        const r = plant._shoot(true, false, type, SG_PF_SPEED, dir, plant.peaSpawnpoint);
        if (r && typeof r.then === 'function') { if (!isFront) r.then(flip, () => {}); }
        else if (!isFront) flip(r);
        return true;
      } catch (e) { return false; }
    };
    const sgFinishPf = (plant, st) => {
      if (sgPlantfoodBursts.get(plant) !== st) return;
      sgPlantfoodBursts.delete(plant);
      st.active = false;
      st.scheduledCallback = null;
      if (plant[SG_FLAG] === true && plant.fooding === true && sgAlive(plant)) {
        try { plant.foodEnd(); } catch (e) {}
      }
      try { plant.shooting = false; } catch (e) {}
    };
    const sgStartPlantfoodBurst = (plant) => {
      sgCancelPlantfood(plant);
      const frontCount = SG_ULT_FRONT;
      const backCount = SG_ULT_BACK;
      if (frontCount + backCount <= 0) { try { plant.foodEnd(); } catch (e) {} return false; }
      const st = { active: true, frontCount, backCount, frontFired: 0, backFired: 0, fired: 0, totalCount: frontCount + backCount, scheduledCallback: null };
      sgPlantfoodBursts.set(plant, st);
      try { plant.fooding = true; } catch (e) {}
      try { plant.shooting = true; } catch (e) {}
      const stepMs = Math.max(10, Math.floor(SG_ULT_MS / Math.max(1, Math.ceil(st.totalCount / 2))));
      const timer = setInterval(() => {
        try {
          if (!sgCanContinuePf(plant, st)) { clearInterval(timer); activeTimers.delete(timer); sgFinishPf(plant, st); return; }
          if (st.fired >= st.totalCount) { clearInterval(timer); activeTimers.delete(timer); sgFinishPf(plant, st); return; }
          let did = 0;
          if (st.frontFired < frontCount && sgFirePfShot(plant, st, true)) { st.frontFired++; st.fired++; did++; }
          if (st.backFired < backCount && sgFirePfShot(plant, st, false)) { st.backFired++; st.fired++; did++; }
          if (did === 0) { clearInterval(timer); activeTimers.delete(timer); sgFinishPf(plant, st); }
        } catch (e) {}
      }, stepMs);
      activeTimers.add(timer);
      if (log) log.info('PEP [SplitGatling] plantfood burst started: front=' + frontCount + ' back=' + backCount);
      return true;
    };
    const prevSPF2 = spProto.specialPlantFood;
    const newSPF2 = function (...args) {
      if (this[SG_FLAG] !== true) return prevSPF2.apply(this, args);
      const self = this;
      try {
        sgCancelPlantfood(self);
        const result = prevSPF2.apply(this, args);
        try {
          if (typeof self.scheduleOnce === 'function') {
            self.scheduleOnce(() => {
              try {
                if (self.dead || self[SG_FLAG] !== true) return;
                if (self.fooding === true && !sgPlantfoodBursts.has(self)) sgStartPlantfoodBurst(self);
              } catch (e) {}
            }, 0.45);
          }
        } catch (e) {}
        return result;
      } catch (e) {
        return prevSPF2.apply(this, args);
      }
    };
    const prevSFS = typeof spProto.foodShooting === 'function' ? spProto.foodShooting : null;
    const newSFS = function (...args) {
      if (this[SG_FLAG] !== true) return prevSFS ? prevSFS.apply(this, args) : undefined;
      return sgStartPlantfoodBurst(this);
    };
    const restoreFoodShooting = () => {
      try {
        if (prevSFS) { if (spProto.foodShooting === newSFS) spProto.foodShooting = prevSFS; }
        else { if (spProto.foodShooting === newSFS) delete spProto.foodShooting; }
      } catch (e) {}
    };
    if (typeof spProto.foodShooting === 'function' || !('foodShooting' in spProto)) {
      spProto.foodShooting = newSFS;
    }
    spProto.specialPeashooterAnimationListener = newSPAL;
    spProto.specialPlantFood = newSPF2;
    cleanups.push(() => {
      try {
        for (const st of sgStates.values()) { try { sgRestoreSkin(st); } catch (e) {} }
        sgStates.clear();
        for (const pl of sgSnapshots.keys()) { try { sgRestoreSnapshot(pl, sgSnapshots.get(pl)); } catch (e) {} }
        sgSnapshots.clear();
        if (spProto.specialPeashooterAnimationListener === newSPAL) spProto.specialPeashooterAnimationListener = prevSPAL;
        if (spProto.specialPlantFood === newSPF2) spProto.specialPlantFood = prevSPF2;
        restoreFoodShooting();
      } catch (e) {}
    });
    try {
      const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
      if (PlantF && PlantF.prototype && !PlantF.prototype.__gpnSGCOD) {
        PlantF.prototype.__gpnSGCOD = true;
        const prevCOD = PlantF.prototype.characterOnDisable;
        PlantF.prototype.characterOnDisable = function (...cargs) {
          try {
            if (this[SG_FLAG] === true || sgSnapshots.has(this)) {
              const st = sgStates.get(this);
              if (st) { try { sgRestoreSkin(st); } catch (e) {} sgStates.delete(this); }
              try { sgRestoreSnapshot(this, sgSnapshots.get(this)); } catch (e) {}
              sgSnapshots.delete(this);
              try { this.__gpnSplitPlan = null; } catch (e) {}
            }
          } catch (e) {}
          return prevCOD.apply(this, cargs);
        };
        cleanups.push(() => {
          try { if (PlantF.prototype.characterOnDisable && PlantF.prototype.__gpnSGCOD) PlantF.prototype.characterOnDisable = prevCOD; } catch (e) {}
          try { delete PlantF.prototype.__gpnSGCOD; } catch (e) {}
        });
      }
    } catch (e) {}
    try {
      const LnC = engine.getClassByName ? engine.getClassByName('LnC') : null;
      if (LnC && LnC.prototype && typeof LnC.prototype.putPlantAvailable === 'function' && !LnC.prototype.__gpnSGOverlap) {
        LnC.prototype.__gpnSGOverlap = true;
        const orig = LnC.prototype.putPlantAvailable;
        LnC.prototype.putPlantAvailable = function (t, e, n, i, o, a) {
          try {
            const id = Number(e);
            if (id === 9 || id === SPLIT_ID) {
              const arr = this.plantInSquare;
              if (Array.isArray(arr) && arr.length > 0) {
                const hasSG = arr.some((pl) => {
                  try { return !!(pl && !pl.dead && pl[SG_FLAG] === true); } catch (e2) { return false; }
                });
                if (hasSG) {
                  if (log) log.info('PEP [SplitGatling] overlap deny: split gatling on square, plant=' + id);
                  return orig.apply(this, arguments);
                }
                const need = id === 9 ? SPLIT_ID : 9;
                const has = arr.some((pl) => {
                  try {
                    if (!pl || pl.dead) return false;
                    const pid = Number(pl.ID != null ? pl.ID : pl._plantID);
                    if (pid === need) return true;
                    if (need === SPLIT_ID && (pid === SPLIT_ID || pl.constructor === SP2)) return true;
                    if (need === 9 && (pid === 9 || pl.constructor === MG6)) return true;
                    return false;
                  } catch (e2) { return false; }
                });
                if (has) return true;
              }
            }
          } catch (e) {}
          return orig.apply(this, arguments);
        };
        cleanups.push(() => {
          try { if (LnC.prototype.putPlantAvailable && LnC.prototype.__gpnSGOverlap) LnC.prototype.putPlantAvailable = orig; } catch (e) {}
          try { delete LnC.prototype.__gpnSGOverlap; } catch (e) {}
        });
        if (log) log.info('PEP [SplitGatling] overlap ON (MG + SplitPea)');
      }
    } catch (e) {}
    let sgScanTimer = null;
    try {
      sgScanTimer = setInterval(() => {
        try {
          const cc = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
          const PlantF = engine.getClassByName ? engine.getClassByName('Plant') : null;
          if (!cc || !PlantF) return;
          const scene = cc.director.getScene();
          if (!scene) return;
          const list = scene.getComponentsInChildren(PlantF);
          if (!Array.isArray(list)) return;
          for (const p of list) {
            try {
              if (!p.node || !p.node.isValid || p.dead) continue;
              if (p[SG_PENDING]) continue;
              const lc = p.plantInLnC || p.inLnC;
              if (!lc || !lc.plantInSquare || !lc.plantInSquare.length) continue;
              const isMG = sgIsMG(p);
              const isSP = sgIsSplit(p);
              if (!isMG && !isSP) continue;
              for (const other of lc.plantInSquare) {
                if (!other || other === p || !other.node || !other.node.isValid || other.dead) continue;
                if (isMG && sgIsSplit(other)) { sgBossCreate(p, other); break; }
                if (isSP && sgIsMG(other)) { sgBossCreate(other, p); break; }
              }
            } catch (e) {}
          }
        } catch (e) {}
      }, 200);
      cleanups.push(() => { try { clearInterval(sgScanTimer); } catch (e) {} });
    } catch (e) {}
    if (log) log.info('PEP [SplitGatling] active: MG + SplitPea -> Split Gatling (front 4/6, back 5/7, ult front 150 @mega-angle + back 150 @160deg)');
  })();
  (function installShadowPeashooter() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('ShadowPeashooterPlant')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: ShadowPeashooterPlant class not found, shadow peashooter features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shoot !== 'function' ||
      typeof proto.startShooting !== 'function' ||
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function' ||
      typeof proto.animationListener !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on ShadowPeashooterPlant, shadow peashooter features skipped');
      return;
    }
    const isSelf = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const prevPF = proto.specialPlantFood;
    const newPF = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          this.__gpnShadowUlted = true;
          this.__gpnShadowUltCount = (Number(this.__gpnShadowUltCount) || 0) + 1;
          this.__gpnShadowCycleBurst = false;
          this.__gpnShadowCycleFired = 0;
          if (SHADOW_ULT_RAIN_CHANCE > 0 && Math.random() < SHADOW_ULT_RAIN_CHANCE) {
            this.__gpnShadowUltMode = 'rain';
            this.__gpnRainSfxStop = false;
            this.fooding = true;
            const ultCount = Number(this.__gpnShadowUltCount) || 0;
            const stage3 = ultCount >= 3;
            let count = SHADOW_ULT_RAIN_COUNT;
            let rainTier = 0;
            try {
              if (this.ShadowPowered === true && typeof this.get_moonflower_count === 'function') {
                if (stage3) count = SHADOW_ULT_RAIN_COUNT_3;
                rainTier = this.get_moonflower_count() >= 2 ? 2 : 1;
              }
            } catch (e) {}
            this.__gpnShadowRainTier = rainTier;
            this.__gpnShadowRainStage3 = stage3;
            startRainSfx(this);
            try { this.anmControl.playAnimation('FoodStart', 1, SHADOW_ULT_RAIN_PREPARE_SPEED); } catch (e) {}
            try { this.soundRes.playFood(); } catch (e) {}
            const self = this;
            if (typeof this.scheduleOnce === 'function') {
              this.scheduleOnce(() => {
                try {
                  if (self.dead || self.__gpnShadowUltMode !== 'rain') return;
                  if (self.anmControl) self.anmControl.playAnimation('Food', 1 / 0);
                  const total = Math.max(1, Math.floor(Number(count) || 1));
                  const step = Math.max(16, Math.floor(2000 / total));
                  let fired = 0;
                  const timer = setInterval(() => {
                    try {
                      if (self.dead || self.__gpnShadowUltMode !== 'rain') {
                        clearInterval(timer); activeTimers.delete(timer);
                        try { self.finishShadowRain(); } catch (e) {}
                        return;
                      }
                    } catch (e) {}
                    if (fired >= total) {
                      clearInterval(timer); activeTimers.delete(timer);
                      try { self.finishShadowRain(); } catch (e) {}
                      return;
                    }
                    try { self._shoot('pea_shadow'); } catch (e) {}
                    fired++;
                  }, step);
                  activeTimers.add(timer);
                } catch (err) {}
              }, SHADOW_ULT_RAIN_PREPARE_SECONDS);
            } else {
              const total = Math.max(1, Math.floor(Number(count) || 1));
              for (let i = 0; i < total; i++) { try { this._shoot('pea_shadow'); } catch (e) {} }
              try { this.finishShadowRain(); } catch (e) {}
            }
            return;
          }
        }
      } catch (e) {}
      return prevPF.apply(this, args); 
    };
    const finishRain = function () {
      try {
        if (this.__gpnShadowUltMode === 'rain') {
          this.__gpnShadowUltMode = null;
          this.__gpnShadowRainTier = 0;
          this.__gpnShadowRainStage3 = false;
          stopRainSfx(this);
          try {
            if (this.anmControl && typeof this.anmControl.playIdle === 'function') this.anmControl.playIdle();
          } catch (e) {}
        }
      } catch (e) {}
      try { if (typeof this.foodEnd === 'function') this.foodEnd(); } catch (e) {}
    };
    proto.finishShadowRain = finishRain;
    const prevOE = proto.specialPlantOnEnable;
    const newOE = function (...args) {
      try {
        this.__gpnShadowUlted = false;
        this.__gpnShadowUltCount = 0;
        this.__gpnShadowCycleBurst = false;
        this.__gpnShadowCycleFired = 0;
        this.__gpnShadowUltMode = null;
        this.__gpnShadowRainTier = 0;
        this.__gpnShadowRainStage3 = false;
        this.__gpnShadowSpreadCursor = 0;
        stopRainSfx(this);
      } catch (e) {}
      return prevOE.apply(this, args);
    };
    const prevAL = proto.animationListener;
    const newAL = function (evt) {
      try {
        if (this.__gpnShadowUltMode === 'rain') return;
      } catch (e) {}
      return prevAL.apply(this, arguments);
    };
    const prevStart = proto.startShooting;
    const newStart = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          if (this.__gpnShadowUlted === true && this.ShadowPowered !== true && SHADOW_BURST_CHANCE > 0) {
            this.__gpnShadowCycleBurst = Math.random() < SHADOW_BURST_CHANCE;
          } else {
            this.__gpnShadowCycleBurst = false;
          }
          this.__gpnShadowCycleFired = 0;
        }
      } catch (e) {}
      return prevStart.apply(this, args);
    };
    const prevShoot = proto._shoot;
    const newShoot = function (...args) {
      const rainMode = this.__gpnShadowUltMode === 'rain';
      const powered = this.ShadowPowered === true;
      let perfumeSecs = 0;
      let angle = null;
      try {
        if (rainMode) {
          if (powered) {
            if (this.__gpnShadowRainStage3 === true && SHADOW_ULT_SPREAD_ANGLES && SHADOW_ULT_SPREAD_ANGLES.length) {
              angle = SHADOW_ULT_SPREAD_ANGLES[(this.__gpnShadowSpreadCursor || 0) % SHADOW_ULT_SPREAD_ANGLES.length];
              this.__gpnShadowSpreadCursor = (this.__gpnShadowSpreadCursor || 0) + 1;
            }
            perfumeSecs = SHADOW_ULT_RAIN_PERFUME_SECONDS;
          }
        } else if (!this.__gpnFusion && !powered && this.__gpnShadowUlted === true && this.__gpnShadowCycleBurst === true) {
          perfumeSecs = SHADOW_BURST_PERFUME_SECONDS;
          if (this.__gpnShadowCycleFired === 0) {
            this.__gpnShadowCycleFired = 1;
            const self = this;
            const remain = Math.max(0, COUNT - 1);
            let n = 0;
            const timer = setInterval(() => {
              try {
                if (self.dead) { clearInterval(timer); activeTimers.delete(timer); return; }
              } catch (e) {}
              if (n >= remain) { clearInterval(timer); activeTimers.delete(timer); return; }
              try { self._shoot(); } catch (e) {}
              n++;
            }, INTERVAL_MS);
            activeTimers.add(timer);
          }
        }
      } catch (e) {}
      const result = prevShoot.apply(this, args);
      try {
        const apply = (p) => {
          try {
            if (!p) return;
            if (perfumeSecs > 0) p.__gpnPerfumeSeconds = perfumeSecs;
            if (rainMode) {
              const tier = this.__gpnShadowRainTier || 0;
              if (tier > 0 && typeof p.setDamage === 'function') {
                try {
                  const dmg = tier >= 2 ? SHADOW_ULT_RAIN_DMG_SHADOW2 : SHADOW_ULT_RAIN_DMG_SHADOW1;
                  p.setDamage(dmg);
                } catch (e) {}
              }
              const scatter = powered && this.__gpnShadowRainStage3 === true;
              const jitterBase = scatter ? SHADOW_ULT_RAIN_JITTER_SHADOW : SHADOW_ULT_RAIN_JITTER_NORMAL;
              const jitter = jitterBase > 0 ? (Math.random() - 0.5) * jitterBase : 0;
              const finalAngle = scatter ? ((angle == null ? 0 : angle) + jitter) : jitter;
              if (p.linearVelocity && typeof p.linearVelocity.x === 'number') {
                p.linearVelocity.y = p.linearVelocity.x * finalAngle;
              }
              if (SHADOW_ULT_RAIN_PEA_SCALE > 1) {
                try {
                  const cur = typeof p.scale === 'number' ? Math.abs(p.scale) : 1;
                  p.scale = cur > 0 ? cur * SHADOW_ULT_RAIN_PEA_SCALE : SHADOW_ULT_RAIN_PEA_SCALE;
                } catch (e) {}
              }
            } else if (perfumeSecs > 0 && angle != null && p.linearVelocity && typeof p.linearVelocity.x === 'number') {
              p.linearVelocity.y = p.linearVelocity.x * angle;
            }
          } catch (e) {}
        };
        if (result && typeof result.then === 'function') {
          result.then(apply, () => {});
        } else {
          apply(result);
        }
      } catch (e) {}
      return result;
    };
    proto.specialPlantFood = newPF;
    proto.specialPlantOnEnable = newOE;
    proto.animationListener = newAL;
    proto.startShooting = newStart;
    proto._shoot = newShoot;
    let commonShotCls = null;
    try {
      commonShotCls = engine.getClassByName('commonShot') || null;
    } catch (e) { commonShotCls = null; }
    let prevDeal = null;
    let newDeal = null;
    let prevCE = null;
    let newCE = null;
    if (commonShotCls && commonShotCls.prototype) {
      if (typeof commonShotCls.prototype.dealDamageToZombie === 'function') {
        prevDeal = commonShotCls.prototype.dealDamageToZombie;
        newDeal = function (zombie, ...rest) {
          const res = prevDeal.apply(this, arguments);
          try {
            const secs = this.__gpnPerfumeSeconds;
            if (secs > 0 && zombie && typeof zombie.setPerfume === 'function') {
              zombie.setPerfume(secs);
            }
          } catch (e) {}
          return res;
        };
        commonShotCls.prototype.dealDamageToZombie = newDeal;
      }
      if (typeof commonShotCls.prototype.characterOnEnable === 'function') {
        prevCE = commonShotCls.prototype.characterOnEnable;
        newCE = function (...args) {
          try {
            this.__gpnPerfumeSeconds = 0;
          } catch (e) {}
          return prevCE.apply(this, args);
        };
        commonShotCls.prototype.characterOnEnable = newCE;
      }
    }
    cleanups.unshift(() => {
      try {
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
        if (proto.specialPlantOnEnable === newOE) proto.specialPlantOnEnable = prevOE;
        if (proto.animationListener === newAL) proto.animationListener = prevAL;
        if (proto.startShooting === newStart) proto.startShooting = prevStart;
        if (proto._shoot === newShoot) proto._shoot = prevShoot;
        if (proto.finishShadowRain === finishRain) delete proto.finishShadowRain;
        if (commonShotCls && commonShotCls.prototype) {
          if (newDeal && commonShotCls.prototype.dealDamageToZombie === newDeal) {
            commonShotCls.prototype.dealDamageToZombie = prevDeal;
          }
          if (newCE && commonShotCls.prototype.characterOnEnable === newCE) {
            commonShotCls.prototype.characterOnEnable = prevCE;
          }
        }
      } catch (e) {}
    });
    if (log) log.info('PEP [ShadowPeashooter] active: ult rain chance=' + SHADOW_ULT_RAIN_CHANCE + ' (normal ' + SHADOW_ULT_RAIN_COUNT + ' straight+jitter / shadow 60 straight -> ' + SHADOW_ULT_RAIN_COUNT_3 + ' spread from 3rd ult, perfume, dmg ' + SHADOW_ULT_RAIN_DMG_SHADOW1 + '/' + SHADOW_ULT_RAIN_DMG_SHADOW2 + '), burst chance=' + SHADOW_BURST_CHANCE + ' count=' + COUNT + ' perfume=' + SHADOW_BURST_PERFUME_SECONDS + 's, pea scale=' + SHADOW_ULT_RAIN_PEA_SCALE);
  })();
  (function installSeashooterMemory() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('SeashooterPlant')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: SeashooterPlant class not found, seashooter features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shoot !== 'function' ||
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function' ||
      typeof proto.specialOnTileTypeChange !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on SeashooterPlant, seashooter features skipped');
      return;
    }
    const isSelf = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const prevPF = proto.specialPlantFood;
    const newPF = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          const count = Number(this.__gpnSeaUltCount) || 0;
          if (this.isSwimming === true || count >= 1) {
            this.__gpnSeaUltCount = count + 1;
          }
          if ((Number(this.__gpnSeaUltCount) || 0) >= SEA_ULT_LOCK_SWIM && this.isSwimming !== true) {
            this.isSwimming = true;
          }
        }
      } catch (e) {}
      return prevPF.apply(this, args);
    };
    const prevOE = proto.specialPlantOnEnable;
    const newOE = function (...args) {
      try {
        this.__gpnSeaUltCount = 0;
      } catch (e) {}
      return prevOE.apply(this, args);
    };
    const prevOTT = proto.specialOnTileTypeChange;
    const newOTT = function (...args) {
      try {
        if (isSelf(this) && !this.__gpnFusion && (Number(this.__gpnSeaUltCount) || 0) >= SEA_ULT_LOCK_SWIM) {
          if (this.isSwimming !== true) this.isSwimming = true;
          return;
        }
      } catch (e) {}
      return prevOTT.apply(this, args);
    };
    const prevShoot = proto._shoot;
    const newShoot = function (...args) {
      let fireArgs = args;
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          const unlocked = (Number(this.__gpnSeaUltCount) || 0) >= SEA_ULT_LOCK_SEA_PEA;
          if (this.isSwimming === true || unlocked) {
            fireArgs = args.slice();
            fireArgs[2] = 'sea_pea';
          }
        }
      } catch (e) {}
      return prevShoot.apply(this, fireArgs);
    };
    proto.specialPlantFood = newPF;
    proto.specialPlantOnEnable = newOE;
    proto.specialOnTileTypeChange = newOTT;
    proto._shoot = newShoot;
    cleanups.push(() => {
      try {
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
        if (proto.specialPlantOnEnable === newOE) proto.specialPlantOnEnable = prevOE;
        if (proto.specialOnTileTypeChange === newOTT) proto.specialOnTileTypeChange = prevOTT;
        if (proto._shoot === newShoot) proto._shoot = prevShoot;
      } catch (e) {}
    });
    if (log) log.info('PEP [Seashooter] active: evolve = ult while swimming (land ults never count), sea-pea lock after ' + SEA_ULT_LOCK_SEA_PEA + ' swim ult(s), swim lock after ' + SEA_ULT_LOCK_SWIM + ' ult(s)');
  })();
  (function installSkyshooter() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('SkyshooterPlant')
      : null;
    if (!Cls || !Cls.prototype) {
      if (log) log.warn('PEP: SkyshooterPlant class not found, skyshooter features skipped');
      return;
    }
    const proto = Cls.prototype;
    if (
      typeof proto._shoot !== 'function' ||
      typeof proto.startShooting !== 'function' ||
      typeof proto.specialPlantFood !== 'function' ||
      typeof proto.specialPlantOnEnable !== 'function'
    ) {
      if (log) log.warn('PEP: required methods missing on SkyshooterPlant, skyshooter features skipped');
      return;
    }
    const isSelf = (self) => {
      try { return Object.getPrototypeOf(self) === proto; } catch (e) { return false; }
    };
    const prevPF = proto.specialPlantFood;
    const newPF = function (...args) {
      let touched = false;
      let saved;
      try {
        if (isSelf(this) && !this.__gpnFusion) {
          this.__gpnSkyUlted = true;
          this.__gpnSkyCycleBurst = false;
          this.__gpnSkyCycleFired = 0;
          this.__gpnSkyUltCount = (Number(this.__gpnSkyUltCount) || 0) + 1;
          if ((Number(this.__gpnSkyUltCount) || 0) >= 3 && SKY_ULT_COUNT_3 > 0 && this._objdataOwn) {
            saved = this._objdataOwn.PlantfoodPeaCount;
            this._objdataOwn.PlantfoodPeaCount = SKY_ULT_COUNT_3;
            touched = true;
          }
        }
      } catch (e) {}
      let res;
      try {
        res = prevPF.apply(this, args);
      } finally {
        if (touched) {
          try { this._objdataOwn.PlantfoodPeaCount = saved; } catch (e) {}
        }
      }
      return res;
    };
    const prevOE = proto.specialPlantOnEnable;
    const newOE = function (...args) {
      try {
        this.__gpnSkyUlted = false;
        this.__gpnSkyCycleBurst = false;
        this.__gpnSkyCycleFired = 0;
        this.__gpnSkyUltCount = 0;
        this.__gpnSkySpreadCursor = 0;
      } catch (e) {}
      return prevOE.apply(this, args);
    };
    const prevStart = proto.startShooting;
    const newStart = function (...args) {
      try {
        if (isSelf(this)) {
          if (this.__gpnSkyUlted === true && SKY_BURST_CHANCE > 0) {
            this.__gpnSkyCycleBurst = Math.random() < SKY_BURST_CHANCE;
          } else {
            this.__gpnSkyCycleBurst = false;
          }
          this.__gpnSkyCycleFired = 0;
        }
      } catch (e) {}
      return prevStart.apply(this, args);
    };
    const prevShoot = proto._shoot;
    const newShoot = function (...args) {
      const isFoodShot = args[0] === true;
      let scatterAngle = null;
      try {
        if (
          isFoodShot && isSelf(this) && !this.__gpnFusion &&
          (Number(this.__gpnSkyUltCount) || 0) >= 3 &&
          MEGA_ULT_SPREAD_ANGLES && MEGA_ULT_SPREAD_ANGLES.length && SKY_ULT_SCATTER_SCALE > 0
        ) {
          scatterAngle = MEGA_ULT_SPREAD_ANGLES[(this.__gpnSkySpreadCursor || 0) % MEGA_ULT_SPREAD_ANGLES.length] * SKY_ULT_SCATTER_SCALE;
          this.__gpnSkySpreadCursor = (this.__gpnSkySpreadCursor || 0) + 1;
        }
      } catch (e) {}
      const result = prevShoot.apply(this, args);
      try {
        if (scatterAngle != null) {
          const scatter = (p) => {
            try {
              if (p && p.linearVelocity && typeof p.linearVelocity.x === 'number') {
                p.linearVelocity.y = p.linearVelocity.x * scatterAngle;
              }
            } catch (e) {}
          };
          if (result && typeof result.then === 'function') {
            result.then(scatter, () => {});
          } else {
            scatter(result);
          }
        }
      } catch (e) {}
      try {
        if (
          !isFoodShot && isSelf(this) && !this.__gpnFusion &&
          this.__gpnSkyUlted === true && this.__gpnSkyCycleBurst === true &&
          this.__gpnSkyCycleFired === 0
        ) {
          this.__gpnSkyCycleFired = 1;
          const self = this;
          const remain = Math.max(0, COUNT - 1);
          let n = 0;
          const timer = setInterval(() => {
            try {
              if (self.dead) { clearInterval(timer); activeTimers.delete(timer); return; }
            } catch (e) {}
            if (n >= remain) { clearInterval(timer); activeTimers.delete(timer); return; }
            try { self._shoot(); } catch (e) {}
            n++;
          }, INTERVAL_MS);
          activeTimers.add(timer);
        }
      } catch (e) {}
      return result;
    };
    proto.specialPlantFood = newPF;
    proto.specialPlantOnEnable = newOE;
    proto.startShooting = newStart;
    proto._shoot = newShoot;
    cleanups.push(() => {
      try {
        if (proto.specialPlantFood === newPF) proto.specialPlantFood = prevPF;
        if (proto.specialPlantOnEnable === newOE) proto.specialPlantOnEnable = prevOE;
        if (proto.startShooting === newStart) proto.startShooting = prevStart;
        if (proto._shoot === newShoot) proto._shoot = prevShoot;
      } catch (e) {}
    });
    if (log) log.info('PEP [Skyshooter] active: ult burst chance=' + SKY_BURST_CHANCE + ' count=' + COUNT + ' interval=' + INTERVAL_MS + 'ms, 3rd+ ult scatter scale=' + SKY_ULT_SCATTER_SCALE + ' count=' + SKY_ULT_COUNT_3);
  })();
  (function installFullLevelBadge() {
    const Cls = engine && typeof engine.getClassByName === 'function'
      ? engine.getClassByName('Plant')
      : null;
    if (!Cls || !Cls.prototype || typeof Cls.prototype.food !== 'function') {
      if (log) log.warn('PEP: Plant base class not found, full-level badge skipped');
      return;
    }
    const proto = Cls.prototype;
    let foodLightPrefab = null;
    let foodLightArmatureCls = null;
    try {
      const mPar = engine.getSystemModule('chunks:///_virtual/Particles.ts');
      const particle = mPar && mPar.particle;
      foodLightPrefab = (particle && typeof particle.foodLight === 'function') ? particle.foodLight() : null;
      const cc = getCc();
      foodLightArmatureCls = (cc && (cc.ArmatureDisplay || (cc.dragonBones && cc.dragonBones.ArmatureDisplay))) || null;
    } catch (e) { foodLightPrefab = null; foodLightArmatureCls = null; }
    const isPlantLike = (self) => {
      try { return !!self && typeof self.food === 'function' && !!self.node; } catch (e) { return false; }
    };
    const ensureBadge = (self) => {
      try {
        if (!self || self.dead || !self.node || !self.node.isValid) return;
        if (self.__gpnPepBadge && self.__gpnPepBadge.isValid) return;
        const cc = getCc();
        if (!cc || !cc.instantiate || !foodLightPrefab) return;
        const light = cc.instantiate(foodLightPrefab);
        if (!light) return;
        light.parent = self.node;
        try { light.setLayerWithAllChildren(self.node.layer); } catch (e) {}
        try { light.setPosition(0, 0, 0); } catch (e) {}
        if (FULL_LIGHT_SCALE > 0 && FULL_LIGHT_SCALE !== 1) {
          try { light.setScale(FULL_LIGHT_SCALE, FULL_LIGHT_SCALE, 1); } catch (e) {}
        }
        try {
          const ad = foodLightArmatureCls ? light.getComponent(foodLightArmatureCls) : null;
          if (ad && typeof ad.playAnimation === 'function') ad.playAnimation('Start', 1 / 0);
        } catch (e) {}
        self.__gpnPepBadge = light;
      } catch (e) {}
    };
    const removeBadge = (self) => {
      try {
        const icon = self && self.__gpnPepBadge;
        if (icon) self.__gpnPepBadge = null;
        if (icon && icon.isValid) { try { icon.destroy(); } catch (e) {} }
      } catch (e) {}
    };
    const prevFood = proto.food;
    const newFood = function (...args) {
      const result = prevFood.apply(this, args);
      try {
        if (result === true && isPlantLike(this) && !this.dead) {
          const n = (Number(this.__gpnPepUltCount) || 0) + 1;
          this.__gpnPepUltCount = Math.min(n, FULL_ULT_COUNT);
          if (this.__gpnPepUltCount >= FULL_ULT_COUNT) ensureBadge(this);
        }
      } catch (e) {}
      return result;
    };
    let charCls = null;
    try {
      charCls = engine.getClassByName('Character') || null;
    } catch (e) { charCls = null; }
    let prevCOD = null;
    let newCOD = null;
    if (charCls && charCls.prototype && typeof charCls.prototype.characterOnDisable === 'function') {
      prevCOD = charCls.prototype.characterOnDisable;
      newCOD = function (...args) {
        try {
          if (isPlantLike(this)) {
            removeBadge(this);
            this.__gpnPepUltCount = 0;
          }
        } catch (e) {}
        return prevCOD.apply(this, args);
      };
      charCls.prototype.characterOnDisable = newCOD;
    }
    proto.food = newFood;
    const isFull = (self) => {
      try { return isPlantLike(self) && (Number(self.__gpnPepUltCount) || 0) >= FULL_ULT_COUNT; } catch (e) { return false; }
    };
    let sunflowerProduce = null;
    try {
      const mSun = engine.getSystemModule('chunks:///_virtual/Sunflower.ts');
      sunflowerProduce = (mSun && mSun.sunflower && typeof mSun.sunflower.producePlantFood === 'function')
        ? mSun.sunflower.producePlantFood.bind(mSun.sunflower)
        : null;
    } catch (e) { sunflowerProduce = null; }
    let peaCls = null;
    try {
      peaCls = engine.getClassByName('PeashooterPlant') || null;
    } catch (e) { peaCls = null; }
    let prevShotInit = null;
    let newShotInit = null;
    if (peaCls && peaCls.prototype && typeof peaCls.prototype.shotInitialize === 'function') {
      prevShotInit = peaCls.prototype.shotInitialize;
      newShotInit = function (prj) {
        try {
          if (isFull(this) && prj) prj.__gpnPepShooter = this;
        } catch (e) {}
        return prevShotInit.apply(this, arguments);
      };
      peaCls.prototype.shotInitialize = newShotInit;
    }
    const lobberClassNames = ['CabbagePultPlant', 'MelonPultPlant', 'KernelPultPlant', 'WinterMelonPlant', 'SpringBeanPlant'];
    const lobberWraps = [];
    for (const lcn of lobberClassNames) {
      try {
        const lc = engine.getClassByName(lcn) || null;
        if (lc && lc.prototype && typeof lc.prototype.csFunc === 'function') {
          const prevCF = lc.prototype.csFunc;
          const newCF = function (prj, n) {
            try {
              if (isFull(this) && prj) prj.__gpnPepShooter = this;
            } catch (e) {}
            return prevCF.apply(this, arguments);
          };
          lc.prototype.csFunc = newCF;
          lobberWraps.push({ cls: lc, prev: prevCF, next: newCF });
        }
      } catch (e) {}
    }
    let shotCls = null;
    try { shotCls = engine.getClassByName('commonShot') || null; } catch (e) { shotCls = null; }
    let prevDD = null;
    let newDD = null;
    if (shotCls && shotCls.prototype && typeof shotCls.prototype.dealDamageToZombie === 'function') {
      prevDD = shotCls.prototype.dealDamageToZombie;
      newDD = function (zombie, ...rest) {
        const res = prevDD.apply(this, arguments);
        try {
          if (
            FULL_KILL_DROP_CHANCE > 0 && sunflowerProduce &&
            zombie && typeof zombie.isAlive === 'function' && zombie.isAlive() === false && 
            this.__gpnPepShooter && isFull(this.__gpnPepShooter)
          ) {
            if (Math.random() < FULL_KILL_DROP_CHANCE) {
              try { sunflowerProduce(this.__gpnPepShooter.worldPosition); } catch (e) {}
            }
          }
        } catch (e) {}
        return res;
      };
      shotCls.prototype.dealDamageToZombie = newDD;
    }
    cleanups.push(() => {
      try {
        if (proto.food === newFood) proto.food = prevFood;
        if (newCOD && charCls && charCls.prototype.characterOnDisable === newCOD) {
          charCls.prototype.characterOnDisable = prevCOD;
        }
        if (newShotInit && peaCls && peaCls.prototype.shotInitialize === newShotInit) {
          peaCls.prototype.shotInitialize = prevShotInit;
        }
        for (const w of lobberWraps) {
          try {
            if (w.cls && w.cls.prototype.csFunc === w.next) w.cls.prototype.csFunc = w.prev;
          } catch (e) {}
        }
        if (newDD && shotCls && shotCls.prototype.dealDamageToZombie === newDD) {
          shotCls.prototype.dealDamageToZombie = prevDD;
        }
      } catch (e) {}
    });
    if (log) log.info('PEP [FullLevelBadge] active: full-level at ' + FULL_ULT_COUNT + ' ults for ALL plants, permanent foodLight effect scale=' + FULL_LIGHT_SCALE + (foodLightPrefab ? '' : ' (WARN: foodLight prefab unavailable)') + ', kill-drop chance=' + FULL_KILL_DROP_CHANCE + (sunflowerProduce ? '' : ' (WARN: producePlantFood unavailable)') + (newShotInit ? '' : ' (WARN: Peashooter shotInitialize not found)'));
  })();
  return () => {
    for (const c of cleanups) {
      try { c(); } catch (e) {}
    }
  };
}
