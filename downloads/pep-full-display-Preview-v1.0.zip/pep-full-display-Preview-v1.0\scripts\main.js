export async function setup(ctx) {
  const log = ctx && ctx.log;
  const engine = ctx && ctx.unsafe && ctx.unsafe.engine;
  const cleanups = [];
  let SHOW_PLANT_HP = true;        
  let SHOW_ZOMBIE_HP = true;       
  let SHOW_TOMB_HP = true;         
  let LABEL_SIZE = 12;             
  let LABEL_OFFSET_Y = 44;         
  let ZOMBIE_OFFSET_DELTA = 20;    
  let ARMOR_LABEL_SIZE = 8;        
  let ARMOR_LABEL_OFFSET = 9;      
  const LABEL_COLOR_NORMAL = [255, 255, 255, 255];   
  const LABEL_COLOR_FULL = [255, 215, 0, 255];       
  const LABEL_COLOR_ARMOR = [245, 240, 220, 255];    
  const SETTINGS_SCHEMA = {
    title: '血量显示',
    description: '开关血量显示(字号/位置在代码顶部调,不在此开放)',
    fields: [
      { key: 'showPlantHp', type: 'toggle', default: true, label: '显示植物血量' },
      { key: 'showZombieHp', type: 'toggle', default: true, label: '显示僵尸血量' },
      { key: 'showTombHp', type: 'toggle', default: true, label: '显示地物血量' },
    ],
  };
  const applySettings = (values) => {
    try {
      if (!values || typeof values !== 'object') return;
      if (typeof values.showPlantHp === 'boolean') SHOW_PLANT_HP = values.showPlantHp;
      if (typeof values.showZombieHp === 'boolean') SHOW_ZOMBIE_HP = values.showZombieHp;
      if (typeof values.showTombHp === 'boolean') SHOW_TOMB_HP = values.showTombHp;
    } catch (e) {}
  };
  try {
    if (ctx && ctx.settings && typeof ctx.settings.defineSchema === 'function') {
      await ctx.settings.defineSchema(SETTINGS_SCHEMA);
      const initial = await ctx.settings.getAll();
      applySettings(initial);
      if (log) log.info('PEP-FullDisplay: settings panel registered');
    } else if (log) {
      log.warn('PEP-FullDisplay: ctx.settings unavailable, panel skipped (params stay at defaults)');
    }
  } catch (e) {
    if (log) log.warn('PEP-FullDisplay: settings register failed: ' + (e && e.message));
  }
  const settingsPollTimer = setInterval(async () => {
    try {
      if (ctx && ctx.settings && typeof ctx.settings.getAll === 'function') {
        applySettings(await ctx.settings.getAll());
      }
    } catch (e) {}
  }, 800);
  cleanups.push(() => { try { clearInterval(settingsPollTimer); } catch (e) {} });
  const getDirector = () => {
    try {
      const ccC = engine && typeof engine.getCc === 'function' ? engine.getCc() : null;
      return (ccC && ccC.director) || null;
    } catch (e) { return null; }
  };
  const OVERLAY_POLL_MS = 300;          
  const OVERLAY_OPEN_CLASS = 'gp-open';  
  let overlayPaused = false;             
  let overlaySavedGameSpeed = 1;         
  const overlayPauseTimer = setInterval(() => {
    try {
      let isOpen = false;
      try {
        const el = (typeof document !== 'undefined' && typeof document.getElementById === 'function')
          ? document.getElementById('gp-overlay')
          : null;
        isOpen = !!el && typeof el.classList !== 'undefined' && el.classList.contains(OVERLAY_OPEN_CLASS);
      } catch (e) { isOpen = false; }
      const dir = getDirector();
      if (isOpen && !overlayPaused) {
        overlayPaused = true;
        try { if (dir && typeof dir.pause === 'function' && !dir.isPaused()) dir.pause(); } catch (e) {}
        try { if (dir) dir.gameSpeed = 0; } catch (e) {}
      } else if (!isOpen && overlayPaused) {
        overlayPaused = false;
        try { if (dir && typeof dir.resume === 'function' && dir.isPaused()) dir.resume(); } catch (e) {}
        try { if (dir) dir.gameSpeed = overlaySavedGameSpeed; } catch (e) {}
      }
    } catch (e) {}
  }, OVERLAY_POLL_MS);
  cleanups.push(() => {
    try { clearInterval(overlayPauseTimer); } catch (e) {}
    try {
      const dir = getDirector();
      if (dir && overlayPaused) {
        if (typeof dir.resume === 'function' && dir.isPaused()) dir.resume();
        dir.gameSpeed = overlaySavedGameSpeed;
      }
    } catch (e) {}
  });
  const getCc = () => { try { return engine && typeof engine.getCc === 'function' ? engine.getCc() : null; } catch (e) { return null; } };
  let pointLabelPrefab = null;      
  let pointLayerNode = null;        
  let instantiatePooly = null;      
  let destroyPooly = null;          
  let armatureLabelCls = null;      
  let resolveFailedLogged = false;
  const activeLabels = new Map();
  const resolveResources = () => {
    try {
      if (pointLabelPrefab && instantiatePooly && destroyPooly && pointLayerNode && armatureLabelCls) return true;
      const mPar = engine.getSystemModule('chunks:///_virtual/Particles.ts');
      const particle = mPar && mPar.particle;
      if (particle) {
        const pr = particle.particleRes || null;
        if (pr && pr.PointShowerLabel && !pointLabelPrefab) pointLabelPrefab = pr.PointShowerLabel;
      }
      const mPool = engine.getSystemModule('chunks:///_virtual/NodePools.ts');
      if (mPool) {
        if (!instantiatePooly && mPool.instantiatePooly) instantiatePooly = mPool.instantiatePooly;
        if (!destroyPooly && mPool.destroyPooly) destroyPooly = mPool.destroyPooly;
      }
      const mLevel = engine.getSystemModule('chunks:///_virtual/levelController.ts');
      const lvl = mLevel && mLevel.LevelPlay;
      const pl = (lvl && lvl.component && lvl.component.pointLayer) || null;
      if (pl && pl.isValid) pointLayerNode = pl;
      const cc = getCc();
      if (!armatureLabelCls && cc && cc.Label) armatureLabelCls = cc.Label;
      const ok = !!(pointLabelPrefab && instantiatePooly && destroyPooly && pointLayerNode && armatureLabelCls);
      if (!ok && !resolveFailedLogged && log) {
        resolveFailedLogged = true;
        log.warn('PEP-FullDisplay: resource missing — prefab=' + !!pointLabelPrefab + ' pool=' + !!(instantiatePooly && destroyPooly) + ' pointLayer=' + !!pointLayerNode + ' Label=' + !!armatureLabelCls + ' (will retry each frame)');
      }
      return ok;
    } catch (e) { return false; }
  };
  const isPlantLike = (self) => {
    try { return !!self && typeof self.food === 'function' && !!self.node && !!self.node.isValid; } catch (e) { return false; }
  };
  const isZombieLike = (self) => {
    try { return !!self && typeof self.totalHealth === 'function' && !!self.node && !!self.node.isValid; } catch (e) { return false; }
  };
  const isTombLike = (self) => {
    try { return !!self && typeof self.toughness === 'number' && typeof self.food !== 'function' && typeof self.totalHealth !== 'function' && !!self.node && !!self.node.isValid; } catch (e) { return false; }
  };
  const isShowable = (self) => {
    try { return !!self && !!self.node && !!self.node.isValid && (typeof self.toughness === 'number' || typeof self.health === 'number'); } catch (e) { return false; }
  };
  const ensureLabel = (self) => {
    try {
      if (!resolveResources()) return null;
      if (self.__gpnHpLabel && self.__gpnHpLabel.isValid) return self.__gpnHpLabel;
      if (self.__gpnHpLabelNode && !self.__gpnHpLabelNode.isValid) {
        self.__gpnHpLabel = null; self.__gpnHpLabelNode = null;
      }
      const node = instantiatePooly(pointLabelPrefab);
      if (!node) return null;
      node.parent = pointLayerNode;
      try { node.setLayerWithAllChildren(pointLayerNode.layer); } catch (e) {}
      try { if (activeLabels) activeLabels.set(self, (activeLabels.get(self) || 0) + 1); } catch (e) {}
      const label = node.getComponent ? node.getComponent(armatureLabelCls) : null;
      if (label) {
        try { label.fontSize = LABEL_SIZE; } catch (e) {}
        try { label.lineHeight = Math.round(LABEL_SIZE * 1.3); } catch (e) {}
        try { if ('isBold' in label) label.isBold = false; } catch (e) {}
        try { if ('enableOutline' in label) label.enableOutline = true; } catch (e) {}
        try { if (label.outlineWidth !== undefined) label.outlineWidth = 1; } catch (e) {}
        try {
          if (label.color && typeof label.color.set === 'function') {
            label.color.set(255, 255, 255, 255);
          }
        } catch (e) {}
      }
      self.__gpnHpLabel = label || node;
      self.__gpnHpLabelNode = node;
      return self.__gpnHpLabel;
    } catch (e) { return null; }
  };
  const buildArmorText = (self, isZombie, isPlant) => {
    try {
      if (isZombie && Array.isArray(self.armors) && self.armors.length > 0) {
        const segs = [];
        for (const a of self.armors) {
          try {
            const h = Math.max(0, Math.round(Number(a.health) || 0));
            const t = Math.max(0, Math.round(Number(a.toughness) || Number((a.props && a.props.Toughness) || 0) || h));
            segs.push(t > 0 ? h + '/' + t : String(h));
          } catch (e) {}
        }
        return segs.join(' ');
      }
      if (isPlant) {
        try {
          const h = Math.max(0, Math.round(Number(self.armorHealth) || 0));
          const t = Math.max(0, Math.round(Number(self.armorToughness) || 0));
          if (h > 0 && t > 0) return h + '/' + t;
          if (h > 0) return String(h);
        } catch (e) {}
      }
      return '';
    } catch (e) { return ''; }
  };
  const ensureArmorLabel = (self) => {
    try {
      if (!resolveResources()) return null;
      if (self.__gpnHpArmorLabel && self.__gpnHpArmorLabel.isValid) return self.__gpnHpArmorLabel;
      if (self.__gpnHpArmorNode && !self.__gpnHpArmorNode.isValid) {
        self.__gpnHpArmorLabel = null; self.__gpnHpArmorNode = null;
      }
      const node = instantiatePooly(pointLabelPrefab);
      if (!node) return null;
      node.parent = pointLayerNode;
      try { node.setLayerWithAllChildren(pointLayerNode.layer); } catch (e) {}
      try { if (activeLabels) activeLabels.set(self, (activeLabels.get(self) || 0) + 1); } catch (e) {}
      const label = node.getComponent ? node.getComponent(armatureLabelCls) : null;
      if (label) {
        try { label.fontSize = ARMOR_LABEL_SIZE; } catch (e) {}
        try { label.lineHeight = Math.round(ARMOR_LABEL_SIZE * 1.3); } catch (e) {}
        try { if ('isBold' in label) label.isBold = false; } catch (e) {}
        try { if ('enableOutline' in label) label.enableOutline = true; } catch (e) {}
        try { if (label.outlineWidth !== undefined) label.outlineWidth = 1; } catch (e) {}
        try {
          if (label.color && typeof label.color.set === 'function') {
            label.color.set(LABEL_COLOR_ARMOR[0], LABEL_COLOR_ARMOR[1], LABEL_COLOR_ARMOR[2], LABEL_COLOR_ARMOR[3]);
          }
        } catch (e) {}
      }
      self.__gpnHpArmorLabel = label || node;
      self.__gpnHpArmorNode = node;
      return self.__gpnHpArmorLabel;
    } catch (e) { return null; }
  };
  const refreshLabel = (self) => {
    try {
      if (!self || !self.node || !self.node.isValid || self.dead === true) {
        removeLabel(self);
        return;
      }
      const isPlant = isPlantLike(self);
      const isZombie = !isPlant && isZombieLike(self);
      const isTomb = !isPlant && !isZombie && isTombLike(self);
      if (!isPlant && !isZombie && !isTomb) return;
      if (isPlant && !SHOW_PLANT_HP) { removeLabel(self); return; }
      if (isZombie && !SHOW_ZOMBIE_HP) { removeLabel(self); return; }
      if (isTomb && !SHOW_TOMB_HP) { removeLabel(self); return; }
      const label = ensureLabel(self);
      if (!label) return;
      try {
        const wp = self.node && self.node.worldPosition;
        if (wp && typeof wp.x === 'number') {
          const node = self.__gpnHpLabelNode;
          if (node) {
            const offY = isZombie ? (LABEL_OFFSET_Y - ZOMBIE_OFFSET_DELTA) : LABEL_OFFSET_Y;
            node.worldPosition = new (getCc().Vec3)(wp.x, wp.y + offY, wp.z || 0);
          }
        }
      } catch (e) {}
      let hp = 0, maxHp = 0;
      try {
        hp = Math.max(0, Math.round(Number(self.health) || 0));
        maxHp = Math.max(0, Math.round(Number(self.toughness) || 0));
      } catch (e) {}
      const parts = [];
      if (maxHp > 0) parts.push(hp + '/' + maxHp);
      else parts.push(String(hp));
      if (isPlant) {
        const ultCountRaw = Number(self.__gpnPepUltCount) || 0;
        const ultCount = Math.min(ultCountRaw, 3);
        if (ultCountRaw > 0) {
          parts.push(ultCount >= 3 ? '★' : '(' + ultCount + ')');
        }
      }
      const text = parts.join(' ');
      const old = self.__gpnHpText;
      if (text !== old) {
        try { label.string = text; self.__gpnHpText = text; } catch (e) {}
      }
      const armorText = buildArmorText(self, isZombie, isPlant);
      if (armorText) {
        const armorLabel = ensureArmorLabel(self);
        if (armorLabel) {
          const aOld = self.__gpnHpArmorText;
          if (armorText !== aOld) {
            try { armorLabel.string = armorText; self.__gpnHpArmorText = armorText; } catch (e) {}
          }
          try {
            if (armorLabel.color && typeof armorLabel.color.set === 'function') {
              armorLabel.color.set(LABEL_COLOR_ARMOR[0], LABEL_COLOR_ARMOR[1], LABEL_COLOR_ARMOR[2], LABEL_COLOR_ARMOR[3]);
            }
          } catch (e) {}
          try {
            const wp = self.node && self.node.worldPosition;
            if (wp && typeof wp.x === 'number') {
              const an = self.__gpnHpArmorNode;
              if (an) {
                const baseY = isZombie ? (LABEL_OFFSET_Y - ZOMBIE_OFFSET_DELTA) : LABEL_OFFSET_Y;
                an.worldPosition = new (getCc().Vec3)(wp.x, wp.y + baseY + ARMOR_LABEL_OFFSET, wp.z || 0);
              }
            }
          } catch (e) {}
        }
      } else {
        try {
          const an = self.__gpnHpArmorNode;
          if (an && an.isValid) {
            self.__gpnHpArmorLabel = null;
            self.__gpnHpArmorNode = null;
            self.__gpnHpArmorText = null;
            try { if (destroyPooly) destroyPooly(an); else an.destroy(); } catch (e) {}
          }
        } catch (e) {}
      }
      const full = isPlant && (Number(self.__gpnPepUltCount) || 0) >= 3;
      const wantColor = full ? LABEL_COLOR_FULL : LABEL_COLOR_NORMAL;
      const oldColor = self.__gpnHpColor;
      if (!oldColor || oldColor[0] !== wantColor[0] || oldColor[1] !== wantColor[1] || oldColor[2] !== wantColor[2]) {
        try {
          if (label.color && typeof label.color.set === 'function') {
            label.color.set(wantColor[0], wantColor[1], wantColor[2], wantColor[3]);
          } else if (typeof label.setColor === 'function') {
            label.setColor(new (getCc().Color)(wantColor[0], wantColor[1], wantColor[2], wantColor[3]));
          }
          self.__gpnHpColor = wantColor;
        } catch (e) {}
      }
    } catch (e) {}
  };
  const removeLabel = (self) => {
    try {
      try { if (self && activeLabels) activeLabels.delete(self); } catch (e) {}
      const node = self && self.__gpnHpLabelNode;
      self.__gpnHpLabel = null;
      self.__gpnHpLabelNode = null;
      self.__gpnHpText = null;
      self.__gpnHpColor = null;
      if (node && node.isValid) {
        try { if (destroyPooly) destroyPooly(node); else node.destroy(); } catch (e) {}
      }
      const an = self && self.__gpnHpArmorNode;
      self.__gpnHpArmorLabel = null;
      self.__gpnHpArmorNode = null;
      self.__gpnHpArmorText = null;
      if (an && an.isValid) {
        try { if (destroyPooly) destroyPooly(an); else an.destroy(); } catch (e) {}
      }
    } catch (e) {}
  };
  let charCls = null;
  try { charCls = engine.getClassByName('Character') || null; } catch (e) { charCls = null; }
  let prevCharUpdate = null;
  let newCharUpdate = null;
  if (charCls && charCls.prototype && typeof charCls.prototype.update === 'function') {
    prevCharUpdate = charCls.prototype.update;
    newCharUpdate = function (dt, ...rest) {
      try {
        if (this && this.__gpnHpLabelNode && this.__gpnHpLabelNode.isValid && (this.dead === true || !this.node || !this.node.isValid)) {
          removeLabel(this);
        }
        if (isShowable(this)) refreshLabel(this);
      } catch (e) {}
      return prevCharUpdate.apply(this, arguments);
    };
    charCls.prototype.update = newCharUpdate;
  } else {
    if (log) log.warn('PEP-FullDisplay: Character.update not found');
  }
  const cleanupTargets = ['Plant', 'Zombie', 'Tomb'];
  const codWraps = [];
  for (const cn of cleanupTargets) {
    try {
      const cls = engine.getClassByName(cn) || null;
      if (cls && cls.prototype && typeof cls.prototype.characterOnDisable === 'function') {
        const prev = cls.prototype.characterOnDisable;
        const next = function (...args) {
          try { if (this && (this.__gpnHpLabelNode || this.__gpnHpArmorNode)) removeLabel(this); } catch (e) {}
          return prev.apply(this, args);
        };
        cls.prototype.characterOnDisable = next;
        codWraps.push({ cls, prev, next });
      }
    } catch (e) {}
  }
  let scanTimer = null;
  try {
    scanTimer = setInterval(() => {
      try {
        for (const [ent, cnt] of activeLabels) {
          try {
            if (!ent || !ent.node || !ent.node.isValid || ent.dead === true) removeLabel(ent);
          } catch (e) {}
        }
      } catch (e) {}
    }, 400);
  } catch (e) { scanTimer = null; }
  cleanups.push(() => {
    try {
      if (scanTimer) clearInterval(scanTimer);
      if (newCharUpdate && charCls && charCls.prototype.update === newCharUpdate) {
        charCls.prototype.update = prevCharUpdate;
      }
      for (const w of codWraps) {
        try {
          if (w.cls && w.cls.prototype.characterOnDisable === w.next) w.cls.prototype.characterOnDisable = w.prev;
        } catch (e) {}
      }
      try {
        for (const ent of [...activeLabels.keys()]) removeLabel(ent);
      } catch (e) {}
    } catch (e) {}
  });
  if (log) log.info('PEP-FullDisplay active: plant=' + SHOW_PLANT_HP + ' zombie=' + SHOW_ZOMBIE_HP + ' tomb=' + SHOW_TOMB_HP + ' fontSize=' + LABEL_SIZE + ' offsetY=' + LABEL_OFFSET_Y + (resolveResources() ? '' : ' (WARN: PointShowerLabel unavailable)'));
  return () => {
    for (const c of cleanups) { try { c(); } catch (e) {} }
  };
}
